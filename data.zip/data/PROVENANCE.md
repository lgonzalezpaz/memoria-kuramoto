# Provenance of the connectome files

The four `dk68_*` files are redistributed, unmodified, from the openly available
`tvb-data` Python package, version 3.0.0, archive `tvb_data/connectivity/connectivity_68.zip`:

```
pip download tvb-data==3.0.0 --no-deps
unzip tvb_data-3.0.0-py3-none-any.whl
unzip tvb_data/connectivity/connectivity_68.zip -d c68
bunzip2 c68/*.bz2
```

| redistributed file | upstream file |
|---|---|
| `dk68_weights.txt` | `weights.txt` |
| `dk68_tract_lengths.txt` | `tract_lengths.txt` |
| `dk68_centres.txt` | `centres.txt` |
| `dk68_orientations.txt` | `average_orientations.txt` |
| `dk68_regions.txt` | first column of `centres.txt` |

MD5 checksums of the redistributed matrices:

```
2a17652fecca239d910a4140b6a9b366  dk68_weights.txt
5f735f5fec2746a74a53d60bbda6a8e0  dk68_tract_lengths.txt
```

Properties verified by `src/model.py::load_connectome` at load time:
68 x 68, exactly symmetric, zero diagonal, edge density 0.273,
tract lengths 8.0-252.9 mm (mean 79.0 mm unweighted, 52.4 mm weighted by
connection strength).

The parcellation is the Desikan-Killiany atlas restricted to its 68 cortical
regions (34 per hemisphere). The connectome retains the licence terms of its
upstream `tvb-data` distribution.
