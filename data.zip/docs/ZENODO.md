# Zenodo deposition checklist

1. Tag the repository: `git tag -a v1.0.0 -m "Manuscript submission" && git push --tags`.
2. Enable the GitHub-Zenodo integration for this repository, then publish the release;
   Zenodo mints the DOI automatically from the tag.
3. Upload metadata from `CITATION.cff` (title, author, ORCID, licence, keywords).
4. Attach, in addition to the source archive:
   - `results/` (all result tables, including `references_verified.csv`)
   - `figures/` (PDF vector + 600 dpi PNG)
   - `docs/Manuscript.docx`, `docs/Figures.docx`, `docs/manuscript.md`
5. Set the licence to MIT for code and CC BY 4.0 for data and figures.
6. Replace `[GITHUB URL]` and `[ZENODO DOI]` in the Data Availability Statement of the
   manuscript with the minted values, then regenerate the DOCX with `make docx`.
7. Record the exact environment used for the archived run:
   `pip freeze > results/environment_frozen.txt` before tagging.
