<!--
STYLE NOTES FOR DOCX CONVERSION
Page: A4, single column, margins 2.54 cm. Body: Times New Roman 12 pt, black,
left-aligned, double-spaced, no first-line indent, blank line between paragraphs.
Title 16 pt bold sentence case. Authors 12 pt centred. Affiliations 9-10 pt.
Abstract 10-11 pt single paragraph. Keywords 9-10 pt. Level-1 headings 12-14 pt
bold sentence case, unnumbered. Level-2 headings 11-12 pt bold sentence case.
Equations centred, numbered (1), (2), ... at right margin; variables italic,
units roman. Page numbers top right; continuous line numbers in left margin.
Reference list 9-10 pt, 1.15 spacing. Gene symbols italic; P, n, t, r, rho italic.
-->

# Everything is memory? A connectome-based falsification test of attractor inertia as a unifying axis of autistic, Alzheimer and parkinsonian brain dynamics

Ysaías J. Alvarado^1^, Máximo Quintero^2,3^, Arlene Cardozo-Urdaneta^1^, Carla Lossada^1^, Ariana Delgado^1^ and Lenin González-Paz^1,\*^

^1^Instituto Venezolano de Investigaciones Científicas (IVIC), Centro de Biomedicina Molecular (CBM), 4001 Maracaibo, Venezuela.

^2^Servicio Autónomo Hospital Universitario de Maracaibo (SAHUM), Servicio de Neurología, 4001 Maracaibo, Zulia, Venezuela.

^3^Universidad del Zulia, Facultad de Medicina, 4001 Maracaibo, Zulia, Venezuela.

\*Correspondence: lgonzalezpaz@gmail.com (L.G.-P.)

---

## Abstract

The "everything is memory" hypothesis proposes that boundaries between cognition, perception, motor control and memory are artificial, and that attractor inertia (consolidated well depth, *g*) and noise tolerance (*σ*) span a plane unifying neurotypical flexibility, autistic rigidity, Alzheimer fragmentation and parkinsonian blockade. To test this claim, we placed 68 Kuramoto phase oscillators on a diffusion-MRI human connectome with empirical conduction delays and motif-gated, homeostatically normalised structural plasticity, calibrated at maximal metastability (*K* = 160, *v* = 12 m s^−1^, *f*~0~ = 20 Hz) and validated against three independent empirical anchors. Across 441 grid settings, 20 realisations at five operating points and 22 pre-specified markers, raising noise (*σ* = 6.0) reproduced six of seven Alzheimer markers, whereas increasing attractor inertia (*g*) concentrated coupling (*H* effect size +53.0) yet monotonically shortened attractor dwell time across all eight plasticity implementations (*ρ* ≤ −0.961), rendering the autistic quadrant anti-predictive and parkinsonian hypersynchrony unreachable under conserved coupling. A 263-setting search recovered all three clinical signatures in the structural plane of global coupling budget (*K*) and conduction velocity (*v*). Although four-marker autistic and parkinsonian criteria overlapped by 83.9 % (Jaccard 0.388) at high *K* and fast *v*, adding spectral-spatial specificity — delay-pulled alpha preservation in autism versus focal sensorimotor beta consolidation (*g*~SM~) in Parkinson's disease — separated all three syndromes with zero overlap (Jaccard 0.000). Thus, "everything is memory" fails for edge-local synaptic consolidation but holds for the connectome's structural-dynamical prior (*K*, *v*, *g*~SM~, *σ*), defining measurable coordinates for clinical testing.

**Keywords:** Kuramoto model; structural connectome; metastability; attractor inertia; synaptic consolidation; autism spectrum disorder; Alzheimer's disease; Parkinson's disease

---

## Introduction

Large-scale cortical activity is neither globally synchronised nor independent across regions. It dwells transiently in quasi-stable configurations of phase relations and switches between them on a timescale of tens to hundreds of milliseconds, a regime usually called metastability^1-3^. The same regime has been reached from several directions: from coupled-oscillator theory, where partial synchronisation emerges between order and disorder^4-5^; from whole-brain modelling, where oscillators placed on the measured connectome with realistic axonal delays spontaneously generate transient, spatially organised synchronisation modes^6-8^; and from electrophysiology, where resting EEG decomposes into quasi-stable topographies lasting approximately 60–120 ms^9-10^.

This convergence has made metastability an attractive common currency for neuropsychiatric disorders. Reduced metastability accompanies traumatic brain injury^11^ and tracks disease severity across the Alzheimer spectrum^12^; psilocybin expands the dynamical repertoire explored at rest^13^; and whole-brain models reproduce the progressive functional disconnection of Alzheimer's disease from structural damage alone^14^. In autism, energy-landscape analysis of resting fMRI shows that adults with autism spectrum disorder (ASD) make fewer transitions between dominant brain states than neurotypical controls, with an unusually large effect, and that this excess stability predicts symptom severity^15-16^. In Parkinson's disease (PD), exaggerated synchronisation in the beta band of the cortico-basal-ganglia loop is the cardinal electrophysiological finding, and the duration of beta bursts scales with motor impairment and is shortened by dopaminergic therapy^17-20^.

The temptation to read these separate literatures as one phenomenon is strong, and it has been made explicit. A recent conceptual proposal — which we refer to here as the "everything is memory" hypothesis and take as the formal claim under test — holds that the taxonomic distinctions between cognition, motor control, perception and memory are artificial; that all observable behaviour reduces to the competition between the **attractor inertia** of previously consolidated memory traces and the capacity of stochastic perturbation to drive phase transitions; and that tuning only two biophysical quantities, the depth of consolidated attractor wells (governed by disynaptic motifs, *g*) and the tolerance to stochastic noise (*σ*), suffices to generate a bio-behavioural continuum in which neurotypical flexibility, autistic rigidity (hyper-deep attractors), Alzheimer fragmentation (shallow attractors) and parkinsonian blockade (a parasitic attractor monopolising execution) occupy four quadrants of a single plane. Because the role of noise (*σ*) in driving state transitions is already well established in computational neuroscience^7,21^, the decisive, untested claim of the "everything is memory" thesis is that **attractor inertia** implemented by synaptic consolidation (*g*) provides the orthogonal unifying axis that rigidifies whole-brain dynamics.

The proposal is attractive, falsifiable and, as far as we are aware, untested. Each of its ingredients has partial support in its own clinical domain, but those findings come from different populations, modalities and mathematical frameworks; no study has shown that the four conditions share a dynamical substrate governed by the same two variables. The present work asks whether a model built to the specification can deliver the claim.

We therefore constructed the smallest model that contains the hypothesis honestly. Phase oscillators are placed on a real human structural connectome with delays derived from measured tract lengths^22-25^. Coupling is made adaptive through a coherence-dependent, motif-gated consolidation rule in the tradition of plasticity in oscillator networks^26^, and is constrained by homeostatic synaptic scaling so that the consolidation gain *g* redistributes coupling across edges at constant nodal strength rather than simply raising the total coupling. This separation is essential: without it, "deepening the wells" is indistinguishable from "turning up the global coupling", and the hypothesis cannot be tested at all. The second parameter is the phase-noise amplitude *σ*, the role of which in enabling exploration of the dynamic repertoire is well established^7^.

Three methodological commitments make the test informative rather than decorative. First, the parameters that are *not* part of the hypothesis are fixed once, by maximising metastability subject to constraints taken from the literature, and are then never adjusted; their influence is quantified by elementary-effects screening. Second, 22 markers are pre-specified before any statistic is computed, each chosen because it has a published human counterpart with a digital object identifier. Third, because the central result turns out to be negative, it is tested against eight alternative operationalisations of attractor deepening, so that the refutation applies to a class of implementations rather than to a single arbitrary choice.

---

## Methods

### Structural connectome

Simulations used the 68-region cortical connectome of the Desikan–Killiany parcellation^24^ distributed with *The Virtual Brain*^23^ and derived from diffusion-MRI tractography^22^ (Fig. 1a). The weight matrix *W* is symmetric with zero diagonal, 1,176 directed edges and an off-diagonal edge density of 0.258 (1,176 / 4,556 directed pairs). Tract lengths range from 8.0 to 252.9 mm (mean 79.0 mm unweighted; 52.4 mm weighted by connection strength), and weight and length are negatively correlated across edges (*r* = −0.263), so that strong connections are preferentially short. Weights were normalised so that the mean nodal strength equals unity, which makes the global coupling *K* directly interpretable. No human participants were recruited or scanned for this study and no individual-level data were analysed; the connectome files, their checksums and the exact extraction commands are given in the reproducibility package.

Conduction delays follow from the measured lengths,

> *τ*~*ij*~ = *L*~*ij*~ ⁄ *v* ,  (1)

with *v* the axonal conduction velocity, calibrated within the range reported for human cortico-cortical fibres^25^ (Fig. 1c).

The disynaptic motif support, which operationalises the "disynaptic motifs" invoked by the hypothesis, is the normalised two-step path weight (Fig. 1b),

> *M*~*ij*~ = (*W*²)~*ij*~ ⁄ max~*i*≠*j*~ (*W*²)~*ij*~ ,  *M*~*ii*~ = 0 .  (2)

### Motif-gated adaptive Kuramoto model

Each region *i* carries a phase *θ*~*i*~ with intrinsic angular frequency *ω*~*i*~ drawn from a normal distribution of mean 2π*f*~0~ and standard deviation 2π × 1 Hz. The dynamics are

> d*θ*~*i*~⁄d*t* = *ω*~*i*~ + *K* Σ~*j*~ *C*~*ij*~(*t*) sin[*θ*~*j*~(*t* − *τ*~*ij*~) − *θ*~*i*~(*t*)] + *σ* *ξ*~*i*~(*t*) ,  (3)

where *ξ*~*i*~ is independent Gaussian white noise of unit intensity and *σ* is the first hypothesis parameter. The coupling *C*~*ij*~ is not fixed. A low-pass filtered local coherence trace,

> *τ*~r~ d*r*~*ij*~⁄d*t* = −*r*~*ij*~ + cos[*θ*~*j*~(*t*) − *θ*~*i*~(*t*)] ,  (4)

drives consolidation towards a Gibbs-weighted target,

> *τ*~c~ d*C*~*ij*~⁄d*t* = −*C*~*ij*~ + *W*~*ij*~ exp(*g* *M*~*ij*~ *r*~*ij*~) ,  (5)

in which *g* ≥ 0 is the second hypothesis parameter, the consolidation gain. After each update the coupling is rescaled to conserve the anatomical nodal strength *S*~*i*~ = Σ~*j*~ *W*~*ij*~,

> *C*~*ij*~ ← *C*~*ij*~ *S*~*i*~ ⁄ Σ~*k*~ *C*~*ik*~ .  (6)

Equations (5) and (6) together make consolidation a softmax over the edges of each node, with *g* playing the role of an inverse temperature: *g* = 0 recovers the standard non-adaptive Kuramoto model on the anatomical connectome exactly, while large *g* concentrates each node's fixed coupling budget on its most coherent, most motif-supported partners. This is the sense in which *g* deepens attractor wells, and the conservation law in equation (6) guarantees that it does so by changing the *shape* of the landscape and not its overall depth, which remains the province of *K*.

The sculpting achieved by *g* is quantified by the mean within-node Herfindahl concentration of the coupling,

> *H* = (1⁄*N*) Σ~*i*~ Σ~*j*~ [ *C*~*ij*~ ⁄ Σ~*k*~ *C*~*ik*~ ]² .  (7)

Equations (3)–(6) were integrated by the Euler–Maruyama scheme with a step of 0.5 ms (100 steps per cycle at *f*~0~ = 20 Hz), using ring-buffered delayed phases and a compressed sparse-row edge list. Each run discarded a 4 s transient and recorded 20 s. The integrator was compiled with Numba^27^ on top of NumPy^28^ and SciPy^29^; clustering used scikit-learn^30^ and figures Matplotlib^31^. One run takes about 2 s on a single core.

### Observables

The global order parameter is *R*(*t*)e^i*Φ*(*t*)^ = *N*^−1^ Σ~*j*~ e^i*θ*~*j*~(*t*)^. Mean synchrony is ⟨*R*⟩ and metastability is the standard deviation of *R*(*t*)^32-34^.

Instantaneous phase-locking configurations were summarised by the leading phase-locking mode *u*~*i*~(*t*) = cos[*θ*~*i*~(*t*) − *Φ*(*t*)], sampled at 200 Hz. A **single** dictionary of *k* = 5 configurations was obtained by *k*-means on a pooled sample of 24,000 time points spanning the whole parameter plane, and that fixed dictionary was then applied to every condition by nearest-centroid assignment, so that occupancies, dwell times and transition matrices are strictly comparable across conditions^13,35^. From the resulting label sequence we computed the mean dwell time, the transition rate, the occupancy-weighted transition entropy, the normalised repertoire entropy, the occupancy of the dominant configuration (the "parasitic index") and the summed occupancy of all configurations ranked third or lower (the "minor-state occupancy"), the last being the direct analogue of the minor-state size reported for autism^15^. Robustness to *k* = 3–8 is reported.

Spectral markers were computed by Welch's method on the global field *N*^−1^ Σ~*i*~ cos *θ*~*i*~, as relative power in the theta (4–8 Hz), alpha (8–13 Hz), beta (13–30 Hz) and gamma (30–48 Hz) bands over 1–48 Hz, together with the carrier frequency and the theta/alpha ratio. Synchronisation bursts were defined as excursions of *R*(*t*) above a threshold fixed once at the 75th percentile of the neurotypical reference run and applied unchanged to every other condition, in direct analogy with the amplitude-envelope beta bursts quantified in the parkinsonian basal ganglia^19^ (Fig. 1e). The same observables were computed for a bilateral sensorimotor subnetwork of 12 regions (Fig. 1d). Simulated functional connectivity was taken as the correlation matrix of *u*(*t*) and compared with *W* over existing structural connections^36-38^.

Finally, the barrier height implied by the observed residence time was estimated from the Kramers relation for escape driven by noise of intensity *D* = *σ*²/2^21^,

> Δ*U* = (*σ*²⁄2) ln(*T*~dwell~ ⁄ *τ*~0~) ,  *τ*~0~ = 1⁄*f*~0~ .  (8)

**[Figure 1 near here]**

### Calibration of the nuisance parameters

The two hypothesis parameters were never calibrated. The three nuisance parameters *f*~0~, *v* and *K* were fixed once, on a grid of 120 settings (*f*~0~ ∈ {10, 20, 40} Hz; *v* ∈ {5, 6, 8, 12, 20} m s^−1^; *K* ∈ {5, 10, 20, 40, 80, 120, 160, 220}), by the standard working-point criterion of maximal metastability^6,33-34^ subject to two constraints taken from the literature and not otherwise used in fitting: a mean configuration dwell time between 60 and 120 ms^9-10^ and partial synchrony, 0.15 ≤ ⟨*R*⟩ ≤ 0.60. Thirteen settings were admissible. The selected working point was *f*~0~ = 20 Hz, *v* = 12 m s^−1^, *K* = 160, and it was then held fixed for every result reported below.

### Operating points, statistics and controls

Five operating points were specified a priori (Table 1): a neurotypical reference NT (*g* = 1, *σ* = 0.4); the three pathological quadrants of the hypothesis, ASD (*g* = 16, *σ* = 0.4), AD (*g* = 1, *σ* = 6.0) and PD~hyp~ (*g* = 16, *σ* = 6.0); and one additional point, PD~locus~, in which consolidation is restricted to the sensorimotor subnetwork. Twenty independent realisations, differing only in the noise seed, were run at each.

All contrasts used two-sided permutation tests with 10,000 relabellings, bootstrap 95 % confidence intervals of the mean difference with 10,000 resamples, and small-sample-corrected Hedges' *g* effect sizes. The Benjamini–Hochberg procedure^39^ controlled the false-discovery rate across the entire family of 132 tests (22 markers × 6 contrasts). Separability of the operating points in the 22-dimensional standardised marker space was tested by permutation on the Euclidean distance between group centroids.

Nuisance-parameter influence was screened by the Morris elementary-effects method^40-41^ over *f*~0~, *v*, *K*, *τ*~r~ and *τ*~c~ with eight trajectories, and the qualitative ordering of the operating points was re-tested under ±25 % perturbation of every nuisance parameter. A prior-predictive check drew 200 Latin-hypercube samples from the full seven-dimensional parameter space to confirm that the empirical target intervals lie inside the model's prior-predictive support, so that any agreement reflects a capability of the model rather than an artefact of tuning.

Because the central finding is negative, three families of controls probed alternative operationalisations of attractor deepening: homeostatic scaling disabled, so that consolidation raises the total coupling budget (C1); the consolidation timescale *τ*~c~ varied from 50 ms to 4 s, spanning well below and well above the dwell time (C2); and the coherence-trace timescale *τ*~r~ varied from 10 to 200 ms (C3). The small-*g* limit of equation (5) is linear in *r*, so the gain sweep covers both the linear and the strongly selective reinforcement regimes.

Every random number generator is explicitly seeded; the seeds are stored in the output files and the entire study reruns end-to-end in under one hour on two CPU cores.

**[Table 1 near here]**

---

## Results

### A working point fixed by metastability alone reproduces three independent empirical anchors

The calibration grid selected *f*~0~ = 20 Hz, *v* = 12 m s^−1^ and *K* = 160 as the admissible setting of maximal metastability (SD(*R*) = 0.151; Fig. 2a, b and Supplementary Fig. S1). At that point the network sits in partial synchrony, ⟨*R*⟩ = 0.457 ± 0.002, with a collective carrier at 11.25 Hz — the delay-induced slowing from the 20 Hz node rhythm into the alpha band that is characteristic of delay-coupled oscillator networks^6,8^.

Three quantities not used by the selection criterion fall inside their published ranges (Fig. 2c, Table 2). The mean dwell time of phase-locking configurations is 106.4 ± 2.7 ms, within the 60–120 ms range of resting EEG microstates^9-10^. The correlation between simulated functional connectivity and the structural connectome is *r* = 0.418 ± 0.006, inside the range reported for human data^36^. Most pointedly, the minor-state occupancy of the neurotypical model is 0.2016 ± 0.0087, against 0.226 reported for typically developing adults by energy-landscape analysis of resting fMRI^15^ — a relative error of −10.8 % for a quantity that entered no fitting procedure at any stage, and this repertoire structure remains consistent across dictionary sizes *k* = 3–8 (Supplementary Fig. S2). The prior-predictive check confirms that these matches are informative rather than automatic: across 200 draws from the full parameter space, dwell time spans 22.9 ms to 12 s and only 52.5 % of draws fall in the empirical window, while the structure–function correlation spans −0.010 to 0.611 with 46.0 % inside its window (Supplementary Fig. S3).

**[Figure 2 near here]** **[Table 2 near here]**

### Consolidation gain sculpts the coupling landscape, exactly as intended

Across the 21 × 21 phase diagram, increasing *g* does what equation (5) was designed to do. The coupling concentration *H* rises monotonically from 0.2785 ± 0.0000 at the neurotypical point to 0.4936 ± 0.0056 at *g* = 16 (Hedges' *g* = 53.0, *q* = 1.1 × 10^−4^) and beyond 0.68 at *g* = 32, while the total coupling budget is conserved to machine precision by equation (6) (Fig. 3f). The landscape is therefore genuinely being reshaped: each node withdraws coupling from incoherent partners and concentrates it on coherent, motif-supported ones. Whatever the dynamical consequences, they cannot be attributed to a failure of the mechanism to act.

**[Figure 3 near here]**

### Deepening the wells shortens, rather than lengthens, attractor residence

The dynamical consequence is the opposite of the one the hypothesis requires (Fig. 4a). Mean dwell time falls from 106.4 ± 2.7 ms at NT to 66.3 ± 1.5 ms at the ASD quadrant (difference −40.1 ms, 95 % CI −41.4 to −38.8, Hedges' *g* = −18.2, *q* = 1.1 × 10^−4^), and the transition rate rises from 9.36 ± 0.24 to 15.04 ± 0.34 Hz (*g* = +19.5). The repertoire does not concentrate but expands: repertoire entropy rises from 0.643 ± 0.010 to 0.986 ± 0.003 (*g* = +46.3), minor-state occupancy from 0.202 ± 0.009 to 0.518 ± 0.011 (*g* = +30.8), and the occupancy of the dominant configuration falls from 0.541 ± 0.015 to 0.264 ± 0.010 (*g* = −21.1). All effects survive FDR control across the full family of 132 tests, of which 124 are significant at *q* < 0.05.

The phase diagram shows that this is not a local accident. Over the whole plane, the maximum dwell time (132.5 ms), the minimum transition rate (7.50 Hz), the minimum minor-state occupancy (0.153) and the maximum dominant-state occupancy (0.603) all occur at *g* = 0 (Fig. 3b–e). In this model the most rigid, most concentrated, longest-dwelling dynamics available are those of the bare anatomical connectome; every increment of consolidation gain makes the system more labile, not less.

### The negative result survives every alternative operationalisation tested

Because a negative result is only as strong as the space of implementations it survives, the consolidation axis was re-examined under eight alternatives (Fig. 5a–c, Table 3). Disabling homeostatic scaling, so that consolidation inflates the total coupling budget rather than redistributing it, does not rescue the hypothesis: dwell time falls from 123.1 ms at *g* = 0 to 14.5 ms at *g* = 32 (Spearman *ρ* = −0.988, *P* = 2.0 × 10^−14^). Varying the consolidation timescale across two orders of magnitude, from 50 ms — well below the dwell time, so that coupling tracks the current configuration — to 4 s — well above it, so that coupling integrates over many configurations — leaves the sign unchanged (*ρ* between −0.961 and −0.988, all *P* ≤ 2.5 × 10^−10^). Varying the coherence-trace timescale from 10 to 200 ms likewise leaves it unchanged. In all eight implementations the coupling concentration rises with *g* (*ρ* = +0.820 to +0.933) while the dwell time falls. The mechanism works; the predicted consequence does not follow.

The Morris screening explains why this cannot be blamed on the fixed parameters: the mean elementary effect *μ** is dominated by *f*~0~ (1.565), *v* (1.037) and *K* (0.584), with the two plasticity timescales an order of magnitude smaller (*τ*~r~ 0.097, *τ*~c~ 0.091; Fig. 6a, b). Under ±25 % perturbation of every nuisance parameter in turn, the ordering of the operating points is preserved in 11 of 11 settings for dwell time and for coupling concentration (Fig. 6c). The repertoire results are also robust to the dictionary size: the elevation of minor-state occupancy in the ASD quadrant relative to NT holds for every *k* from 3 to 8 (Supplementary Fig. S2).

**[Figure 5 near here]** **[Figure 6 near here]** **[Table 3 near here]**

### Noise alone reproduces the Alzheimer signature

The second axis behaves as the hypothesis predicts. At the AD quadrant, metastability falls from 0.1567 ± 0.0026 to 0.1332 ± 0.0036 (*g* = −7.32), mean synchrony from 0.4570 ± 0.0022 to 0.4203 ± 0.0062 (*g* = −7.75), relative alpha power from 0.868 ± 0.006 to 0.825 ± 0.012 (*g* = −4.35), while relative theta power (*g* = +5.34) and the theta/alpha ratio (*g* = +5.33) rise and dwell time shortens^42^ (*g* = −18.9). Six of the seven published Alzheimer markers are reproduced with the correct sign and all six are significant after FDR control (binomial *P* = 0.063); the single failure is the direction of the carrier frequency, which does not slow (Fig. 6a, Table 4). The pattern recapitulates the decreased global EEG synchronisation of Alzheimer's disease and mild cognitive impairment^43^, the loss of alpha with relative theta increase^44^, the disconnection account of the syndrome^45^ and the reduction of metastability reported across the Alzheimer spectrum^12^. Increasing stochastic perturbability on a fixed connectome is thus sufficient, in this model, to generate most of the electrophysiological phenotype.

**[Figure 4 near here]** **[Table 4 near here]**

### The four hypothesised quadrants are statistically distinct but clinically misassigned

All ten pairwise contrasts between the five operating points are significant in the 22-dimensional marker space, with centroid distances from 4.36 to 10.85 standardised units and *q* = 1.0 × 10^−4^ throughout (Fig. 4b, c; Supplementary Fig. S4). The plane therefore does carve out distinct dynamical regimes; the hypothesis is not vacuous at that level.

The assignment of those regimes to syndromes is nevertheless wrong for autism. Of the seven published autism targets, the model reproduces one (Table 4): the increase in coupling concentration, consistent with reports of local network hyperconnectivity alongside long-range underconnectivity in autism^46-48^. It fails on the decrease in transition rate, the increase in dwell time^15,49^, the decrease in repertoire and transition entropy, and quantitatively on minor-state occupancy, where the model gives 0.518 against the published 0.030^15^ — an error of more than an order of magnitude, and in the wrong direction. A binomial test over the directional family gives *P* = 0.98 against chance, which is to say the ASD quadrant is systematically anti-predictive. For Parkinson's disease the outcome is intermediate: both the hypothesis quadrant and the focal-locus point reproduce four of nine targets, succeeding on the spectral markers and failing on every synchrony and burst marker.

The reason for the parkinsonian failures is mechanistic and instructive. The neurotypical working point was selected to maximise metastability, and in a delay-coupled network under the homeostatic constraint of equation (6) it also sits near the maximum of achievable global synchrony. No redistribution of a conserved coupling budget can therefore raise ⟨*R*⟩ above its neurotypical value: at PD~hyp~ synchrony falls to 0.262 ± 0.010 (*g* = −25.8) and the fraction of time spent in synchronisation bursts collapses from 0.247 to 0.009 (*g* = −33.5). Hypersynchrony, the defining feature of the parkinsonian basal ganglia^17,50^, is simply unreachable along the hypothesis axes.

### The anatomical locus of consolidation shifts the spectrum focally towards beta

Restricting consolidation to the 12-region bilateral sensorimotor subnetwork — 80 of the 1,176 edges — produces the one clearly parkinsonian effect the model can generate. Relative beta power of the global field rises from 0.130 ± 0.006 to 0.598 ± 0.019 (*g* = +33.3), beta power within the sensorimotor subnetwork from 0.043 ± 0.003 to 0.167 ± 0.008 (*g* = +19.7), and the collective carrier shifts upward from 11.25 to 13.80 ± 0.10 Hz (*g* = +34.5), crossing from the alpha into the beta band. The effect depends on the anatomy and not merely on the number of edges affected: at matched locus size, the anatomical sensorimotor core produces consistently higher sensorimotor beta than size-matched random loci (Supplementary Fig. S5). The locus of consolidation is thus a genuine third control, orthogonal to both hypothesis parameters, and it moves the system in the spectral direction that beta hypersynchrony requires — without, however, delivering the accompanying increase in synchrony or burst duration.

### The clinical signatures live in the coupling-budget and delay plane, and spectral-spatial specificity resolves the autistic–parkinsonian overlap

If the regimes are not where the hypothesis puts them, where are they? We defined each syndrome's baseline signature as the conjunction of four directional criteria taken verbatim from the published targets, and searched 263 model settings: a 9 × 7 grid over the total coupling budget *K* and the conduction velocity *v* at *g* = 0, together with the 200-point prior-predictive sample (Fig. 7a–c).

All three four-criterion signatures are fully satisfiable, but by the two structural quantities the hypothesis holds fixed. The four-criterion autistic signature — longer dwell, fewer transitions, lower minor-state occupancy, lower repertoire entropy — is met at 62 of 263 settings, including *K* = 220 with *v* = 12 m s^−1^ (dwell time 200.0 ms vs 106.4 ms for NT; transition rate 4.93 Hz vs 9.36 Hz; alpha power 0.978) and *K* = 40 with *v* = 18 m s^−1^ (dwell time 368.4 ms; transition rate 2.64 Hz). The Alzheimer signature is met at 119 settings, either via low coupling with slow conduction (*K* = 40–220, *v* = 5–12 m s^−1^, *K*·*v* ≤ 1,760; prototype *K* = 120, *v* = 8 m s^−1^, where ⟨*R*⟩ = 0.326 and dwell time = 71.1 ms) or via elevated phase noise (*σ* = 1.5–6.0). The parkinsonian signature is met at 31 settings, which combine elevated synchrony (⟨*R*⟩ = 0.598–0.977), beta-dominant spectra, prolonged bursts and an upward carrier shift into the beta band (13.75–19.50 Hz).

Evaluating the exclusivity of the unconstrained four-marker signatures exposes a fundamental ambiguity (Fig. 7d, e, Table 5). Whereas the Alzheimer signature is perfectly disjoint from both others (Jaccard index 0.000 against both ASD and PD; all 119 settings exclusive), 26 of the 31 parkinsonian settings (83.9 %) also satisfy the four-criterion autistic signature (Jaccard index 0.388), leaving only five settings parkinsonian-exclusive against 36 autistic-exclusive. The physical origin of this overlap is delay-induced frequency suppression^6,8,51^: in a network of 20 Hz oscillators coupled through axonal delays *τ*~*ij*~ = *L*~*ij*~/*v*, strong coupling combined with moderate or slow conduction (*v* ≤ 12 m s^−1^, or *K*/*v* ≥ 11.5 m^−1^ s) pulls the collective oscillation down into the alpha and theta bands (2.25–12.50 Hz), whereas fast conduction (*v* ≥ 18 m s^−1^) abolishes delay frustration so that the network locks near its intrinsic 20 Hz beta rhythm while simultaneously freezing state transitions. Because the four-marker autistic definition constrains state switching but not spectral band, it inadvertently admits beta-locked regimes at high *K* and fast *v*.

Incorporating the third coordinate identified by our focal-locus experiment — **spectral-spatial specificity** — completely resolves this ambiguity (Table 5, Table 6, Fig. 7e, f). Requiring that autistic attractor rigidity preserve the neurotypical alpha-dominated spectrum without pathological beta inflation (`pow_beta` ≤ 0.130, matching the absence of whole-cortex beta hypersynchrony in ASD) while Parkinson's disease requires either fast-conduction beta shift (`pow_beta` > 0.130, carrier > 13.5 Hz) or focal sensorimotor consolidation (*g*~SM~ = 16 on the 12-node sensorimotor core at *K* = 160, *v* = 12 m s^−1^) partitions the regimes with **zero overlap across all 263 settings** (ASD–PD overlap 0/31; Jaccard = 0.000 for ASD–AD, ASD–PD and AD–PD; 34/34 ASD settings, 119/119 AD settings and 31/31 PD settings strictly exclusive). Within these disjoint domains, requiring nonzero metastable switching (`transition_rate_hz` > 0) further isolates the physiologically realistic, non-locked clinical operating coordinates (Table 6): metastable ASD at *K* = 160–400, *v* = 5–12 m s^−1^ (prototype *K* = 220, *v* = 12 m s^−1^), structural/delay AD at *K* = 40–220, *v* = 5–12 m s^−1^ (prototype *K* = 120, *v* = 8 m s^−1^) or noise-driven AD at *σ* = 1.5–6.0 (prototype *K* = 160, *v* = 12 m s^−1^, *σ* = 6.0), and intermittent-bursting PD at *K* = 40–160, *v* = 18–26 m s^−1^ (prototype *K* = 160, *v* = 18 m s^−1^, where ⟨*R*⟩ = 0.623, beta power = 0.997, carrier = 13.75 Hz and switching persists at 2.14 Hz) alongside focal sensorimotor PD (*K* = 160, *v* = 12 m s^−1^, *g*~SM~ = 16).

**[Figure 7 near here]** **[Table 5 near here]** **[Table 6 near here]**

---

## Discussion

We set out to test the "everything is memory" hypothesis and its core dynamical claim: that attractor inertia — operationalised as the motif-gated depth of consolidated synaptic wells (*g*) — together with stochastic noise tolerance (*σ*) spans a single two-dimensional plane whose four quadrants unify neurotypical flexibility, autistic rigidity, Alzheimer fragmentation and parkinsonian blockade. Implemented on a diffusion-MRI human connectome, calibrated without reference to clinical outcomes, and interrogated across 22 pre-specified markers and eight plasticity implementations, our results provide a direct, two-part answer to the title question.

First, if "memory" is defined narrowly as activity-dependent, edge-local synaptic consolidation (*g*), then **the claim that "everything is memory" and that synaptic attractor inertia is the unifying axis of these syndromes is falsified**. The consolidation gain *g* sculpts the coupling landscape exactly as intended — concentrating synaptic weight onto coherent, motif-supported edges with an effect size of +53.0 — yet it monotonically *shortens* attractor dwell time and *expands* the state repertoire across all eight operationalisations (with and without homeostatic scaling, across consolidation timescales from 50 ms to 4 s and coherence timescales from 10 to 200 ms, all Spearman *ρ* ≤ −0.961, *P* ≤ 2.5 × 10^−10^). The physical mechanism of this failure is transparent: in a delay-frustrated cortical network, concentrating a node's coupling budget onto its currently coherent local partners strengthens intra-modular binding at the expense of long-range inter-modular bridges, allowing peripheral regions to drift and trigger global configuration switches faster than the consolidated core can prevent them. Edge-local Hebbian consolidation buys local binding at the cost of global attractor stability.

Second, if "memory" is construed in its broader systems-neuroscience sense as the **multi-scale structural and dynamical prior encoded in the connectome** — encompassing global synaptic coupling capacity (*K*), axonal conduction velocity (*v*), regional plasticity locus (*g*~SM~) and stochastic background noise (*σ*) — then **a low-dimensional unification survives, but in a different coordinate system**. Along the noise axis (*σ*), elevating stochastic perturbability on a fixed anatomy reproduces six of seven published Alzheimer markers, including reduced metastability^12^, decreased global synchronisation^43^ and alpha-to-theta spectral slowing^44^, complementing structural-lesion models of Alzheimer's disease^12,14^. Along the structural axes (*K* and *v*), our 263-setting search demonstrates why parkinsonian hypersynchrony^17,19,50^ is unreachable at a conserved coupling budget and how all three complete clinical signatures emerge when *K* and *v* are allowed to vary.

Crucially, our exclusivity and resolution analyses show both why four-marker global phase-dynamics criteria confuse autism with Parkinson's disease in the (*K*, *v*) plane (83.9 % overlap, Jaccard 0.388) and how a third coordinate — **spectral-spatial specificity** — breaks that degeneracy completely (0 % overlap, Jaccard 0.000; Table 5, Table 6). Because axonal delays depress collective oscillation frequency relative to the intrinsic node rhythm^6,8,51^, autistic attractor rigidity corresponds to strong global coupling under preserved or slow conduction (*K* = 160–400, *v* = 5–12 m s^−1^, *K*/*v* ≥ 13.3 m^−1^ s; prototype *K* = 220, *v* = 12 m s^−1^), where delays pull the collective carrier into the alpha band (10.25 Hz) while doubling dwell time (200.0 ms) and halving transition rate (4.93 Hz). Conversely, parkinsonian pathology corresponds either to reduced delay frustration (*K* = 40–160, *v* = 18–26 m s^−1^; prototype *K* = 160, *v* = 18 m s^−1^) that releases the 13.75–19.50 Hz beta carrier, or — at normal cortical conduction velocity (*v* = 12 m s^−1^) — to **focal consolidation restricted to the 12-node sensorimotor core (*g*~SM~ = 16)**, which selectively shifts the sensorimotor and global spectrum into the beta band without requiring whole-cortex conduction speeding.

To make these model coordinates directly actionable for empirical falsification, each parameter maps onto non-invasively measurable neurobiological quantities (Table 6):
1. **Global coupling budget (*K*)** reflects net cortico-cortical synaptic efficacy and excitation/inhibition (E/I) gain^52^, indexed empirically by whole-cortex M/EEG phase-locking value (PLV), global functional connectivity strength and transcranial magnetic stimulation (TMS)-evoked cortical reactivity^37-38^.
2. **Axonal conduction velocity (*v*)** reflects white-matter myelination and axonal diameter^25^, quantifiable in vivo by combining diffusion-MRI tractography lengths (*L*~*ij*~) with MRI myelin-water fraction / *g*-ratio mapping^53^ and direct inter-hemispheric or cortico-cortical conduction latencies from TMS-EEG or cortico-cortical evoked potentials (CCEPs).
3. **Focal sensorimotor consolidation (*g*~SM~)** reflects selective synaptic potentiation within the cortico-basal-ganglia-thalamocortical sensorimotor loop, indexed by source-reconstructed M1/S1 beta-burst duration, sensorimotor-to-global beta power ratio and cortico-muscular coherence^17-19^.
4. **Effective noise amplitude (*σ*)** reflects stochastic background synaptic bombardment and E/I conductance variability, indexed non-invasively by the flattening of the aperiodic 1/*f* spectral exponent in resting M/EEG^54^.

This biophysical mapping defines a concrete, falsifiable experimental protocol for the next test: a multimodal cohort study acquiring high-angular-resolution diffusion MRI, quantitative *g*-ratio myelin imaging and resting-state HD-EEG/MEG in matched neurotypical, ASD, AD and PD cohorts. Fitting individualized whole-brain oscillator models to each participant's tractogram (*W*~*ij*~, *L*~*ij*~) and testing whether empirical estimates (*K̂*, *v̂*, *ĝ*~SM~, *σ̂*) segregate the four cohorts into the disjoint coordinate domains of Table 6 will directly test our central prediction: that ASD exhibits elevated global coupling *K̂* with preserved alpha-band delay frustration (*K̂*/*v̂* ≥ 13 m^−1^ s and uninflated sensorimotor beta), AD exhibits reduced *K̂*·*v̂* and/or flattened aperiodic 1/*f* slope (elevated *σ̂*), and PD exhibits focal sensorimotor beta consolidation (elevated *ĝ*~SM~) and/or shortened effective loop delays, with dopaminergic therapy or adaptive deep brain stimulation^18,20^ shifting patients back toward the neurotypical metastable working point.

Several limitations bound these conclusions. First, our refutation of *g* applies to edge-local pairwise phase plasticity; consolidation rules that reinforce multi-node patterns, modulate oscillator amplitude (Stuart–Landau dynamics^8^) or tune local inhibitory balance^11,52^ could stabilize attractors differently. Second, the 68-region cortical phase model omits explicit subcortical basal-ganglia-thalamic pacemakers, capturing only the cortical projection of the sensorimotor loop. Third, simulations used a group-average connectome; repeating the pipeline on individual connectomes is essential to capture inter-individual heterogeneity^55-56^. Fourth, our clinical signatures are auditable four- and five-marker conjunctions rather than clinical diagnostic criteria. Finally, our methodological design — pre-specified markers, independent working-point calibration, eight plasticity controls and DOI-verified targets — illustrates the value of falsification-first whole-brain modelling: a model is scientifically informative precisely when its mechanics refuse to produce a postulated effect and instead reveal the coordinates that do.

---

## Conclusions

Directly testing the "everything is memory" hypothesis on the human structural connectome yields a clear verdict. As a claim about edge-local synaptic consolidation (*g*), "attractor inertia as a unifying axis" is falsified: motif-gated consolidation sculpts the coupling landscape (*H* effect size +53.0) but monotonically shortens attractor dwell time across all eight implementations (*ρ* ≤ −0.961), making the hypothesised autistic quadrant anti-predictive (1/7 markers) and leaving parkinsonian hypersynchrony unreachable under conserved coupling. Conversely, stochastic noise (*σ*) reproduces six of seven Alzheimer markers on a fixed anatomy. When the search is widened to the structural parameters held fixed by the hypothesis — global coupling budget (*K*) and axonal conduction velocity (*v*) — all three clinical signatures are recovered, and the 83.9 % overlap between four-marker autistic and parkinsonian criteria (Jaccard 0.388) is completely resolved (0 % overlap, Jaccard 0.000) by incorporating a third coordinate: spectral-spatial locus specificity (delay-pulled alpha preservation at *K* = 160–400, *v* = 5–12 m s^−1^ in autism versus fast-conduction beta shift at *v* ≥ 18 m s^−1^ or focal sensorimotor consolidation *g*~SM~ = 16 in Parkinson's disease). Unification across neurotypical, autistic, Alzheimer and parkinsonian dynamics therefore fails in the two-parameter (*g*, *σ*) plane of synaptic consolidation and noise, but succeeds in the four-coordinate structural-dynamical space (*K*, *v*, *g*~SM~, *σ*), providing exact parameter domains and a concrete multimodal dMRI/*g*-ratio/M-EEG protocol for empirical falsification.

---

## CRediT authorship contribution statement

**Ysaías J. Alvarado:** Conceptualization, Investigation, Validation, Writing – review & editing. **Máximo Quintero:** Investigation, Clinical validation, Formal analysis, Writing – review & editing. **Arlene Cardozo-Urdaneta:** Investigation, Data curation, Validation, Writing – review & editing. **Carla Lossada:** Investigation, Validation, Visualization, Writing – review & editing. **Yovani Marrero-Ponce:** Methodology, Validation, Supervision, Writing – review & editing. **Félix Martinez-Rios:** Software, Formal analysis, Validation, Writing – review & editing. **Yunierkis Pérez-Castillo:** Methodology, Formal analysis, Validation, Writing – review & editing. **Ariana Delgado:** Conceptualization, Methodology, Investigation, Validation, Supervision, Writing – original draft, Writing – review & editing. **Lenin González-Paz:** Conceptualization, Methodology, Software, Formal analysis, Investigation, Data curation, Validation, Visualization, Writing – original draft, Writing – review & editing, Project administration.

## Ethics statement

This study is entirely computational. No human participants or animals were recruited, enrolled or scanned, and no individual-level human data were accessed. The structural connectome analysed is a group-average matrix redistributed in anonymised, openly available form with *The Virtual Brain* software package; its provenance and checksums are documented in the reproducibility package. All empirical comparison values were extracted from peer-reviewed publications, each identified by its digital object identifier, and no new human data were generated. Ethical approval was therefore not required.

## Funding

This research received no specific grant from any funding agency in the public, commercial or not-for-profit sectors.

## Declaration of competing interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## Data availability statement

All data, code and derived results needed to reproduce every number, table and figure in this article are openly available in the accompanying reproducibility package (`memoria-kuramoto-reproducibility-package.zip`). The repository contains the model and observable definitions (`src/model.py`, `src/observables.py`), the calibration, experiment, control, sensitivity, validation and search pipelines (`src/calibrate.py`, `src/run_experiments.py`, `src/run_controls.py`, `src/run_sensitivity.py`, `src/run_validation.py`, `src/run_search.py`), the figure generator (`src/make_figures.py`), the Crossref-based reference verification and bibliography tools (`src/verify_refs.py`, `src/make_bibliography.py`), all derived CSV/JSON tables (`results/`), a pinned environment (`requirements.txt`, `environment.yml`), an MIT licence for the code and CC BY 4.0 for derived data, and a `Makefile` that reruns the entire study end to end in under one hour on two CPU cores. The upstream connectome can be regenerated from its original distribution with `src/fetch_connectome.py`, which verifies the published MD5 checksums. Every random seed is recorded in the output files.

## Declaration of generative AI and AI-assisted technologies in the writing process

During the preparation of this work the authors used large language models to assist with implementing and debugging the simulation and analysis code, with the automated verification of bibliographic records against the Crossref API, with the generation of figures, and with drafting and language editing of the manuscript. The authors designed the study, specified the hypothesis and the markers, defined the validation strategy, verified the numerical results, and reviewed and edited all AI-assisted output. The authors take full responsibility for the content of the publication.

## References

1. Tognoli, E., Kelso, J. A. S. The Metastable Brain. Neuron 81, 35-48 (2014). https://doi.org/10.1016/j.neuron.2013.12.022
2. Kelso, J. A. S. Multistability and metastability: understanding dynamic coordination in the brain. Philosophical Transactions of the Royal Society B: Biological Sciences 367, 906-918 (2012). https://doi.org/10.1098/rstb.2011.0351
3. Deco, G., Jirsa, V. K., McIntosh, A. R. Emerging concepts for the dynamical organization of resting-state activity in the brain. Nature Reviews Neuroscience 12, 43-56 (2010). https://doi.org/10.1038/nrn2961
4. Kuramoto, Y. Self-entrainment of a population of coupled non-linear oscillators. In: Araki, H. (ed.) International Symposium on Mathematical Problems in Theoretical Physics. Lecture Notes in Physics vol. 39, 420-422 (Springer, Berlin, 1975).
5. Acebrón, J. A., Bonilla, L. L., Pérez Vicente, C. J., Ritort, F., Spigler, R. The Kuramoto model: A simple paradigm for synchronization phenomena. Reviews of Modern Physics 77, 137-185 (2005). https://doi.org/10.1103/revmodphys.77.137
6. Cabral, J., Hugues, E., Sporns, O., Deco, G. Role of local network oscillations in resting-state functional connectivity. NeuroImage 57, 130-139 (2011). https://doi.org/10.1016/j.neuroimage.2011.04.010
7. Ghosh, A., Rho, Y., McIntosh, A. R., Kötter, R., Jirsa, V. K. Noise during Rest Enables the Exploration of the Brain's Dynamic Repertoire. PLoS Computational Biology 4, e1000196 (2008). https://doi.org/10.1371/journal.pcbi.1000196
8. Cabral, J., Castaldo, F., Vohryzek, J., Litvak, V., Bick, C., Lambiotte, R. et al. Metastable oscillatory modes emerge from synchronization in the brain spacetime connectome. Communications Physics 5 (2022). https://doi.org/10.1038/s42005-022-00950-y
9. Michel, C. M., Koenig, T. EEG microstates as a tool for studying the temporal dynamics of whole-brain neuronal networks: A review. NeuroImage 180, 577-593 (2018). https://doi.org/10.1016/j.neuroimage.2017.11.062
10. Khanna, A., Pascual-Leone, A., Michel, C. M., Farzan, F. Microstates in resting-state EEG: Current status and future directions. Neuroscience & Biobehavioral Reviews 49, 105-113 (2015). https://doi.org/10.1016/j.neubiorev.2014.12.010
11. Hellyer, P. J., Jachs, B., Clopath, C., Leech, R. Local inhibitory plasticity tunes macroscopic brain dynamics and allows the emergence of functional brain networks. NeuroImage 124, 85-95 (2016). https://doi.org/10.1016/j.neuroimage.2015.08.069
12. Alderson, T. H., Bokde, A. L., Kelso, J. S., Maguire, L., Coyle, D. Metastable neural dynamics in Alzheimer's disease are disrupted by lesions to the structural connectome. NeuroImage 183, 438-455 (2018). https://doi.org/10.1016/j.neuroimage.2018.08.033
13. Lord, L. D., Expert, P., Atasoy, S., Roseman, L., Rapuano, K., Lambiotte, R. et al. Dynamical exploration of the repertoire of brain networks at rest is modulated by psilocybin. NeuroImage 199, 127-142 (2019). https://doi.org/10.1016/j.neuroimage.2019.05.060
14. Demirtaş, M., Falcon, C., Tucholka, A., Gispert, J. D., Molinuevo, J. L., Deco, G. A whole-brain computational modeling approach to explain the alterations in resting-state functional connectivity during progression of Alzheimer's disease. NeuroImage: Clinical 16, 343-354 (2017). https://doi.org/10.1016/j.nicl.2017.08.006
15. Watanabe, T., Rees, G. Brain network dynamics in high-functioning individuals with autism. Nature Communications 8 (2017). https://doi.org/10.1038/ncomms16048
16. Ezaki, T., Watanabe, T., Ohzeki, M., Masuda, N. Energy landscape analysis of neuroimaging data. Philosophical Transactions of the Royal Society A: Mathematical, Physical and Engineering Sciences 375, 20160287 (2017). https://doi.org/10.1098/rsta.2016.0287
17. Hammond, C., Bergman, H., Brown, P. Pathological synchronization in Parkinson's disease: networks, models and treatments. Trends in Neurosciences 30, 357-364 (2007). https://doi.org/10.1016/j.tins.2007.05.004
18. Kühn, A. A., Kupsch, A., Schneider, G., Brown, P. Reduction in subthalamic 8–35 Hz oscillatory activity correlates with clinical improvement in Parkinson's disease. European Journal of Neuroscience 23, 1956-1960 (2006). https://doi.org/10.1111/j.1460-9568.2006.04717.x
19. Tinkhauser, G., Pogosyan, A., Tan, H., Herz, D. M., Kühn, A. A., Brown, P. Beta burst dynamics in Parkinson’s disease OFF and ON dopaminergic medication. Brain 140, 2968-2981 (2017). https://doi.org/10.1093/brain/awx252
20. Little, S., Pogosyan, A., Neal, S., Zavala, B., Zrinzo, L., Hariz, M. et al. Adaptive deep brain stimulation in advanced Parkinson disease. Annals of Neurology 74, 449-457 (2013). https://doi.org/10.1002/ana.23951
21. Kramers, H. Brownian motion in a field of force and the diffusion model of chemical reactions. Physica 7, 284-304 (1940). https://doi.org/10.1016/s0031-8914(40)90098-2
22. Hagmann, P., Cammoun, L., Gigandet, X., Meuli, R., Honey, C. J., Wedeen, V. J. et al. Mapping the Structural Core of Human Cerebral Cortex. PLoS Biology 6, e159 (2008). https://doi.org/10.1371/journal.pbio.0060159
23. Sanz Leon, P., Knock, S. A., Woodman, M. M., Domide, L., Mersmann, J., McIntosh, A. R. et al. The Virtual Brain: a simulator of primate brain network dynamics. Frontiers in Neuroinformatics 7 (2013). https://doi.org/10.3389/fninf.2013.00010
24. Desikan, R. S., Ségonne, F., Fischl, B., Quinn, B. T., Dickerson, B. C., Blacker, D. et al. An automated labeling system for subdividing the human cerebral cortex on MRI scans into gyral based regions of interest. NeuroImage 31, 968-980 (2006). https://doi.org/10.1016/j.neuroimage.2006.01.021
25. Caminiti, R., Carducci, F., Piervincenzi, C., Battaglia-Mayer, A., Confalone, G., Visco-Comandini, F. et al. Diameter, Length, Speed, and Conduction Delay of Callosal Axons in Macaque Monkeys and Humans: Comparing Data from Histology and Magnetic Resonance Imaging Diffusion Tractography. The Journal of Neuroscience 33, 14501-14511 (2013). https://doi.org/10.1523/jneurosci.0761-13.2013
26. Seliger, P., Young, S. C., Tsimring, L. S. Plasticity and learning in a network of coupled phase oscillators. Physical Review E 65 (2002). https://doi.org/10.1103/physreve.65.041906
27. Lam, S. K., Pitrou, A., Seibert, S. Numba. Proceedings of the Second Workshop on the LLVM Compiler Infrastructure in HPC 1-6 (2015). https://doi.org/10.1145/2833157.2833162
28. Harris, C. R., Millman, K. J., van der Walt, S. J., Gommers, R., Virtanen, P., Cournapeau, D. et al. Array programming with NumPy. Nature 585, 357-362 (2020). https://doi.org/10.1038/s41586-020-2649-2
29. Virtanen, P., Gommers, R., Oliphant, T. E., Haberland, M., Reddy, T., Cournapeau, D. et al. SciPy 1.0: fundamental algorithms for scientific computing in Python. Nature Methods 17, 261-272 (2020). https://doi.org/10.1038/s41592-019-0686-2
30. Pedregosa, F. et al. Scikit-learn: machine learning in Python. J. Mach. Learn. Res. 12, 2825-2830 (2011).
31. Hunter, J. D. Matplotlib: A 2D Graphics Environment. Computing in Science & Engineering 9, 90-95 (2007). https://doi.org/10.1109/mcse.2007.55
32. Shanahan, M. Metastable chimera states in community-structured oscillator networks. Chaos: An Interdisciplinary Journal of Nonlinear Science 20 (2010). https://doi.org/10.1063/1.3305451
33. Hellyer, P. J., Shanahan, M., Scott, G., Wise, R. J. S., Sharp, D. J., Leech, R. The Control of Global Brain Dynamics: Opposing Actions of Frontoparietal Control and Default Mode Networks on Attention. The Journal of Neuroscience 34, 451-461 (2014). https://doi.org/10.1523/jneurosci.1853-13.2014
34. Deco, G., Kringelbach, M. L., Jirsa, V. K., Ritter, P. The dynamics of resting fluctuations in the brain: metastability and its dynamical cortical core. Scientific Reports 7 (2017). https://doi.org/10.1038/s41598-017-03073-5
35. Cabral, J., Vidaurre, D., Marques, P., Magalhães, R., Silva Moreira, P., Miguel Soares, J. et al. Cognitive performance in healthy older adults relates to spontaneous switching between states of functional connectivity during rest. Scientific Reports 7 (2017). https://doi.org/10.1038/s41598-017-05425-7
36. Honey, C. J., Sporns, O., Cammoun, L., Gigandet, X., Thiran, J. P., Meuli, R. et al. Predicting human resting-state functional connectivity from structural connectivity. Proceedings of the National Academy of Sciences 106, 2035-2040 (2009). https://doi.org/10.1073/pnas.0811168106
37. Stam, C. J., Nolte, G., Daffertshofer, A. Phase lag index: Assessment of functional connectivity from multi channel EEG and MEG with diminished bias from common sources. Human Brain Mapping 28, 1178-1193 (2007). https://doi.org/10.1002/hbm.20346
38. Lachaux, J. P., Rodriguez, E., Martinerie, J., Varela, F. J. Measuring phase synchrony in brain signals. Human Brain Mapping 8, 194-208 (1999). https://doi.org/10.1002/(sici)1097-0193(1999)8:4<194::aid-hbm4>3.0.co;2-c
39. Benjamini, Y., Hochberg, Y. Controlling the False Discovery Rate: A Practical and Powerful Approach to Multiple Testing. Journal of the Royal Statistical Society Series B: Statistical Methodology 57, 289-300 (1995). https://doi.org/10.1111/j.2517-6161.1995.tb02031.x
40. Morris, M. D. Factorial Sampling Plans for Preliminary Computational Experiments. Technometrics 33, 161-174 (1991). https://doi.org/10.1080/00401706.1991.10484804
41. Saltelli, A., Annoni, P., Azzini, I., Campolongo, F., Ratto, M., Tarantola, S. Variance based sensitivity analysis of model output. Design and estimator for the total sensitivity index. Computer Physics Communications 181, 259-270 (2010). https://doi.org/10.1016/j.cpc.2009.09.018
42. Fiorenzato, E., Strafella, A. P., Kim, J., Schifano, R., Weis, L., Antonini, A. et al. Dynamic functional connectivity changes associated with dementia in Parkinson’s disease. Brain 142, 2860-2872 (2019). https://doi.org/10.1093/brain/awz192
43. Koenig, T., Prichep, L., Dierks, T., Hubl, D., Wahlund, L., John, E. et al. Decreased EEG synchronization in Alzheimer’s disease and mild cognitive impairment. Neurobiology of Aging 26, 165-171 (2005). https://doi.org/10.1016/j.neurobiolaging.2004.03.008
44. Zhang, H., Geng, X., Wang, Y., Guo, Y., Gao, Y., Zhang, S. et al. The Significance of EEG Alpha Oscillation Spectral Power and Beta Oscillation Phase Synchronization for Diagnosing Probable Alzheimer Disease. Frontiers in Aging Neuroscience 13 (2021). https://doi.org/10.3389/fnagi.2021.631587
45. Delbeuck, X., Van der Linden, M., Collette, F. Alzheimer' Disease as a Disconnection Syndrome?. Neuropsychology Review 13, 79-92 (2003). https://doi.org/10.1023/a:1023832305702
46. Supekar, K., Uddin, L. Q., Khouzam, A., Phillips, J., Gaillard, W. D., Kenworthy, L. E. et al. Brain Hyperconnectivity in Children with Autism and its Links to Social Deficits. Cell Reports 5, 738-747 (2013). https://doi.org/10.1016/j.celrep.2013.10.001
47. Uddin, L. Q., Supekar, K., Lynch, C. J., Khouzam, A., Phillips, J., Feinstein, C. et al. Salience Network–Based Classification and Prediction of Symptom Severity in Children With Autism. JAMA Psychiatry 70, 869 (2013). https://doi.org/10.1001/jamapsychiatry.2013.104
48. Just, M. A. Cortical activation and synchronization during sentence comprehension in high-functioning autism: evidence of underconnectivity. Brain 127, 1811-1821 (2004). https://doi.org/10.1093/brain/awh199
49. Nagabhushan Kalburgi, S., Whitten, A. P., Key, A. P., Bodfish, J. W. Children With Autism Produce a Unique Pattern of EEG Microstates During an Eyes Closed Resting-State Condition. Frontiers in Human Neuroscience 14 (2020). https://doi.org/10.3389/fnhum.2020.00288
50. Rubchinsky, L. L., Park, C., Worth, R. M. Intermittent neural synchronization in Parkinson’s disease. Nonlinear Dynamics 68, 329-346 (2011). https://doi.org/10.1007/s11071-011-0223-z
51. Niebur, E., Schuster, H. G., Kammen, D. M. Collective frequencies and metastability in networks of limit-cycle oscillators with time delay. Physical Review Letters 67, 2753-2756 (1991). https://doi.org/10.1103/physrevlett.67.2753
52. Rubenstein, J. L. R., Merzenich, M. M. Model of autism: increased ratio of excitation/inhibition in key neural systems. Genes, Brain and Behavior 2, 255-267 (2003). https://doi.org/10.1034/j.1601-183x.2003.00037.x
53. Stikov, N., Campbell, J. S., Stroh, T., Lavelée, M., Frey, S., Novek, J. et al. In vivo histology of the myelin g-ratio with magnetic resonance imaging. NeuroImage 118, 397-405 (2015). https://doi.org/10.1016/j.neuroimage.2015.05.023
54. Donoghue, T., Haller, M., Peterson, E. J., Varma, P., Sebastian, P., Gao, R. et al. Parameterizing neural power spectra into periodic and aperiodic components. Nature Neuroscience 23, 1655-1665 (2020). https://doi.org/10.1038/s41593-020-00744-x
55. Váša, F., Shanahan, M., Hellyer, P. J., Scott, G., Cabral, J., Leech, R. Effects of lesions on synchrony and metastability in cortical networks. NeuroImage 118, 456-467 (2015). https://doi.org/10.1016/j.neuroimage.2015.05.042
56. Gollo, L. L., Zalesky, A., Hutchison, R. M., van den Heuvel, M., Breakspear, M. Dwelling quietly in the rich club: brain network determinants of slow cortical fluctuations. Philosophical Transactions of the Royal Society B: Biological Sciences 370, 20140165 (2015). https://doi.org/10.1098/rstb.2014.0165

---

## Tables

**Table 1. Model parameters, their values and their provenance.** Only *g* and *σ* are varied; all other parameters are fixed once and then held constant.

| Symbol | Meaning | Value or range | Provenance |
|---|---|---|---|
| *N* | cortical regions | 68 | Desikan–Killiany parcellation^24^ |
| *W* | structural connectivity | measured, density 0.258 | diffusion MRI^22-23^ |
| *L* | tract lengths | 8.0–252.9 mm | idem |
| *f*~0~ | node intrinsic frequency | 20 Hz | calibrated in {10, 20, 40} Hz |
| *v* | conduction velocity | 12 m s^−1^ | calibrated in 5–20 m s^−1^^25^ |
| *K* | global coupling | 160 | calibrated in 5–220 |
| *τ*~r~ | coherence-trace constant | 50 ms | control range 10–200 ms |
| *τ*~c~ | consolidation constant | 200 ms | control range 50 ms–4 s |
| Δ*t* | integration step | 0.5 ms | 100 steps per cycle at 20 Hz |
| *g* | **consolidation gain** | **0–32** | **hypothesis parameter 1** |
| *σ* | **noise amplitude** | **0.05–8** | **hypothesis parameter 2** |

**Table 2. The calibrated working point against three independent empirical anchors.** None of these quantities entered the calibration criterion, which maximised metastability alone. Model values are mean ± s.d. over 20 realisations.

| Quantity | Model (NT) | Published range or value | Source |
|---|---|---|---|
| Configuration dwell time | 106.4 ± 2.7 ms | 60–120 ms | Khanna et al. 2015^10^; Michel & Koenig 2018^9^ |
| Structure–function correlation | *r* = 0.418 ± 0.006 | 0.30–0.70 | Honey et al. 2009^36^ |
| Mean synchrony ⟨*R*⟩ | 0.457 ± 0.002 | 0.15–0.60 (partial synchrony) | Deco et al. 2017^34^ |
| Minor-state occupancy | 0.2016 ± 0.0087 | 0.226 (typically developing) | Watanabe & Rees 2017^15^ |

**Table 3. The consolidation axis across eight alternative implementations.** Spearman correlation of mean dwell time with the consolidation gain *g*, and the dwell time at the extremes of the gain range. In every case the coupling concentration rises while the dwell time falls.

| Control | *ρ* (dwell vs *g*) | *P* | Dwell at *g* = 0 | Dwell at *g* = 32 | *ρ* (concentration vs *g*) |
|---|---|---|---|---|---|
| C1 homeostasis off | −0.988 | 2.0 × 10^−14^ | 123.1 ms | 14.5 ms | +0.933 |
| C2 *τ*~c~ = 50 ms | −0.963 | 1.6 × 10^−10^ | 126.7 ms | 60.0 ms | +0.820 |
| C2 *τ*~c~ = 200 ms | −0.985 | 1.3 × 10^−13^ | 122.5 ms | 57.1 ms | +0.820 |
| C2 *τ*~c~ = 1 s | −0.988 | 2.0 × 10^−14^ | 123.9 ms | 56.6 ms | +0.820 |
| C2 *τ*~c~ = 4 s | −0.961 | 2.5 × 10^−10^ | 126.3 ms | 58.4 ms | +0.820 |
| C3 *τ*~r~ = 10 ms | −0.969 | 3.7 × 10^−11^ | 122.5 ms | 61.5 ms | +0.820 |
| C3 *τ*~r~ = 50 ms | −0.985 | 1.3 × 10^−13^ | 122.5 ms | 57.1 ms | +0.820 |
| C3 *τ*~r~ = 200 ms | −0.982 | 5.8 × 10^−13^ | 122.5 ms | 60.2 ms | +0.820 |

**Table 4. Confrontation with the published literature.** Directional targets are scored by the sign of the contrast against the neurotypical operating point; *q* values are Benjamini–Hochberg corrected across all 132 tests. Hedges' *g* is the small-sample-corrected effect size. Agreement counts per operating point, over the full target list of `data/empirical_targets.csv`: ASD 1/7, AD 6/7, PD~hyp~ 4/9, PD~locus~ 4/9; neurotypical quantitative anchors 5/5. The table lists one row per unique marker; markers targeted by two independent sources (autistic dwell time, parkinsonian beta power) are counted twice in those totals.

| Operating point | Marker | Published direction | NT | Model | Hedges' *g* | *q* | Agree | Source |
|---|---|---|---|---|---|---|---|---|
| ASD | coupling concentration | increase | 0.279 | 0.494 | +53.0 | 1.1 × 10^−4^ | yes | Supekar et al. 2013^46^ |
| ASD | transition rate | decrease | 9.36 Hz | 15.04 Hz | +19.5 | 1.1 × 10^−4^ | **no** | Watanabe & Rees 2017^15^ |
| ASD | dwell time | increase | 106.4 ms | 66.3 ms | −18.2 | 1.1 × 10^−4^ | **no** | Watanabe & Rees 2017^15^; Kalburgi et al. 2020^49^ |
| ASD | repertoire entropy | decrease | 0.643 | 0.986 | +46.3 | 1.1 × 10^−4^ | **no** | Watanabe & Rees 2017^15^ |
| ASD | transition entropy | decrease | 0.495 | 0.875 | +17.7 | 1.1 × 10^−4^ | **no** | Supekar et al. 2013^46^ |
| ASD | minor-state occupancy | 0.030 (point) | 0.202 | 0.518 | — | — | **no** | Watanabe & Rees 2017^15^ |
| AD | mean synchrony | decrease | 0.457 | 0.420 | −7.75 | 1.1 × 10^−4^ | yes | Koenig et al. 2005^43^ |
| AD | metastability | decrease | 0.157 | 0.133 | −7.32 | 1.1 × 10^−4^ | yes | Alderson et al. 2018^12^ |
| AD | alpha power | decrease | 0.868 | 0.825 | −4.35 | 1.1 × 10^−4^ | yes | Zhang et al. 2021^44^ |
| AD | theta power | increase | 0.0025 | 0.0049 | +5.34 | 1.1 × 10^−4^ | yes | Zhang et al. 2021^44^ |
| AD | theta/alpha ratio | increase | 0.0029 | 0.0060 | +5.33 | 1.1 × 10^−4^ | yes | Zhang et al. 2021^44^ |
| AD | dwell time | decrease | 106.4 ms | 51.6 ms | −18.9 | 1.1 × 10^−4^ | yes | Fiorenzato et al. 2019^42^ |
| AD | carrier frequency | decrease | 11.25 Hz | 11.50 Hz | — | 1.1 × 10^−4^ | **no** | Koenig et al. 2005^43^ |
| PD~locus~ | beta power | increase | 0.130 | 0.598 | +33.3 | 1.1 × 10^−4^ | yes | Hammond et al. 2007^17^ |
| PD~locus~ | sensorimotor beta power | increase | 0.043 | 0.167 | +19.7 | 1.1 × 10^−4^ | yes | Hammond et al. 2007^17^ |
| PD~locus~ | carrier frequency | increase | 11.25 Hz | 13.80 Hz | +34.5 | 1.1 × 10^−4^ | yes | Kühn et al. 2006^18^ |
| PD~locus~ | mean synchrony | increase | 0.457 | 0.357 | −34.7 | 1.1 × 10^−4^ | **no** | Hammond et al. 2007^17^ |
| PD~locus~ | burst time fraction | increase | 0.247 | 0.132 | −8.79 | 1.1 × 10^−4^ | **no** | Tinkhauser et al. 2017^19^ |
| PD~locus~ | burst duration | increase | 121.8 ms | 82.9 ms | −6.54 | 1.1 × 10^−4^ | **no** | Tinkhauser et al. 2017^19^ |
| PD~locus~ | dominant-state occupancy | increase | 0.541 | 0.326 | −12.3 | 1.1 × 10^−4^ | **no** | Fiorenzato et al. 2019^42^ |

**Table 5. Exclusivity of the clinical signatures across 263 searched model settings before and after spectral-spatial resolution.** A setting satisfies a baseline signature when all four of its directional criteria hold relative to the neurotypical operating point; the resolved signatures add spectral-band specificity (`pow_beta` ≤ 0.130 for ASD vs `pow_beta` > 0.130 or focal sensorimotor locus *g*~SM~ for PD), eliminating the ASD–PD overlap completely.

| Signature definition | Settings satisfying | Satisfying exclusively | Jaccard with ASD | Jaccard with AD | Jaccard with PD |
|---|---|---|---|---|---|
| ASD (4-criterion baseline) | 62 | 36 | — | 0.000 | 0.388 |
| AD (4-criterion baseline) | 119 | 119 | 0.000 | — | 0.000 |
| PD (4-criterion baseline) | 31 | 5 | 0.388 | 0.000 | — |
| **ASD (resolved: + alpha preservation)** | **34** | **34 (100 %)** | — | **0.000** | **0.000** |
| **AD (resolved)** | **119** | **119 (100 %)** | **0.000** | — | **0.000** |
| **PD (resolved: + beta / SM locus)** | **31** | **31 (100 %)** | **0.000** | **0.000** | — |

**Table 6. Disjoint biophysical coordinate domains, representative metastable prototypes and empirical measurement mappings across the four regimes.** Values at each prototype are reported from the reproducible search (`results/syndrome_coordinates.csv`).

| Regime | Parameter domain (*K*, *v*, *σ*, *g*~SM~) | Prototype setting | ⟨*R*⟩ | Dwell (ms) | Transit. (Hz) | Alpha / Beta power | Carrier (Hz) | Empirical biomarker translation |
|---|---|---|---|---|---|---|---|---|
| **NT** (baseline) | *K* = 160, *v* = 12 m s^−1^, *σ* = 0.4, *g* = 1 | *K* = 160, *v* = 12, *σ* = 0.4 | 0.457 | 106.4 | 9.36 | 0.868 / 0.130 | 11.25 | Balanced whole-cortex PLV; normal *g*-ratio myelination; 60–120 ms EEG microstates |
| **ASD** (metastable) | *K* = 160–400, *v* = 5–12 m s^−1^ (*K*/*v* ≥ 13.3), *σ* = 0.4, *g* = 0 | *K* = 220, *v* = 12, *σ* = 0.4 | 0.567 | 200.0 | 4.93 | 0.978 / 0.020 | 10.25 | Elevated global synaptic coupling / E-I gain (*K̂* ↑) with preserved/slow tract conduction (*v̂* ≤ 12 m s^−1^), yielding alpha-locked state rigidity |
| **AD** (structural / delay) | *K* = 40–220, *v* = 5–12 m s^−1^ (*K*·*v* ≤ 1,760), *σ* = 0.4, *g* = 0 | *K* = 120, *v* = 8, *σ* = 0.4 | 0.326 | 71.1 | 14.00 | 0.644 / 0.352 | 11.00 | Reduced global coupling (*K̂* ↓) and demyelination-related conduction slowing (*v̂* ↓ on dMRI/*g*-ratio + CCEP latency) |
| **AD** (noise-driven) | *K* = 160, *v* = 12 m s^−1^, *σ* = 1.5–6.0, *g* = 1 | *K* = 160, *v* = 12, *σ* = 6.0 | 0.420 | 51.6 | 19.39 | 0.825 / 0.166 | 11.50 | Flattened M/EEG aperiodic 1/*f* spectral exponent (*σ̂* ↑), reduced alpha PLV and shortened microstate dwell |
| **PD** (fast-conduction beta) | *K* = 40–160, *v* = 18–26 m s^−1^ (metastable; ≥18 all), *σ* = 0.4 | *K* = 160, *v* = 18, *σ* = 0.4 | 0.623 | 451.6 | 2.14 | 0.003 / 0.997 | 13.75 | Reduced effective loop transmission delay (*v̂* ↑), releasing intrinsic beta-band synchronisation and prolonged beta bursts |
| **PD** (focal SM locus) | *K* = 160, *v* = 12 m s^−1^, *σ* = 0.4, *g*~SM~ = 16 (12-node M1/S1) | *K* = 160, *v* = 12, *g*~SM~ = 16 | 0.357 | 63.7 | 15.65 | 0.365 / 0.598 (SM 0.167) | 13.80 | Selective M1/S1 sensorimotor beta-burst prolongation and cortico-subcortical coherence (*ĝ*~SM~ ↑) at normal cortical conduction velocity |

---

## Figure captions

**Figure 1. The model and its anatomical substrate.** (**a**) Structural connectivity *W* of the 68-region Desikan–Killiany cortical connectome, logarithmic colour scale. (**b**) Normalised disynaptic motif support *M* (equation 2), which gates consolidation. (**c**) Distribution of conduction delays implied by the measured tract lengths at the calibrated conduction velocity of 12 m s^−1^. (**d**) The bilateral sensorimotor consolidation locus (12 regions, 80 edges) used to define the focal operating point, highlighted on the existing structural edges. (**e**) Six seconds of dynamics at the neurotypical operating point: global synchrony *R*(*t*) (grey), the fixed burst threshold (dotted), and the sequence of phase-locking configurations assigned against the common dictionary (coloured band).

**Figure 2. Calibration of the nuisance parameters and validation of the working point.** (**a**) Metastability against global coupling *K* for every combination of node frequency (marker) and conduction velocity (colour) in the 120-setting calibration grid; the selected working point is circled. (**b**) Metastability against mean dwell time; the shaded band is the empirical 60–120 ms microstate window and blue points are the 13 admissible settings. (**c**) Three quantities not used in calibration, each shown as its position within the published range: dwell time, structure–function correlation and mean synchrony.

**Figure 3. The two-parameter phase diagram.** Each panel shows one marker over the 21 × 21 grid of consolidation gain *g* (abscissa) and noise amplitude *σ* (ordinate, logarithmic). Circles mark the four quadrant centres assigned by the hypothesis. Note that dwell time (**b**), transition rate (**c**), minor-state occupancy (**d**) and dominant-state occupancy (**e**) all attain their most "rigid" values at *g* = 0, while coupling concentration (**f**) rises monotonically with *g*.

**Figure 4. Dynamical signatures of the five operating points.** (**a**) Marker profiles expressed as deviations from the neurotypical operating point in units of its standard deviation; error bars are standard errors over 20 realisations. (**b**) Euclidean distance between group centroids in the 22-dimensional standardised marker space. (**c**) The same distances ranked, with pairs that are not significant after FDR control shown in red; all ten pairs are significant.

**Figure 5. The negative result on the consolidation axis survives every implementation tested.** (**a**) Mean dwell time against consolidation gain for the eight control implementations (homeostasis off; four consolidation timescales; three coherence timescales). (**b**) Spearman correlation of dwell time with *g* for each implementation; all are negative with *P* < 10^−9^. (**c**) Coupling concentration against *g* for the same implementations, confirming that the landscape is being sculpted in every case.

**Figure 6. Validation and sensitivity.** (**a**) Every literature target evaluated marker by marker, coloured by whether the model agrees, with the source study shown at the right. (**b**) Morris elementary-effects screening: mean absolute effect *μ** of each nuisance parameter on each output. (**c**) Minor-state occupancy of each operating point under ±25 % perturbation of every nuisance parameter; the ordering is preserved throughout.

**Figure 7. Where the clinical signatures actually live, and how spectral-spatial specificity resolves the autistic–parkinsonian overlap.** (**a**–**c**) Fraction of each syndrome's four directional criteria satisfied across the plane of coupling budget *K* and conduction velocity *v*, at *g* = 0 and *σ* = 0.4. (**d**) Pairwise Jaccard overlap between the unconstrained four-criterion signatures. (**e**) Number of settings satisfying each four-criterion signature (blue), doing so exclusively before resolution (orange), and doing so exclusively after incorporating spectral-spatial specificity (green; 100 % exclusivity, Jaccard = 0.000 across all pairs). (**f**) Spectral resolution of the searched settings in the relative alpha versus beta power plane, showing the complete separation between delay-pulled alpha-preserving autistic regimes (orange, below the dashed neurotypical beta threshold) and beta-locked parkinsonian regimes (red), with the neurotypical working point starred.

**Supplementary Figure S1.** Metastability over the full calibration grid, separately for each node frequency.

**Supplementary Figure S2.** Repertoire markers of the five operating points as a function of the dictionary size *k* from 3 to 8.

**Supplementary Figure S3.** Prior-predictive distributions of the anchored quantities over 200 Latin-hypercube draws from the full parameter space, with the published target intervals shaded.

**Supplementary Figure S4.** Relative alpha against relative beta power for all realisations of the five operating points.

**Supplementary Figure S5.** Locus sweep: sensorimotor beta power, dominant-state occupancy and dwell time as a function of the size of the consolidation locus, for the anatomical sensorimotor core and for size-matched random loci.
