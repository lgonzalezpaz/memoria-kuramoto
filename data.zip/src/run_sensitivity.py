#!/usr/bin/env python3
"""Stage 3 - sensitivity, robustness and prior-predictive checks.

(a) Morris elementary-effects screening of the five nuisance parameters
    (f0, v, K, tau_r, tau_c) at the neurotypical operating point.
(b) Regime-ordering robustness: are the qualitative contrasts between the four
    operating points preserved when every nuisance parameter is perturbed by
    +/-25 %?
(c) Prior-predictive check: Latin-hypercube sample of the full parameter space,
    used to verify that the empirical target intervals lie inside the model's
    prior-predictive support (i.e. the match is a capability of the model, not
    an artefact of tuning).

Outputs: results/morris.csv, results/robustness.csv, results/prior_predictive.csv
"""
from __future__ import annotations

import json, pathlib, sys
import numpy as np
import pandas as pd
from concurrent.futures import ProcessPoolExecutor

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import model as M
import observables as O

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
with open(RES / "working_point.json", encoding="utf-8") as _fh:
    WP = json.load(_fh)
F0, V, K = WP["f0_hz"], WP["v_ms"], WP["K"]
K_STATES = 5
T_REC = 12.0

REGIMES = {"NT": (1.0, 0.4, False), "ASD": (16.0, 0.4, False),
           "AD": (1.0, 6.0, False), "PD_hyp": (16.0, 6.0, False),
           "PD_locus": (16.0, 0.4, True)}

# nuisance factors and their screening ranges (literature-admissible)
FACTORS = ["f0_hz", "v_ms", "K", "tau_r_s", "tau_c_s"]
LOW = np.array([15.0, 8.0, 110.0, 0.030, 0.300])
HIGH = np.array([25.0, 18.0, 220.0, 0.080, 0.800])
BASE = np.array([F0, V, K, M.TAU_R_S, M.TAU_C_S])

OUTPUTS = ["R_mean", "metastability", "dwell_mean_ms", "transition_rate_hz",
           "repertoire_entropy", "minor_occupancy", "parasitic_index",
           "burst_mean_ms", "burst_time_frac", "carrier_hz", "pow_alpha",
           "pow_beta", "theta_alpha_ratio", "C_conc", "sc_fc_r"]

_C = None
_KM = None
_THR = None


_IDX = None
_THRS = None


def _init():
    global _C, _KM, _THR, _THRS, _IDX
    _C = M.load_connectome(ROOT / "data")
    _IDX = M.subnetwork_indices(_C)
    d = np.load(RES / "state_dictionary.npz")
    _KM = d["centroids"]
    _THR = float(d["burst_thresh"])
    _THRS = float(d["burst_thresh_sub"])


def evaluate(theta, g, sigma, seed, focal=False):
    f0, v, k, tr, tc = theta
    ed = M.build_edges(_C, v_ms=v)
    if focal:
        ed = M.restrict_motif(ed, _C, _IDX)
    om = M.intrinsic_frequencies(_C["n"], f0=f0)
    out = M.simulate(ed, om, K=k, g=g, sigma=sigma, tau_r=tr, tau_c=tc,
                     t_rec=T_REC, seed=seed, n=_C["n"], sub_idx=_IDX)
    m = O.all_markers(out, _KM, K_STATES, W=_C["W"], sigma=sigma,
                      burst_thresh=_THR, f0_hz=f0)
    m["sub_R_mean"] = float(np.mean(out["R_sub"]))
    for kk, vv in O.relative_band_power(out["sig_sub"]).items():
        m["sub_" + kk] = vv
    for kk, vv in O.sync_bursts(out["R_sub"], thresh=_THRS).items():
        m["sub_" + kk] = vv
    return m


# ---------------------------------------------------------------- Morris ----
def morris_design(r=8, p=8, seed=0):
    """Standard Morris one-at-a-time trajectory design on the unit hypercube."""
    rng = np.random.default_rng(seed)
    k = len(FACTORS)
    delta = p / (2.0 * (p - 1))
    levels = np.arange(p) / (p - 1.0)
    traj = []
    for _ in range(r):
        x = rng.choice(levels[: p // 2], size=k)
        order = rng.permutation(k)
        signs = rng.choice([-1.0, 1.0], size=k)
        pts = [x.copy()]
        cur = x.copy()
        for idx in order:
            cur = cur.copy()
            cur[idx] = np.clip(cur[idx] + signs[idx] * delta, 0.0, 1.0)
            pts.append(cur.copy())
        traj.append((np.array(pts), order))
    return traj, delta


def _morris_job(a):
    i, j, u = a
    theta = LOW + u * (HIGH - LOW)
    m = evaluate(theta, 1.0, 0.4, seed=9000 + 17 * i + j)
    m.update(traj=i, step=j, **{f: float(t) for f, t in zip(FACTORS, theta)})
    return m


def morris(r=8):
    traj, delta = morris_design(r=r)
    jobs = [(i, j, u) for i, (pts, _) in enumerate(traj) for j, u in enumerate(pts)]
    with ProcessPoolExecutor(2, initializer=_init) as ex:
        rows = list(ex.map(_morris_job, jobs, chunksize=2))
    df = pd.DataFrame(rows)
    df.to_csv(RES / "morris_raw.csv", index=False)

    out = []
    for i, (pts, order) in enumerate(traj):
        sub = df[df.traj == i].sort_values("step")
        for step, idx in enumerate(order):
            a, b = sub.iloc[step], sub.iloc[step + 1]
            sgn = np.sign(b[FACTORS[idx]] - a[FACTORS[idx]]) or 1.0
            for o in OUTPUTS:
                scale = df[o].std(ddof=1)
                if not np.isfinite(scale) or scale == 0:
                    continue
                ee = (b[o] - a[o]) / (sgn * delta) / scale
                out.append(dict(traj=i, factor=FACTORS[idx], output=o, ee=float(ee)))
    ee = pd.DataFrame(out)
    res = (ee.groupby(["output", "factor"])["ee"]
             .agg(mu=lambda s: s.mean(), mu_star=lambda s: s.abs().mean(),
                  sigma_ee=lambda s: s.std(ddof=1)).reset_index())
    res.to_csv(RES / "morris.csv", index=False)
    return res


# ----------------------------------------------------------- robustness -----
def _rob_job(a):
    tag, theta, name, g, s, f, seed = a
    m = evaluate(np.asarray(theta, float), g, s, seed=seed, focal=f)
    m.update(setting=tag, regime=name)
    return m


def robustness():
    settings = {"baseline": BASE.copy()}
    for i, f in enumerate(FACTORS):
        for sgn, lab in ((-0.25, "lo"), (0.25, "hi")):
            t = BASE.copy()
            t[i] = t[i] * (1.0 + sgn)
            settings[f"{f}_{lab}"] = t
    jobs = [(tag, t, n, g, s, f, 11000 + 13 * ti + j)
            for ti, (tag, t) in enumerate(settings.items())
            for n, (g, s, f) in REGIMES.items() for j in range(3)]
    with ProcessPoolExecutor(2, initializer=_init) as ex:
        rows = list(ex.map(_rob_job, jobs, chunksize=2))
    df = pd.DataFrame(rows)
    df.to_csv(RES / "robustness.csv", index=False)
    return df


# ------------------------------------------------------ prior predictive ----
def _pp_job(a):
    i, u = a
    theta = LOW + u[:5] * (HIGH - LOW)
    g = 0.0 + u[5] * 32.0
    s = 0.05 * (8.0 / 0.05) ** u[6]
    m = evaluate(theta, g, s, seed=21000 + i)
    m.update(draw=i, g=g, sigma=s, **{f: float(t) for f, t in zip(FACTORS, theta)})
    return m


def prior_predictive(n=200, seed=3):
    rng = np.random.default_rng(seed)
    d = 7
    U = (rng.permuted(np.tile(np.arange(n), (d, 1)), axis=1).T + rng.random((n, d))) / n
    with ProcessPoolExecutor(2, initializer=_init) as ex:
        rows = list(ex.map(_pp_job, list(enumerate(U)), chunksize=4))
    df = pd.DataFrame(rows)
    df.to_csv(RES / "prior_predictive.csv", index=False)
    return df


def main():
    print("[a] Morris screening ...", flush=True)
    r = morris()
    piv = r.pivot(index="output", columns="factor", values="mu_star")
    print(piv.to_string(float_format=lambda x: f"{x:6.3f}"))
    print("\n[b] regime-ordering robustness ...", flush=True)
    rb = robustness()
    print(rb.groupby(["setting", "regime"])[["dwell_mean_ms", "metastability",
                                             "minor_occupancy"]].mean()
          .to_string(float_format=lambda x: f"{x:8.3f}"))
    print("\n[c] prior-predictive ...", flush=True)
    pp = prior_predictive()
    print(pp[OUTPUTS].describe().T.to_string(float_format=lambda x: f"{x:9.3f}"))
    print("done")


if __name__ == "__main__":
    main()
