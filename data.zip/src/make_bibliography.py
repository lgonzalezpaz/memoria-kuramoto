#!/usr/bin/env python3
"""Build the reference list directly from Crossref metadata.

Every entry is fetched by DOI so that no bibliographic field is ever typed from
memory. Entries that have no DOI (a monograph, a workshop paper) are listed in
MANUAL with their details and are flagged as such.

Then resolve the [[key]] markers in docs/manuscript_src.md into Nature-style
superscript numbers in order of first appearance, and write the final
manuscript with a numbered reference list.

Outputs: results/bibliography.json, docs/manuscript.md
"""
from __future__ import annotations

import json, pathlib, re, sys, time, urllib.parse, urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
UA = "KuramotoMemoryBib/1.0 (mailto:lgonzalezpaz@gmail.com)"

DOIS = {
    "kuramoto1975": None,
    "acebron2005": "10.1103/revmodphys.77.137",
    "breakspear2017": "10.1038/nn.4497",
    "deco2011": "10.1038/nrn2961",
    "tognoli2014": "10.1016/j.neuron.2013.12.022",
    "kelso2012": "10.1098/rstb.2011.0351",
    "shanahan2010": "10.1063/1.3305451",
    "hellyer2014": "10.1523/jneurosci.1853-13.2014",
    "hellyer2016": "10.1016/j.neuroimage.2015.08.069",
    "cabral2011": "10.1016/j.neuroimage.2011.04.010",
    "cabral2017": "10.1038/s41598-017-05425-7",
    "cabral2022": "10.1038/s42005-022-00950-y",
    "deco2017": "10.1038/s41598-017-03073-5",
    "ghosh2008": "10.1371/journal.pcbi.1000196",
    "vasa2015": "10.1016/j.neuroimage.2015.05.042",
    "alderson2018": "10.1016/j.neuroimage.2018.08.033",
    "demirtas2017": "10.1016/j.nicl.2017.08.006",
    "jirsa2017": "10.1016/j.neuroimage.2016.04.049",
    "sanzleon2013": "10.3389/fninf.2013.00010",
    "hagmann2008": "10.1371/journal.pbio.0060159",
    "desikan2006": "10.1016/j.neuroimage.2006.01.021",
    "honey2009": "10.1073/pnas.0811168106",
    "caminiti2013": "10.1523/jneurosci.0761-13.2013",
    "seliger2002": "10.1103/physreve.65.041906",
    "michel2018": "10.1016/j.neuroimage.2017.11.062",
    "khanna2015": "10.1016/j.neubiorev.2014.12.010",
    "dcroz2019": "10.3389/fnhum.2019.00173",
    "kalburgi2020": "10.3389/fnhum.2020.00288",
    "watanabe2017": "10.1038/ncomms16048",
    "ezaki2017": "10.1098/rsta.2016.0287",
    "supekar2013": "10.1016/j.celrep.2013.10.001",
    "uddin2013": "10.1001/jamapsychiatry.2013.104",
    "just2004": "10.1093/brain/awh199",
    "rubenstein2003": "10.1034/j.1601-183x.2003.00037.x",
    "koenig2005": "10.1016/j.neurobiolaging.2004.03.008",
    "zhang2021": "10.3389/fnagi.2021.631587",
    "delbeuck2003": "10.1023/a:1023832305702",
    "hammond2007": "10.1016/j.tins.2007.05.004",
    "kuhn2006": "10.1111/j.1460-9568.2006.04717.x",
    "tinkhauser2017": "10.1093/brain/awx252",
    "little2013": "10.1002/ana.23951",
    "rubchinsky2011": "10.1007/s11071-011-0223-z",
    "niebur1991": "10.1103/physrevlett.67.2753",
    "stikov2015": "10.1016/j.neuroimage.2015.05.023",
    "donoghue2020": "10.1038/s41593-020-00744-x",
    "fiorenzato2019": "10.1093/brain/awz192",
    "lord2019": "10.1016/j.neuroimage.2019.05.060",
    "hancock2022": "10.1098/rsif.2022.0214",
    "gollo2015": "10.1098/rstb.2014.0165",
    "wang2021": "10.1073/pnas.2022288118",
    "rubinov2010": "10.1016/j.neuroimage.2009.10.003",
    "stam2007": "10.1002/hbm.20346",
    "lachaux1999": "10.1002/(SICI)1097-0193(1999)8:4<194::AID-HBM4>3.0.CO;2-C",
    "benjamini1995": "10.1111/j.2517-6161.1995.tb02031.x",
    "morris1991": "10.1080/00401706.1991.10484804",
    "saltelli2010": "10.1016/j.cpc.2009.09.018",
    "kramers1940": "10.1016/s0031-8914(40)90098-2",
    "harris2020": "10.1038/s41586-020-2649-2",
    "virtanen2020": "10.1038/s41592-019-0686-2",
    "hunter2007": "10.1109/mcse.2007.55",
    "lam2015": "10.1145/2833157.2833162",
    "pedregosa2011": None,
}

MANUAL = {
    "kuramoto1975": "Kuramoto, Y. Self-entrainment of a population of coupled "
                    "non-linear oscillators. In: Araki, H. (ed.) International "
                    "Symposium on Mathematical Problems in Theoretical Physics. "
                    "Lecture Notes in Physics vol. 39, 420-422 (Springer, Berlin, 1975).",
    "pedregosa2011": "Pedregosa, F. et al. Scikit-learn: machine learning in Python. "
                     "J. Mach. Learn. Res. 12, 2825-2830 (2011).",
}


def fetch(doi):
    url = "https://api.crossref.org/works/" + urllib.parse.quote(doi)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.load(r)["message"]


def authors(m, limit=6):
    au = m.get("author") or []
    out = []
    for a in au:
        fam = a.get("family", "").strip()
        giv = a.get("given", "") or ""
        ini = " ".join(p[0].upper() + "." for p in re.split(r"[\s\-]+", giv) if p)
        out.append(f"{fam}, {ini}".strip().rstrip(","))
    if not out:
        return ""
    if len(out) > limit:
        return ", ".join(out[:limit]) + " et al."
    return ", ".join(out)


def unescape(s):
    return (s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
             .replace("<i>", "").replace("</i>", ""))


def format_entry(m):
    t = unescape(m.get("title", [""])[0]).rstrip(".")
    j = unescape((m.get("container-title") or [""])[0])
    vol = m.get("volume", "")
    pg = m.get("page", "")
    yr = m.get("issued", {}).get("date-parts", [[None]])[0][0]
    doi = m.get("DOI", "")
    s = f"{authors(m)} {t}. "
    if j:
        s += f"{j} "
    if vol:
        s += f"{vol}, " if pg else f"{vol} "
    if pg:
        s += f"{pg} "
    s += f"({yr})."
    if doi:
        s += f" https://doi.org/{doi}"
    return re.sub(r"\s+", " ", s).strip()


def build(cache=ROOT / "results" / "bibliography.json"):
    if cache.exists():
        with open(cache, encoding="utf-8") as _fh:
            bib = json.load(_fh)
    else:
        bib = {}
    for key, doi in DOIS.items():
        if key in bib and (bib[key].get("doi") or "").lower() == (doi or "").lower():
            continue
        if doi is None:
            bib[key] = {"text": MANUAL[key], "doi": None}
            continue
        try:
            m = fetch(doi)
            bib[key] = {"text": format_entry(m), "doi": m.get("DOI")}
            print("  ok", key)
        except Exception as e:
            print("  !! FAILED", key, doi, type(e).__name__, e)
            bib[key] = {"text": f"[UNRESOLVED {key} {doi}]", "doi": doi}
        time.sleep(0.12)
    cache.parent.mkdir(exist_ok=True)
    with open(cache, "w", encoding="utf-8") as _fh:
        json.dump(bib, _fh, indent=1, ensure_ascii=False)
    return bib


SUP = str.maketrans("0123456789,-", "⁰¹²³⁴⁵⁶"
                                    "⁷⁸⁹˒⁻")


def resolve(src=ROOT / "docs" / "manuscript_src.md",
            dst=ROOT / "docs" / "manuscript.md"):
    bib = build()
    text = src.read_text(encoding="utf-8")
    order, missing = [], set()

    def repl(mo):
        keys = [k.strip() for k in mo.group(1).split(",")]
        nums = []
        for k in keys:
            if k not in bib:
                missing.add(k)
                return mo.group(0)
            if k not in order:
                order.append(k)
            nums.append(order.index(k) + 1)
        nums = sorted(set(nums))
        # collapse runs
        parts, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
                j += 1
            parts.append(str(nums[i]) if j == i else f"{nums[i]}-{nums[j]}")
            i = j + 1
        return "^" + ",".join(parts) + "^"

    out = re.sub(r"\[\[([^\]]+)\]\]", repl, text)
    refs = "\n".join(f"{i+1}. {bib[k]['text']}" for i, k in enumerate(order))
    out = out.replace("<!--REFERENCES-->", refs)
    dst.write_text(out, encoding="utf-8")
    print(f"resolved {len(order)} references -> {dst}")
    if missing:
        print("  !! MISSING KEYS:", sorted(missing))
    unresolved = [k for k in order if bib[k]["text"].startswith("[UNRESOLVED")]
    if unresolved:
        print("  !! UNRESOLVED:", unresolved)
    return order


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "build":
        build()
    else:
        resolve()
