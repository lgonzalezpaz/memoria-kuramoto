"""
Dynamical observables and their mapping onto empirically measurable markers.

All quantities are defined so that each one has a direct counterpart in the
published human literature (see Table 2 of the manuscript).
"""
from __future__ import annotations

import numpy as np
from scipy import signal as sps
from scipy.stats import entropy as shannon

FS_FAST = 500.0
FS_STATE = 200.0
# Bands of the *synchronization-envelope* (amplitude-modulation) spectrum.
# In this framework the EEG/MEG-observable slow rhythms are the metastable
# oscillatory modes of the order parameter, not the carrier (Cabral et al. 2022).
BANDS = {"delta": (1.0, 4.0), "theta": (4.0, 8.0), "alpha": (8.0, 13.0),
         "beta": (13.0, 30.0)}


# ---------------------------------------------------------------- synchrony --
def synchrony(R):
    """Mean synchrony and metastability (Shanahan 2010; Hellyer 2014)."""
    return float(np.mean(R)), float(np.std(R, ddof=1))


# ------------------------------------------------------------------ spectra --
def carrier_frequency(sig, fs=FS_FAST):
    """Collective (carrier) frequency of the global field."""
    f, p = sps.welch(sig - sig.mean(), fs=fs, nperseg=int(4 * fs),
                     noverlap=int(2 * fs), detrend="constant")
    m = (f >= 1.0) & (f <= 100.0)
    return float(f[m][np.argmax(p[m])])


RAW_BANDS = {"theta": (4.0, 8.0), "alpha": (8.0, 13.0),
             "beta": (13.0, 30.0), "gamma": (30.0, 48.0)}


def relative_band_power(sig, fs=FS_FAST):
    """Relative power of the global field in classical EEG bands (1-48 Hz).

    At the calibrated working point the collective carrier lies at ~14 Hz, so
    these bands are directly comparable with scalp-EEG band ratios.
    """
    f, p = sps.welch(sig - sig.mean(), fs=fs, nperseg=int(4 * fs),
                     noverlap=int(2 * fs), detrend="constant")
    m0 = (f >= 1.0) & (f <= 48.0)
    tot = np.trapezoid(p[m0], f[m0])
    out = {}
    for name, (lo, hi) in RAW_BANDS.items():
        m = (f >= lo) & (f <= hi)
        out[f"pow_{name}"] = float(np.trapezoid(p[m], f[m]) / tot) if tot > 0 else np.nan
    out["theta_alpha_ratio"] = float(out["pow_theta"] / out["pow_alpha"]) \
        if out["pow_alpha"] > 0 else np.nan
    return out


def modulation_spectrum(R, fs=FS_FAST):
    """Relative power of the synchronization envelope R(t) in classical bands."""
    f, p = sps.welch(R - R.mean(), fs=fs, nperseg=int(4 * fs),
                     noverlap=int(2 * fs), detrend="constant")
    m0 = (f >= 1.0) & (f <= 30.0)
    tot = np.trapezoid(p[m0], f[m0])
    out = {}
    for name, (lo, hi) in BANDS.items():
        m = (f >= lo) & (f <= hi)
        out[f"mod_{name}"] = float(np.trapezoid(p[m], f[m]) / tot) if tot > 0 else np.nan
    out["mod_peak_hz"] = float(f[m0][np.argmax(p[m0])])
    return out


def sync_bursts(R, fs=FS_FAST, thresh=None, min_ms=50.0):
    """Synchronization-burst statistics.

    Direct model analogue of the amplitude-envelope beta bursts quantified in
    the parkinsonian basal ganglia by Tinkhauser et al. (2017): episodes during
    which collective synchrony exceeds a fixed reference threshold.
    """
    env = np.asarray(R, dtype=float)
    thr = np.percentile(env, 75) if thresh is None else thresh
    above = env > thr
    d = np.diff(above.astype(int))
    starts = np.flatnonzero(d == 1) + 1
    ends = np.flatnonzero(d == -1) + 1
    if above[0]:
        starts = np.r_[0, starts]
    if above[-1]:
        ends = np.r_[ends, len(above)]
    dur = (ends - starts) / fs * 1e3
    dur = dur[dur >= min_ms]
    return dict(burst_mean_ms=float(dur.mean()) if dur.size else 0.0,
                burst_p_long=float((dur > 300.0).mean()) if dur.size else 0.0,
                burst_time_frac=float(above.mean()),
                burst_thresh=float(thr))


# ----------------------------------------------------- attractor repertoire --
def normalise_rows(U):
    nrm = np.linalg.norm(U, axis=1, keepdims=True)
    nrm[nrm == 0] = 1.0
    return U / nrm


def fit_state_dictionary(U_pool, k=5, seed=0, n_init=12):
    """k-means dictionary of phase-locking configurations (LEiDA-style)."""
    from sklearn.cluster import KMeans
    km = KMeans(n_clusters=k, n_init=n_init, random_state=seed)
    km.fit(normalise_rows(U_pool))
    return km


def assign_states(U, dictionary):
    """Nearest-centroid assignment against a fixed dictionary.

    `dictionary` may be a fitted KMeans object or a (k, n) array of centroids.
    Implemented explicitly so that a dictionary saved to disk can be reused
    without re-fitting, guaranteeing a common state basis across conditions.
    """
    cent = getattr(dictionary, "cluster_centers_", dictionary)
    cent = np.asarray(cent, dtype=float)
    X = normalise_rows(U)
    d2 = (X ** 2).sum(1)[:, None] - 2.0 * X @ cent.T + (cent ** 2).sum(1)[None, :]
    return np.argmin(d2, axis=1)


def repertoire_metrics(labels, k, fs=FS_STATE):
    """Occupancy, dwell time, transition rate and entropies of the repertoire."""
    occ = np.bincount(labels, minlength=k).astype(float)
    occ /= occ.sum()
    # dwell times
    ch = np.flatnonzero(np.diff(labels) != 0) + 1
    seg = np.diff(np.r_[0, ch, len(labels)])
    dwell_ms = seg / fs * 1e3
    n_trans = len(ch)
    # transition matrix (excluding self-loops, row-normalised)
    T = np.zeros((k, k))
    for a, b in zip(labels[:-1], labels[1:]):
        if a != b:
            T[a, b] += 1
    rows = T.sum(axis=1)
    H_rows = np.zeros(k)
    for s in range(k):
        if rows[s] > 0:
            H_rows[s] = shannon(T[s] / rows[s], base=2)
    denom = np.log2(k - 1) if k > 2 else 1.0
    denom_k = np.log2(k) if k > 1 else 1.0
    order = np.argsort(occ)[::-1]
    return dict(
        occupancy=occ,
        dwell_mean_ms=float(dwell_ms.mean()),
        dwell_median_ms=float(np.median(dwell_ms)),
        transition_rate_hz=float(n_trans / (len(labels) / fs)),
        transition_entropy=float(np.sum(occ * H_rows) / denom),
        repertoire_entropy=float(shannon(occ, base=2) / denom_k),
        parasitic_index=float(occ.max()),
        minor_occupancy=float(occ[order[2:]].sum()),
        major_occupancy=float(occ[order[:2]].sum()),
    )


def effective_barrier(dwell_ms, sigma, tau0_ms):
    """Kramers-type effective barrier height implied by the observed dwell time.

    For escape over a barrier Delta-U driven by noise of intensity D = sigma^2/2,
    the mean first-passage time obeys  T ~ tau0 * exp(Delta-U / D), hence
    Delta-U = (sigma^2 / 2) * ln(T / tau0).  Dimensionless (units of sigma^2 s).
    """
    if not np.isfinite(dwell_ms) or dwell_ms <= 0 or tau0_ms <= 0:
        return np.nan
    return float(0.5 * sigma ** 2 * np.log(max(dwell_ms, 1e-9) / tau0_ms))


# ------------------------------------------------- structure-function match --
def plv_matrix(U):
    """Phase-locking proxy from the recorded configuration vectors."""
    X = U - U.mean(axis=0, keepdims=True)
    sd = X.std(axis=0, ddof=1)
    sd[sd == 0] = 1.0
    return (X / sd).T @ (X / sd) / (X.shape[0] - 1)


def sc_fc_correlation(FC, W):
    m = (W > 0) & ~np.eye(W.shape[0], dtype=bool)
    from scipy.stats import pearsonr, spearmanr
    r, pr = pearsonr(W[m], FC[m])
    rho, pp = spearmanr(W[m], FC[m])
    return dict(sc_fc_r=float(r), sc_fc_p=float(pr),
                sc_fc_rho=float(rho), sc_fc_rho_p=float(pp))


# ---------------------------------------------------------------- bundling ---
def all_markers(out, km, k, W=None, sigma=None, burst_thresh=None, f0_hz=20.0):
    sig, R, U = out["sig"], out["R"], out["U"]
    Rm, Rsd = synchrony(R)
    m = dict(R_mean=Rm, metastability=Rsd, C_mean=float(out["Cbar"].mean()),
             C_conc=float(out["Cconc"].mean()),
             carrier_hz=carrier_frequency(sig))
    m.update(relative_band_power(sig))
    m.update(modulation_spectrum(R))
    m.update(sync_bursts(R, thresh=burst_thresh))
    lab = assign_states(U, km)
    rep = repertoire_metrics(lab, k)
    occ = rep.pop("occupancy")
    m.update(rep)
    for s in range(k):
        m[f"occ_{s}"] = float(occ[s])
    if sigma is not None:
        m["barrier_eff"] = effective_barrier(m["dwell_mean_ms"], sigma, 1000.0 / f0_hz)
    if W is not None:
        m.update(sc_fc_correlation(plv_matrix(U), W))
    return m
