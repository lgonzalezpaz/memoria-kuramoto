#!/usr/bin/env python3
"""Stage 4 - confrontation of the model with the published human literature.

Reads data/empirical_targets.csv (one row per published target, each carrying a
DOI) and the stage-2 outputs, and evaluates three kinds of target:

  interval    : does the model's bootstrap 95 % CI overlap the published interval?
  point       : model value vs published value, with relative error
  direction_* : does the model contrast against NT have the published sign, and
                is it significant after BH-FDR control?

Clinical labels are mapped onto model operating points; "parkinson" is evaluated
against BOTH the hypothesis quadrant (PD_hyp) and the focal-locus point
(PD_locus), so that the two competing accounts are scored separately.

A binomial test against chance is applied to the family of directional
predictions of each operating point.

Outputs: results/validation.csv, results/validation_summary.json
"""
from __future__ import annotations

import json, pathlib
import numpy as np
import pandas as pd
from scipy import stats

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
N_BOOT = 10000

CLINICAL = {"healthy": ["NT"], "neurotypical": ["NT"], "autism": ["ASD"],
            "alzheimer": ["AD"], "parkinson": ["PD_hyp", "PD_locus"]}


def boot_mean_ci(x, n=N_BOOT, seed=7):
    rng = np.random.default_rng(seed)
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if not len(x):
        return np.nan, np.nan, np.nan
    b = np.array([x[rng.integers(0, len(x), len(x))].mean() for _ in range(n)])
    return float(x.mean()), float(np.percentile(b, 2.5)), float(np.percentile(b, 97.5))


def main():
    tg = pd.read_csv(ROOT / "data" / "empirical_targets.csv")
    runs = pd.read_csv(RES / "regime_runs.csv")
    stat = pd.read_csv(RES / "regime_stats.csv")

    rows = []
    for _, t in tg.iterrows():
        mk = t["marker"]
        if mk not in runs.columns:
            continue
        for pop in CLINICAL.get(t["population"], [t["population"]]):
            sub = runs[runs.regime == pop]
            if not len(sub):
                continue
            rec = dict(marker=mk, regime=pop, clinical=t["population"],
                       target_type=t["target_type"], source=t["source_short"],
                       doi=t["source_doi"])
            tt = t["target_type"]

            if tt == "interval":
                m, lo, hi = boot_mean_ci(sub[mk])
                ok = bool((hi >= t["target_low"]) and (lo <= t["target_high"]))
                rec.update(model=m, model_ci_lo=lo, model_ci_hi=hi,
                           target=f"[{t['target_low']:g}, {t['target_high']:g}]",
                           agree=ok, significant=np.nan,
                           detail="CI overlaps interval" if ok else "CI outside interval")

            elif tt == "point":
                m, lo, hi = boot_mean_ci(sub[mk])
                tp = float(t["target_point"])
                rel = (m - tp) / tp if tp else np.nan
                ok = bool((lo <= tp <= hi) or abs(rel) <= 0.50)
                rec.update(model=m, model_ci_lo=lo, model_ci_hi=hi, target=tp,
                           rel_error=float(rel), agree=ok, significant=np.nan,
                           detail=f"relative error {rel:+.1%}")

            else:
                want = 1.0 if tt.endswith("increase") else -1.0
                srow = stat[(stat.contrast == f"{pop}_vs_NT") & (stat.marker == mk)]
                if not len(srow):
                    continue
                s = srow.iloc[0]
                sig = bool(s["q_bh"] < 0.05)
                ok = bool(np.sign(s["diff"]) == want)
                rec.update(model=float(s["mean_regime"]), control=float(s["mean_control"]),
                           model_ci_lo=float(s["ci_lo"]), model_ci_hi=float(s["ci_hi"]),
                           target=("increase" if want > 0 else "decrease"),
                           diff=float(s["diff"]), hedges_g=float(s["hedges_g"]),
                           p_perm=float(s["p_perm"]), q_bh=float(s["q_bh"]),
                           significant=sig, agree=ok,
                           detail=("correct sign" if ok else "WRONG SIGN")
                                  + (", q<0.05" if sig else ", n.s."))
            rows.append(rec)

    v = pd.DataFrame(rows)
    v.to_csv(RES / "validation.csv", index=False)

    summ = {"n_targets": int(len(v)), "n_agree": int(v.agree.sum())}
    for pop in ["NT", "ASD", "AD", "PD_hyp", "PD_locus"]:
        d = v[(v.regime == pop) & v.target_type.str.startswith("direction")]
        if not len(d):
            continue
        n_ok, n = int(d.agree.sum()), int(len(d))
        b = stats.binomtest(n_ok, n, 0.5, alternative="greater")
        summ[pop] = dict(n_directional=n, n_agree=n_ok,
                         n_agree_significant=int((d.agree & d.significant.fillna(False)).sum()),
                         binomial_p=float(b.pvalue))
    iv = v[v.target_type.isin(["interval", "point"])]
    summ["n_quantitative"] = int(len(iv))
    summ["n_quantitative_agree"] = int(iv.agree.sum())
    with open(RES / "validation_summary.json", "w", encoding="utf-8") as fh:
        json.dump(summ, fh, indent=2)

    cols = [c for c in ["marker", "regime", "target_type", "target", "control",
                        "model", "model_ci_lo", "model_ci_hi", "hedges_g", "q_bh",
                        "agree", "detail", "source"] if c in v.columns]
    print(v[cols].to_string(index=False, float_format=lambda x: f"{x:9.4g}"))
    print("\n" + json.dumps(summ, indent=2))


if __name__ == "__main__":
    main()
