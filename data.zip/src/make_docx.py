#!/usr/bin/env python3
"""Convert docs/manuscript.md into a journal-ready .docx with the required styles.

Produces:
  docs/Manuscript.docx   - title block, abstract, body, tables, captions, references
  docs/Figures.docx      - all figures embedded at 600 dpi with their captions

Style: A4, 2.54 cm margins, single column, Times New Roman 12 pt black,
left-aligned, double-spaced body, blank line between paragraphs, 16 pt bold
title, 10-11 pt abstract, numbered centred equations, page numbers top right,
continuous line numbers in the left margin, 9.5 pt reference list.
"""
from __future__ import annotations

import pathlib, re, sys
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT, WD_BREAK
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "docs" / "manuscript.md"
OUT = ROOT / "docs" / "Manuscript.docx"
FIGOUT = ROOT / "docs" / "Figures.docx"
SERIF = "Times New Roman"
BODY_PT = 12.0

SUPMAP = {"⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
          "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9"}


# --------------------------------------------------------------- scaffolding --
def setup(doc, line_numbers=True):
    s = doc.sections[0]
    s.page_width, s.page_height = Cm(21.0), Cm(29.7)
    for a in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
        setattr(s, a, Cm(2.54))
    st = doc.styles["Normal"]
    st.font.name = SERIF
    st.font.size = Pt(BODY_PT)
    st.font.color.rgb = RGBColor(0, 0, 0)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), SERIF)
    pf = st.paragraph_format
    pf.line_spacing = 2.0
    pf.space_after = Pt(0)
    pf.first_line_indent = Pt(0)
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT

    if line_numbers:
        sectPr = s._sectPr
        ln = OxmlElement("w:lnNumType")
        ln.set(qn("w:countBy"), "1")
        ln.set(qn("w:restart"), "continuous")
        ln.set(qn("w:distance"), "360")
        sectPr.append(ln)

    hdr = s.header.paragraphs[0]
    hdr.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    _field(hdr, "PAGE", size=10)


def _field(par, instr, size=10):
    r = par.add_run()
    r.font.name = SERIF
    r.font.size = Pt(size)
    for tag, attr, txt in (("w:fldChar", "w:fldCharType", "begin"),
                           ("w:instrText", None, f" {instr} "),
                           ("w:fldChar", "w:fldCharType", "end")):
        e = OxmlElement(tag)
        if attr:
            e.set(qn(attr), txt)
        else:
            e.set(qn("xml:space"), "preserve")
            e.text = txt
        r._r.append(e)


# ------------------------------------------------------------- inline markup --
TOKEN = re.compile(r"(\*\*[^*]+\*\*|\*[^*]+\*|\^[^^]+\^|~[^~]+~|`[^`]+`)")


def add_runs(par, text, size=BODY_PT, italic_all=False, bold_all=False):
    text = text.replace("\\*", "\u0001")
    for part in TOKEN.split(text):
        if not part:
            continue
        p = part.replace("\u0001", "*")
        bold, ital, sup, sub, mono = bold_all, italic_all, False, False, False
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            p, bold = part[2:-2], True
        elif part.startswith("*") and part.endswith("*") and len(part) > 2:
            p, ital = part[1:-1], True
        elif part.startswith("^") and part.endswith("^") and len(part) > 2:
            p, sup = part[1:-1], True
        elif part.startswith("~") and part.endswith("~") and len(part) > 2:
            p, sub = part[1:-1], True
        elif part.startswith("`") and part.endswith("`") and len(part) > 2:
            p, mono = part[1:-1], True
        # nested emphasis inside sub/sup markers
        p = re.sub(r"\*([^*]+)\*", r"\1", p).replace("\u0001", "*")
        r = par.add_run(p)
        r.font.name = "Consolas" if mono else SERIF
        r.font.size = Pt(size - 1 if mono else size)
        r.font.color.rgb = RGBColor(0, 0, 0)
        r.bold, r.italic = bold, ital
        r.font.superscript, r.font.subscript = sup, sub
        if sup or sub:
            r.font.size = Pt(size * 0.72)


def para(doc, text, size=BODY_PT, spacing=2.0, after=10, align=None,
         bold=False, italic=False, space_before=0):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = spacing
    pf.space_after = Pt(after)
    pf.space_before = Pt(space_before)
    if align is not None:
        pf.alignment = align
    add_runs(p, text, size=size, bold_all=bold, italic_all=italic)
    return p


def heading(doc, text, level):
    size = {1: 14.0, 2: 12.0}.get(level, 12.0)
    return para(doc, text, size=size, spacing=1.15, after=6, space_before=14,
                bold=True)


def equation(doc, body, number):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = 1.5
    pf.space_before = Pt(8)
    pf.space_after = Pt(8)
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf.tab_stops.add_tab_stop(Cm(7.5), WD_TAB_ALIGNMENT.CENTER)
    pf.tab_stops.add_tab_stop(Cm(15.9), WD_TAB_ALIGNMENT.RIGHT)
    p.add_run("\t")
    add_runs(p, body, size=BODY_PT)
    p.add_run("\t")
    add_runs(p, number, size=BODY_PT)
    return p


def table(doc, rows):
    hdr, body = rows[0], rows[1:]
    t = doc.add_table(rows=1, cols=len(hdr))
    t.style = "Table Grid"
    t.autofit = True
    for c, txt in zip(t.rows[0].cells, hdr):
        c.paragraphs[0].paragraph_format.line_spacing = 1.0
        c.paragraphs[0].paragraph_format.space_after = Pt(2)
        add_runs(c.paragraphs[0], txt, size=9.0, bold_all=True)
    for row in body:
        cells = t.add_row().cells
        for c, txt in zip(cells, row):
            c.paragraphs[0].paragraph_format.line_spacing = 1.0
            c.paragraphs[0].paragraph_format.space_after = Pt(2)
            add_runs(c.paragraphs[0], txt, size=9.0)
    doc.add_paragraph().paragraph_format.space_after = Pt(6)
    return t


# ------------------------------------------------------------------ builder --
def build(embed_figures=False, out_path=OUT):
    md = SRC.read_text(encoding="utf-8")
    md = re.sub(r"<!--.*?-->", "", md, flags=re.S)
    lines = md.split("\n")

    doc = Document()
    setup(doc)

    i = 0
    state = None
    tbl_buf = []
    while i < len(lines):
        ln = lines[i].rstrip()
        nxt = lines[i + 1].rstrip() if i + 1 < len(lines) else ""

        # table accumulation
        if ln.startswith("|"):
            cells = [c.strip() for c in ln.strip().strip("|").split("|")]
            if not re.fullmatch(r"[-: ]+", "".join(cells)):
                tbl_buf.append(cells)
            i += 1
            if not (i < len(lines) and lines[i].rstrip().startswith("|")):
                table(doc, tbl_buf)
                tbl_buf = []
            continue

        if not ln.strip():
            i += 1
            continue
        if ln.strip() == "---":
            i += 1
            continue

        if ln.startswith("# "):
            para(doc, ln[2:], size=16.0, spacing=1.15, after=12, bold=True)
            state = "title"
            i += 1
            continue
        if ln.startswith("## "):
            h = ln[3:]
            heading(doc, h, 1)
            state = "abstract" if h.lower().startswith("abstract") else (
                "refs" if h.lower().startswith("references") else "body")
            i += 1
            continue
        if ln.startswith("### "):
            heading(doc, ln[4:], 2)
            i += 1
            continue

        if ln.startswith("> "):
            body = ln[2:]
            m = re.search(r"\s{2,}(\(\d+\))\s*$", body)
            num = m.group(1) if m else ""
            if m:
                body = body[: m.start()]
            equation(doc, body.strip().rstrip(","), num)
            i += 1
            continue

        if state == "title":
            if "González" in ln or "Alvarado" in ln or re.match(r"^[A-Z]\.\s", ln):
                para(doc, ln, size=12.0, spacing=1.15, after=6)
            else:
                para(doc, ln, size=9.5, spacing=1.15, after=4)
            i += 1
            continue

        if state == "abstract":
            if ln.startswith("**Keywords:**"):
                para(doc, ln, size=9.5, spacing=1.15, after=12)
            else:
                para(doc, ln, size=10.5, spacing=1.15, after=10)
            i += 1
            continue

        if state == "refs":
            m = re.match(r"^(\d+)\.\s+(.*)$", ln)
            if m:
                p = para(doc, f"{m.group(1)}.\t{m.group(2)}", size=9.5,
                         spacing=1.15, after=4)
                p.paragraph_format.left_indent = Cm(0.9)
                p.paragraph_format.first_line_indent = Cm(-0.9)
                i += 1
                continue

        if ln.startswith("**[") or ln.startswith("**Figure") or ln.startswith("**Table") \
                or ln.startswith("**Supplementary"):
            if embed_figures and (ln.startswith("**Figure") or ln.startswith("**Supplementary Figure")):
                fig_map = {
                    "Figure 1.": "fig1_framework",
                    "Figure 2.": "fig2_calibration",
                    "Figure 3.": "fig3_phase_diagram",
                    "Figure 4.": "fig4_regimes",
                    "Figure 5.": "fig5_consolidation_controls",
                    "Figure 6.": "fig6_validation_sensitivity",
                    "Figure 7.": "fig7_signature_search",
                    "Supplementary Figure S1.": "figS1_calibration_full",
                    "Supplementary Figure S2.": "figS2_k_robustness",
                    "Supplementary Figure S3.": "figS3_prior_predictive",
                    "Supplementary Figure S4.": "figS4_spectral",
                    "Supplementary Figure S5.": "figS5_locus_sweep",
                }
                for prefix, stem in fig_map.items():
                    if ln.startswith(f"**{prefix}"):
                        png = ROOT / "figures" / f"{stem}.png"
                        if png.exists():
                            pf = doc.add_paragraph()
                            pf.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
                            pf.paragraph_format.space_before = Pt(8)
                            pf.paragraph_format.space_after = Pt(6)
                            pf.add_run().add_picture(str(png), width=Cm(15.9))
                        break
            para(doc, ln, size=10.5, spacing=1.15, after=10)
            i += 1
            continue

        para(doc, ln, after=10)
        i += 1

    out_path.parent.mkdir(exist_ok=True)
    doc.save(out_path)
    print("wrote", out_path)


def build_figures():
    caps = {}
    md = SRC.read_text(encoding="utf-8")
    for m in re.finditer(r"\*\*(Figure \d+|Supplementary Figure S\d+)\.(.*?)\*\*(.*?)(?=\n\n|\Z)",
                         md, flags=re.S):
        caps[m.group(1)] = (m.group(2).strip(), re.sub(r"\s+", " ", m.group(3)).strip())
    order = [("Figure 1", "fig1_framework"), ("Figure 2", "fig2_calibration"),
             ("Figure 3", "fig3_phase_diagram"), ("Figure 4", "fig4_regimes"),
             ("Figure 5", "fig5_consolidation_controls"),
             ("Figure 6", "fig6_validation_sensitivity"),
             ("Figure 7", "fig7_signature_search"),
             ("Supplementary Figure S1", "figS1_calibration_full"),
             ("Supplementary Figure S2", "figS2_k_robustness"),
             ("Supplementary Figure S3", "figS3_prior_predictive"),
             ("Supplementary Figure S4", "figS4_spectral"),
             ("Supplementary Figure S5", "figS5_locus_sweep")]
    doc = Document()
    setup(doc, line_numbers=False)
    para(doc, "Figures", size=14.0, spacing=1.15, after=12, bold=True)
    for name, stem in order:
        png = ROOT / "figures" / f"{stem}.png"
        if not png.exists():
            continue
        p = doc.add_paragraph()
        p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(6)
        p.add_run().add_picture(str(png), width=Cm(15.9))
        title, rest = caps.get(name, ("", ""))
        para(doc, f"**{name}. {title}** {rest}", size=10.0, spacing=1.15, after=18)
        doc.paragraphs[-1].runs[-1].add_break(WD_BREAK.PAGE)
    doc.save(FIGOUT)
    print("wrote", FIGOUT)


if __name__ == "__main__":
    build(embed_figures=False, out_path=OUT)
    build(embed_figures=True, out_path=ROOT / "docs" / "Manuscript_Complete_with_Figures.docx")
    build_figures()
