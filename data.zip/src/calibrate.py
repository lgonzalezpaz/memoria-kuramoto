#!/usr/bin/env python3
"""Stage 1 - calibration of the three nuisance parameters (f0, v, K).

The two hypothesis parameters (g, sigma) are NOT calibrated: they are the axes
of the phase diagram.  f0, v and K are fixed once, by the standard
working-point criterion (maximal metastability; Cabral 2011, Hellyer 2014,
Deco et al. 2017) subject to two independent empirical constraints:

  (i)  mean dwell time of phase-locking configurations in 60-120 ms
       (empirical EEG-microstate range; Khanna 2015, Michel & Koenig 2018)
  (ii) partial synchrony, 0.15 <= <R> <= 0.60

Search ranges are restricted to literature-admissible values:
  f0 in {10, 20, 40} Hz   (alpha / beta / gamma node rhythms)
  v  in {5, 6, 8, 12, 20} m/s   (human cortico-cortical conduction velocity)
  K  in {5, 10, 20, 40, 80}     (dimensionless global coupling)

Writes results/calibration_grid.csv and results/working_point.json
"""
from __future__ import annotations

import itertools, json, pathlib, sys
import numpy as np
import pandas as pd
from concurrent.futures import ProcessPoolExecutor

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import model as M
import observables as O

ROOT = pathlib.Path(__file__).resolve().parents[1]
F0S = [10.0, 20.0, 40.0]
VS = [5.0, 6.0, 8.0, 12.0, 20.0]
KS = [5.0, 10.0, 20.0, 40.0, 80.0, 120.0, 160.0, 220.0]
SIGMA_REF = 0.7          # reference noise level named in the source hypothesis
T_REC = 10.0
K_STATES = 5

_CONN = None


def conn():
    global _CONN
    if _CONN is None:
        _CONN = M.load_connectome(ROOT / "data")
    return _CONN


def one(args):
    f0, v, K = args
    c = conn()
    ed = M.build_edges(c, v_ms=v)
    om = M.intrinsic_frequencies(c["n"], f0=f0)
    out = M.simulate(ed, om, K=K, g=0.0, sigma=SIGMA_REF, t_rec=T_REC, seed=7, n=c["n"])
    km = O.fit_state_dictionary(out["U"], k=K_STATES, seed=0, n_init=6)
    rep = O.repertoire_metrics(O.assign_states(out["U"], km), K_STATES)
    Rm, Rsd = O.synchrony(out["R"])
    fc = O.sc_fc_correlation(O.plv_matrix(out["U"]), c["W"])
    return dict(f0_hz=f0, v_ms=v, K=K, R_mean=Rm, metastability=Rsd,
                dwell_mean_ms=rep["dwell_mean_ms"],
                transition_rate_hz=rep["transition_rate_hz"],
                repertoire_entropy=rep["repertoire_entropy"],
                carrier_hz=O.carrier_frequency(out["sig"]),
                mod_peak_hz=O.modulation_spectrum(out["R"])["mod_peak_hz"],
                sc_fc_r=fc["sc_fc_r"])


def main():
    grid = list(itertools.product(F0S, VS, KS))
    with ProcessPoolExecutor(2) as ex:
        rows = list(ex.map(one, grid, chunksize=2))
    df = pd.DataFrame(rows)
    (ROOT / "results").mkdir(exist_ok=True)
    df.to_csv(ROOT / "results" / "calibration_grid.csv", index=False)

    ok = df[(df.dwell_mean_ms.between(60, 120)) & (df.R_mean.between(0.15, 0.60))]
    pool = ok if len(ok) else df[df.R_mean.between(0.15, 0.60)]
    if not len(pool):
        pool = df
    best = pool.loc[pool.metastability.idxmax()]
    wp = {k: (float(v) if isinstance(v, (int, float, np.floating)) else v)
          for k, v in best.to_dict().items()}
    wp["n_admissible"] = int(len(ok))
    with open(ROOT / "results" / "working_point.json", "w", encoding="utf-8") as fh:
        json.dump(wp, fh, indent=2)

    cols = ["f0_hz", "v_ms", "K", "R_mean", "metastability", "dwell_mean_ms",
            "transition_rate_hz", "carrier_hz", "mod_peak_hz", "sc_fc_r"]
    print(df[cols].to_string(index=False, float_format=lambda x: f"{x:8.3f}"))
    print(f"\nadmissible (dwell 60-120 ms & 0.15<=<R><=0.60): {len(ok)}")
    print("WORKING POINT:", json.dumps(wp, indent=2))


if __name__ == "__main__":
    main()
