#!/usr/bin/env python3
"""Stage 3b - controls for the negative result on the consolidation axis.

The central negative finding is that increasing the consolidation gain g does
NOT lengthen the residence time in phase-locking configurations; it shortens it.
Because a negative result is only as strong as the space of implementations it
survives, three alternative operationalisations of "attractor deepening" are
tested here:

  C1  homeostasis off  - consolidation raises the total coupling budget instead
                         of redistributing it at constant nodal strength.
  C2  consolidation timescale - tau_c from 50 ms (tracking) to 4 s (long-term),
                         spanning well below and well above the dwell time.
  C3  coherence-trace timescale - tau_r from 10 ms to 200 ms.
  C4  linear (non-Gibbs) reinforcement, recovered by using a small g, is already
      contained in the g sweep because exp(x) ~ 1 + x for small x; the sweep
      therefore covers both the linear and the strongly selective regimes.

Outputs: results/controls.csv
"""
from __future__ import annotations

import itertools, json, pathlib, sys
import numpy as np
import pandas as pd
from concurrent.futures import ProcessPoolExecutor

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import model as M
import observables as O

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
with open(RES / "working_point.json", encoding="utf-8") as _fh:
    WP = json.load(_fh)
F0, V, K = WP["f0_hz"], WP["v_ms"], WP["K"]
K_STATES = 5
SIGMA = 0.4
T_REC = 16.0
G_SET = (0.0, 2.0, 4.0, 8.0, 16.0, 32.0)
SEEDS = (31, 97, 173)

_C = _IDX = _CENT = None
_THR = _THRS = None


def _init():
    global _C, _IDX, _CENT, _THR, _THRS
    _C = M.load_connectome(ROOT / "data")
    _IDX = M.subnetwork_indices(_C)
    d = np.load(RES / "state_dictionary.npz")
    _CENT = d["centroids"]
    _THR = float(d["burst_thresh"])
    _THRS = float(d["burst_thresh_sub"])


def _one(a):
    ctrl, g, tau_r, tau_c, hom, seed = a
    ed = M.build_edges(_C, v_ms=V)
    om = M.intrinsic_frequencies(_C["n"], f0=F0)
    out = M.simulate(ed, om, K=K, g=g, sigma=SIGMA, tau_r=tau_r, tau_c=tau_c,
                     t_rec=T_REC, seed=seed, n=_C["n"], homeostasis=hom,
                     sub_idx=_IDX)
    m = O.all_markers(out, _CENT, K_STATES, W=_C["W"], sigma=SIGMA,
                      burst_thresh=_THR, f0_hz=F0)
    m.update(control=ctrl, g=g, tau_r=tau_r, tau_c=tau_c, homeostasis=hom,
             seed=seed, C_total=float(out["Cbar"].mean()))
    return m


def main():
    jobs = []
    for g, sd in itertools.product(G_SET, SEEDS):
        jobs.append(("C1_no_homeostasis", g, M.TAU_R_S, M.TAU_C_S, False, sd))
        for tc in (0.05, 0.2, 1.0, 4.0):
            jobs.append((f"C2_tau_c={tc}", g, M.TAU_R_S, tc, True, sd))
        for tr in (0.010, 0.050, 0.200):
            jobs.append((f"C3_tau_r={tr}", g, tr, M.TAU_C_S, True, sd))
    with ProcessPoolExecutor(2, initializer=_init) as ex:
        rows = list(ex.map(_one, jobs, chunksize=2))
    df = pd.DataFrame(rows)
    df.to_csv(RES / "controls.csv", index=False)

    cols = ["dwell_mean_ms", "transition_rate_hz", "minor_occupancy",
            "parasitic_index", "C_conc", "C_total", "R_mean", "metastability"]
    piv = df.groupby(["control", "g"])[cols].mean()
    print(piv.to_string(float_format=lambda x: f"{x:9.3f}"))

    # Spearman trend of dwell time against g, per control
    from scipy.stats import spearmanr
    print("\nmonotone trend of dwell time with g (Spearman):")
    for c, s in df.groupby("control"):
        rho, p = spearmanr(s.g, s.dwell_mean_ms)
        verdict = ("LENGTHENS" if rho > 0 and p < 0.05 else
                   "SHORTENS" if rho < 0 and p < 0.05 else "no trend")
        print(f"  {c:<22} rho = {rho:+.3f}  p = {p:.3g}   -> {verdict}")


if __name__ == "__main__":
    main()
