#!/usr/bin/env python3
"""Stage 2 - main experiments.

A. Common dictionary of phase-locking configurations + reference thresholds.
B. 21 x 21 phase diagram over the two hypothesis parameters (g, sigma).
C. 20 independent realisations at five a-priori operating points:
     NT        g low,  sigma low,  distributed locus   (neurotypical)
     ASD       g high, sigma low,  distributed locus   (hypothesis: autism)
     AD        g low,  sigma high, distributed locus   (hypothesis: Alzheimer)
     PD_hyp    g high, sigma high, distributed locus   (hypothesis: Parkinson)
     PD_locus  g high, sigma low,  sensorimotor locus  (this study's proposal)
   with permutation tests, bootstrap CIs, Hedges' g and BH-FDR control.
D. Separability test of the four hypothesis quadrants in marker space.
E. Locus-size sweep: the third axis of the taxonomy.
F. Robustness of the repertoire size k.

All markers are pre-specified in PRIMARY before any statistic is computed.
"""
from __future__ import annotations

import json, pathlib, sys
import numpy as np
import pandas as pd
from concurrent.futures import ProcessPoolExecutor

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import model as M
import observables as O

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
RES.mkdir(exist_ok=True)

with open(RES / "working_point.json", encoding="utf-8") as _fh:
    WP = json.load(_fh)
F0, V, K = WP["f0_hz"], WP["v_ms"], WP["K"]

N_G, N_S = 21, 21
G_GRID = np.linspace(0.0, 32.0, N_G)
S_GRID = np.geomspace(0.05, 8.0, N_S)

G_LO, G_HI = 1.0, 16.0
S_LO, S_HI = 0.4, 6.0
#                      g,    sigma, focal locus?
OPPOINTS = {
    "NT":       (G_LO, S_LO, False),
    "ASD":      (G_HI, S_LO, False),
    "AD":       (G_LO, S_HI, False),
    "PD_hyp":   (G_HI, S_HI, False),
    "PD_locus": (G_HI, S_LO, True),
}
QUADRANTS = ["NT", "ASD", "AD", "PD_hyp"]     # the hypothesis' own 2x2
N_SEEDS = 20
K_STATES = 5
N_PERM = 10000
N_BOOT = 10000

PRIMARY = ["R_mean", "metastability", "dwell_mean_ms", "transition_rate_hz",
           "transition_entropy", "repertoire_entropy", "minor_occupancy",
           "parasitic_index", "burst_mean_ms", "burst_time_frac",
           "carrier_hz", "pow_theta", "pow_alpha", "pow_beta",
           "theta_alpha_ratio", "C_conc", "barrier_eff", "sc_fc_r",
           "sub_R_mean", "sub_pow_beta", "sub_burst_mean_ms",
           "sub_burst_time_frac"]

_C = _IDX = _CENT = None
_THR = _THRS = None


def conn():
    global _C, _IDX
    if _C is None:
        _C = M.load_connectome(ROOT / "data")
        _IDX = M.subnetwork_indices(_C)
    return _C


def edges_for(focal, locus_idx=None):
    c = conn()
    ed = M.build_edges(c, v_ms=V)
    if focal:
        ed = M.restrict_motif(ed, c, _IDX if locus_idx is None else locus_idx)
    return ed


def run(g, sigma, seed, focal=False, locus_idx=None, t_rec=M.T_REC_S):
    c = conn()
    om = M.intrinsic_frequencies(c["n"], f0=F0)
    return M.simulate(edges_for(focal, locus_idx), om, K=K, g=g, sigma=sigma,
                      t_rec=t_rec, seed=seed, n=c["n"], sub_idx=_IDX)


def markers(out, sigma):
    c = conn()
    m = O.all_markers(out, _CENT, K_STATES, W=c["W"], sigma=sigma,
                      burst_thresh=_THR, f0_hz=F0)
    m["sub_R_mean"] = float(np.mean(out["R_sub"]))
    for kk, vv in O.relative_band_power(out["sig_sub"]).items():
        m["sub_" + kk] = vv
    for kk, vv in O.sync_bursts(out["R_sub"], thresh=_THRS).items():
        m["sub_" + kk] = vv
    return m


# ------------------------------------------------------------------ stage A --
def _anchor_job(a):
    g, s, focal = a
    return run(g, s, seed=101, focal=focal)["U"][::2]


def build_dictionary():
    anchors = [(g, s, False) for g in (0.0, 16.0, 32.0) for s in (0.05, 1.0, 8.0)]
    anchors += [(16.0, s, True) for s in (0.05, 1.0, 8.0)]
    with ProcessPoolExecutor(2) as ex:
        Us = list(ex.map(_anchor_job, anchors))
    pool = np.vstack(Us)
    km = O.fit_state_dictionary(pool, k=K_STATES, seed=0, n_init=25)
    ref = run(G_LO, S_LO, seed=101)
    np.savez(RES / "state_dictionary.npz",
             centroids=km.cluster_centers_,
             burst_thresh=float(np.percentile(ref["R"], 75)),
             burst_thresh_sub=float(np.percentile(ref["R_sub"], 75)),
             pool_shape=np.array(pool.shape))
    return pool


def _init_worker():
    global _CENT, _THR, _THRS
    conn()
    d = np.load(RES / "state_dictionary.npz")
    _CENT = d["centroids"]
    _THR = float(d["burst_thresh"])
    _THRS = float(d["burst_thresh_sub"])


# ------------------------------------------------------------------ stage B --
def _grid_job(a):
    gi, si, g, s = a
    m = markers(run(g, s, seed=1000 + 37 * gi + si), s)
    m.update(g=g, sigma=s, gi=gi, si=si)
    return m


def phase_diagram():
    jobs = [(gi, si, g, s) for gi, g in enumerate(G_GRID)
            for si, s in enumerate(S_GRID)]
    with ProcessPoolExecutor(2, initializer=_init_worker) as ex:
        rows = list(ex.map(_grid_job, jobs, chunksize=4))
    df = pd.DataFrame(rows)
    df.to_csv(RES / "phase_diagram.csv", index=False)
    return df


# ------------------------------------------------------------------ stage C --
def _op_job(a):
    name, g, s, focal, seed = a
    m = markers(run(g, s, seed=seed, focal=focal), s)
    m.update(regime=name, g=g, sigma=s, focal=focal, seed=seed)
    return m


def operating_points():
    jobs = [(n, g, s, f, 5000 + 211 * i + j)
            for i, (n, (g, s, f)) in enumerate(OPPOINTS.items())
            for j in range(N_SEEDS)]
    with ProcessPoolExecutor(2, initializer=_init_worker) as ex:
        rows = list(ex.map(_op_job, jobs, chunksize=2))
    df = pd.DataFrame(rows)
    df.to_csv(RES / "regime_runs.csv", index=False)
    return df


# ----------------------------------------------------------------- stats -----
def perm_test(x, y, n=N_PERM, rng=None):
    rng = rng or np.random.default_rng(0)
    obs = np.nanmean(x) - np.nanmean(y)
    pooled = np.concatenate([x, y])
    nx = len(x)
    cnt = 0
    for _ in range(n):
        rng.shuffle(pooled)
        if abs(np.nanmean(pooled[:nx]) - np.nanmean(pooled[nx:])) >= abs(obs) - 1e-15:
            cnt += 1
    return obs, (cnt + 1) / (n + 1)


def hedges_g(x, y):
    nx, ny = len(x), len(y)
    sp = np.sqrt(((nx - 1) * np.nanvar(x, ddof=1) + (ny - 1) * np.nanvar(y, ddof=1))
                 / (nx + ny - 2))
    if not np.isfinite(sp) or sp == 0:
        return np.nan
    return (np.nanmean(x) - np.nanmean(y)) / sp * (1 - 3 / (4 * (nx + ny) - 9))


def boot_ci(x, y, n=N_BOOT, rng=None):
    rng = rng or np.random.default_rng(1)
    nx, ny = len(x), len(y)
    d = np.array([np.nanmean(x[rng.integers(0, nx, nx)])
                  - np.nanmean(y[rng.integers(0, ny, ny)]) for _ in range(n)])
    return float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))


def bh_fdr(p):
    p = np.asarray(p, float)
    m = len(p)
    o = np.argsort(p)
    q = np.empty(m)
    prev = 1.0
    for rank, idx in enumerate(o[::-1]):
        prev = min(prev, p[idx] * m / (m - rank))
        q[idx] = prev
    return q


CONTRASTS = [("ASD", "NT"), ("AD", "NT"), ("PD_hyp", "NT"), ("PD_locus", "NT"),
             ("PD_hyp", "ASD"), ("PD_locus", "ASD")]


def regime_stats(df):
    rows = []
    rng = np.random.default_rng(2026)
    for a, b in CONTRASTS:
        xa, xb = df[df.regime == a], df[df.regime == b]
        for mk in PRIMARY:
            x = xa[mk].to_numpy(float)
            y = xb[mk].to_numpy(float)
            if not (np.isfinite(x).any() and np.isfinite(y).any()):
                continue
            diff, p = perm_test(x, y, rng=rng)
            lo, hi = boot_ci(x, y, rng=rng)
            rows.append(dict(contrast=f"{a}_vs_{b}", regime=a, reference=b, marker=mk,
                             mean_regime=float(np.nanmean(x)),
                             sd_regime=float(np.nanstd(x, ddof=1)),
                             mean_control=float(np.nanmean(y)),
                             sd_control=float(np.nanstd(y, ddof=1)),
                             diff=float(diff), ci_lo=lo, ci_hi=hi,
                             hedges_g=float(hedges_g(x, y)), p_perm=float(p)))
    st = pd.DataFrame(rows)
    st["q_bh"] = bh_fdr(st.p_perm.to_numpy())
    st.to_csv(RES / "regime_stats.csv", index=False)
    df.groupby("regime")[PRIMARY].agg(["mean", "std"]).to_csv(RES / "regime_summary.csv")
    return st


# ------------------------------------------------------------------ stage D --
def separability(df, n=N_PERM):
    """Permutation test on the centroid distance between operating points.

    Markers are z-scored over the pooled sample; the statistic is the Euclidean
    distance between group centroids in that standardised space.
    """
    names = list(OPPOINTS)
    X = df[PRIMARY].to_numpy(float)
    X = np.where(np.isfinite(X), X, np.nan)
    mu, sd = np.nanmean(X, 0), np.nanstd(X, 0, ddof=1)
    sd[~np.isfinite(sd) | (sd == 0)] = 1.0
    Z = np.nan_to_num((X - mu) / sd)
    lab = df.regime.to_numpy()
    rng = np.random.default_rng(11)
    rows = []
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            m = np.isin(lab, [a, b])
            Zi, li = Z[m], lab[m]
            d0 = np.linalg.norm(Zi[li == a].mean(0) - Zi[li == b].mean(0))
            cnt = 0
            perm = li.copy()
            for _ in range(n):
                rng.shuffle(perm)
                d = np.linalg.norm(Zi[perm == a].mean(0) - Zi[perm == b].mean(0))
                if d >= d0 - 1e-12:
                    cnt += 1
            rows.append(dict(a=a, b=b, centroid_distance=float(d0),
                             p_perm=float((cnt + 1) / (n + 1))))
    sep = pd.DataFrame(rows)
    sep["q_bh"] = bh_fdr(sep.p_perm.to_numpy())
    sep.to_csv(RES / "separability.csv", index=False)
    return sep


# ------------------------------------------------------------------ stage E --
def _locus_job(a):
    size, rep, g, s, seed = a
    c = conn()
    if size >= c["n"]:
        idx = np.arange(c["n"], dtype=np.int32)
    elif rep == 0:
        idx = _IDX[:size] if size <= len(_IDX) else np.r_[
            _IDX, np.setdiff1d(np.arange(c["n"]), _IDX)[: size - len(_IDX)]].astype(np.int32)
    else:
        idx = np.random.default_rng(900 + 13 * rep + size).choice(
            c["n"], size=size, replace=False).astype(np.int32)
    m = markers(run(g, s, seed=seed, focal=True, locus_idx=idx), s)
    m.update(locus_size=size, locus_rep=rep, anatomical=(rep == 0), g=g, sigma=s)
    return m


def locus_sweep():
    jobs = [(size, rep, G_HI, S_LO, 15000 + 71 * size + 7 * rep + j)
            for size in (6, 12, 20, 34, 50, 68) for rep in range(3) for j in range(2)]
    with ProcessPoolExecutor(2, initializer=_init_worker) as ex:
        rows = list(ex.map(_locus_job, jobs, chunksize=2))
    df = pd.DataFrame(rows)
    df.to_csv(RES / "locus_sweep.csv", index=False)
    return df


# ------------------------------------------------------------------ stage F --
def k_robustness(pool):
    dicts = {kk: O.fit_state_dictionary(pool, k=kk, seed=0, n_init=20).cluster_centers_
             for kk in (3, 4, 5, 6, 7, 8)}
    rows = []
    for name, (g, s, f) in OPPOINTS.items():
        for j in range(4):
            out = run(g, s, seed=7000 + 31 * j, focal=f)
            for kk, cent in dicts.items():
                rep = O.repertoire_metrics(O.assign_states(out["U"], cent), kk)
                rep.pop("occupancy")
                rep.update(k=kk, regime=name, seed=7000 + 31 * j)
                rows.append(rep)
    df = pd.DataFrame(rows)
    df.to_csv(RES / "k_robustness.csv", index=False)
    return df


def main():
    print("working point:", dict(f0_hz=F0, v_ms=V, K=K), flush=True)
    print("[A] dictionary ...", flush=True)
    pool = build_dictionary()
    _init_worker()
    print("    pool", pool.shape, flush=True)
    print("[B] phase diagram ...", flush=True)
    print("   ", phase_diagram().shape, flush=True)
    print("[C] operating points ...", flush=True)
    rg = operating_points()
    st = regime_stats(rg)
    print(rg.groupby("regime")[PRIMARY].mean().T
          .to_string(float_format=lambda x: f"{x:9.4f}"), flush=True)
    print("\n[D] separability ...", flush=True)
    print(separability(rg).to_string(index=False,
                                     float_format=lambda x: f"{x:9.4g}"), flush=True)
    print("\n[E] locus sweep ...", flush=True)
    ls = locus_sweep()
    print(ls.groupby(["locus_size"])[["pow_beta", "sub_pow_beta", "parasitic_index",
                                      "minor_occupancy", "dwell_mean_ms", "C_conc"]]
          .mean().to_string(float_format=lambda x: f"{x:9.4f}"), flush=True)
    print("\n[F] k robustness ...", flush=True)
    k_robustness(pool)
    print("\nsignificant contrasts (q<0.05):",
          int((st.q_bh < 0.05).sum()), "/", len(st))
    print("done")


if __name__ == "__main__":
    main()
