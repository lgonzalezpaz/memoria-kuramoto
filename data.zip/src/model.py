"""
Motif-gated adaptive Kuramoto model on the human structural connectome.
======================================================================

Core numerical engine for:

    "Everything is memory? A connectome-based falsification test of attractor
     inertia as a unifying axis of autistic, Alzheimer and parkinsonian
     brain dynamics"

Model (see Methods, Eqs. 1-6):

    tau_ij = L_ij / v                                                      (1)

    M = normalised disynaptic motif support, M_ij = (W^2)_ij / max_(i!=j)(W^2) (2)

    dtheta_i/dt = omega_i + K * sum_j C_ij(t) * sin(theta_j(t - tau_ij) - theta_i(t))
                  + sigma * xi_i(t)                                        (3)

    tau_r * dr_ij/dt  = -r_ij + cos(theta_j(t) - theta_i(t))               (4)

    tau_c * dC_ij/dt  = -C_ij + W_ij * exp(g * M_ij * r_ij)                (5)

    C_ij <- C_ij * S_i / sum_k C_ik   (homeostatic nodal scaling)          (6)

The two control parameters of the hypothesis are:
    g      -- consolidation (plasticity) gain  == "attractor well depth" / memory inertia
    sigma  -- phase noise amplitude            == stochastic perturbability

Everything else is fixed from the literature or calibrated once (see Methods).

Author: see CITATION.cff.  Licence: MIT (code), CC-BY-4.0 (derived data).
"""
from __future__ import annotations

import numpy as np
from numba import njit

# ----------------------------------------------------------------------------
# Default biophysical constants (calibrated working point:
# f0 = 20.0 Hz, v = 12.0 m/s, K = 160.0 -- see Table 1 of the paper)
# ----------------------------------------------------------------------------
F0_HZ = 20.0        # calibrated node intrinsic frequency (Hz)
DF_HZ = 1.0         # s.d. of intrinsic-frequency heterogeneity
V_MS = 12.0         # calibrated axonal conduction velocity (m/s); Caminiti et al. 2013
TAU_R_S = 0.050     # coherence-trace time constant (s)
TAU_C_S = 0.200     # consolidation time constant (s); comparable to the dwell time
DT_S = 5.0e-4       # integration step (s) -> 100 steps per cycle at 20 Hz
FS_FAST = 500.0     # sampling rate of the global signal (Hz)
FS_STATE = 200.0    # sampling rate of the phase-configuration vector (Hz)
T_TRANS_S = 4.0     # discarded transient (s)
T_REC_S = 20.0      # recorded epoch (s)


# ----------------------------------------------------------------------------
# Connectome handling
# ----------------------------------------------------------------------------
def load_connectome(data_dir):
    """Load, validate and normalise the Desikan-Killiany 68-region connectome."""
    import pathlib
    p = pathlib.Path(data_dir)
    W = np.loadtxt(p / "dk68_weights.txt", dtype=np.float64)
    L = np.loadtxt(p / "dk68_tract_lengths.txt", dtype=np.float64)
    with open(p / "dk68_regions.txt", encoding="utf-8") as fh:
        regions = [ln.split()[0] for ln in fh]
    n = W.shape[0]
    assert W.shape == (n, n) == L.shape, "connectome shape mismatch"
    assert np.allclose(W, W.T), "structural matrix must be symmetric"
    np.fill_diagonal(W, 0.0)
    # Normalise so that the mean nodal strength equals one -> K is interpretable
    W = W / W.sum(axis=1).mean()
    # Disynaptic motif support (Eq. 2)
    M = W @ W
    np.fill_diagonal(M, 0.0)
    off = ~np.eye(n, dtype=bool)
    M = M / M[off].max()
    # Delays: only defined where a structural connection exists
    L = np.where(W > 0, L, 0.0)
    return dict(W=W, M=M, L=L, regions=regions, n=n)


def build_edges(conn, v_ms=V_MS, dt=DT_S):
    """Flatten the connectome into a CSR-style directed edge list with delays.

    Edges are returned grouped by receiving node, so that the homeostatic
    row rescaling of Eq. (6) can be applied in a single contiguous pass.
    """
    W, M, L = conn["W"], conn["M"], conn["L"]
    n = W.shape[0]
    i_idx, j_idx = np.nonzero(W)                 # row-major -> grouped by i
    tgt = i_idx.astype(np.int32)                 # receiving node i
    src = j_idx.astype(np.int32)                 # sending   node j
    w_e = W[i_idx, j_idx].astype(np.float64)
    m_e = M[i_idx, j_idx].astype(np.float64)
    d_e = np.maximum(1, np.rint(L[i_idx, j_idx] * 1e-3 / v_ms / dt)).astype(np.int32)
    ptr = np.zeros(n + 1, dtype=np.int32)
    np.cumsum(np.bincount(tgt, minlength=n), out=ptr[1:])
    strength = W.sum(axis=1).astype(np.float64)  # conserved nodal strength S_i
    return tgt, src, w_e, m_e, d_e, ptr, strength


# ----------------------------------------------------------------------------
# Numba integrator (Euler-Maruyama, ring-buffer delays, edge-sparse coupling)
# ----------------------------------------------------------------------------
@njit(cache=True, fastmath=True)
def _integrate(tgt, src, w_e, m_e, d_e, rptr, strength, omega, n, sub_idx,
               K, g, sigma, tau_r, tau_c, dt,
               n_trans, n_rec, step_fast, step_state, seed, homeostasis):
    np.random.seed(seed)
    n_e = tgt.shape[0]
    buf = int(d_e.max()) + 2

    theta = np.random.uniform(0.0, 2.0 * np.pi, n)
    hist = np.zeros((buf, n))
    for b in range(buf):
        for i in range(n):
            hist[b, i] = theta[i]

    C = w_e.copy()
    r = np.zeros(n_e)

    n_f = n_rec // step_fast
    n_s = n_rec // step_state
    sig = np.zeros(n_f)          # global field  (1/N) sum cos(theta)
    Rt = np.zeros(n_f)           # Kuramoto order parameter modulus
    U = np.zeros((n_s, n))       # phase configuration cos(theta_i - Phi)
    Cbar = np.zeros(n_f)         # mean consolidated coupling
    Cconc = np.zeros(n_f)        # coupling concentration (Herfindahl index)
    sig_s = np.zeros(n_f)        # local field of the node subset
    R_s = np.zeros(n_f)          # order parameter of the node subset
    n_sub = sub_idx.shape[0]

    ar = dt / tau_r
    ac = dt / tau_c
    sq = sigma * np.sqrt(dt)
    ptr = 0
    kf = 0
    ks = 0
    total = n_trans + n_rec

    for t in range(total):
        for i in range(n):
            hist[ptr, i] = theta[i]

        drive = np.zeros(n)
        for e in range(n_e):
            i = tgt[e]
            j = src[e]
            idx = ptr - d_e[e]
            if idx < 0:
                idx += buf
            drive[i] += C[e] * np.sin(hist[idx, j] - theta[i])

        # plasticity on the *instantaneous* (undelayed) phase difference
        for e in range(n_e):
            i = tgt[e]
            j = src[e]
            c = np.cos(theta[j] - theta[i])
            r[e] += ar * (c - r[e])
            x = g * m_e[e] * r[e]
            if x > 30.0:
                x = 30.0
            elif x < -30.0:
                x = -30.0
            target = w_e[e] * np.exp(x)
            C[e] += ac * (target - C[e])
            if C[e] < 0.0:
                C[e] = 0.0

        # homeostatic synaptic scaling: conserve the nodal strength S_i, so that
        # g redistributes coupling across edges without changing its total
        if homeostasis == 1:
            for i in range(n):
                s = 0.0
                for e in range(rptr[i], rptr[i + 1]):
                    s += C[e]
                if s > 1e-12:
                    f = strength[i] / s
                    for e in range(rptr[i], rptr[i + 1]):
                        C[e] *= f

        for i in range(n):
            theta[i] += dt * (omega[i] + K * drive[i]) + sq * np.random.normal()

        if t >= n_trans:
            u = t - n_trans
            if u % step_fast == 0 and kf < n_f:
                cs = 0.0
                sn = 0.0
                for i in range(n):
                    cs += np.cos(theta[i])
                    sn += np.sin(theta[i])
                cs /= n
                sn /= n
                sig[kf] = cs
                Rt[kf] = np.sqrt(cs * cs + sn * sn)
                cs2 = 0.0
                sn2 = 0.0
                for q in range(n_sub):
                    cs2 += np.cos(theta[sub_idx[q]])
                    sn2 += np.sin(theta[sub_idx[q]])
                cs2 /= n_sub
                sn2 /= n_sub
                sig_s[kf] = cs2
                R_s[kf] = np.sqrt(cs2 * cs2 + sn2 * sn2)
                csum = 0.0
                hhi = 0.0
                for i2 in range(n):
                    s = 0.0
                    for e in range(rptr[i2], rptr[i2 + 1]):
                        s += C[e]
                    if s > 1e-12:
                        for e in range(rptr[i2], rptr[i2 + 1]):
                            p = C[e] / s
                            hhi += p * p
                    csum += s
                Cbar[kf] = csum / n_e
                Cconc[kf] = hhi / n
                kf += 1
            if u % step_state == 0 and ks < n_s:
                cs = 0.0
                sn = 0.0
                for i in range(n):
                    cs += np.cos(theta[i])
                    sn += np.sin(theta[i])
                phi = np.arctan2(sn, cs)
                for i in range(n):
                    U[ks, i] = np.cos(theta[i] - phi)
                ks += 1

        ptr += 1
        if ptr == buf:
            ptr = 0

    return sig, Rt, U, Cbar, Cconc, sig_s, R_s


def simulate(edges, omega, K, g, sigma,
             tau_r=TAU_R_S, tau_c=TAU_C_S, dt=DT_S,
             t_trans=T_TRANS_S, t_rec=T_REC_S, seed=0, n=68,
             homeostasis=True, sub_idx=None):
    """Run one simulation and return raw observables."""
    tgt, src, w_e, m_e, d_e, row_ptr, strength = edges
    n_trans = int(round(t_trans / dt))
    n_rec = int(round(t_rec / dt))
    step_fast = int(round(1.0 / (FS_FAST * dt)))
    step_state = int(round(1.0 / (FS_STATE * dt)))
    if sub_idx is None:
        sub_idx = np.arange(n, dtype=np.int32)
    sub_idx = np.asarray(sub_idx, dtype=np.int32)
    sig, Rt, U, Cbar, Cconc, sig_s, R_s = _integrate(
        tgt, src, w_e, m_e, d_e, row_ptr, strength, omega, n, sub_idx,
        float(K), float(g), float(sigma), float(tau_r), float(tau_c), float(dt),
        n_trans, n_rec, step_fast, step_state, int(seed), 1 if homeostasis else 0)
    return dict(sig=sig, R=Rt, U=U, Cbar=Cbar, Cconc=Cconc,
                sig_sub=sig_s, R_sub=R_s)


SENSORIMOTOR = ("precentral", "postcentral", "paracentral",
                "caudalmiddlefrontal", "supramarginal", "superiorfrontal")


def subnetwork_indices(conn, keys=SENSORIMOTOR):
    """Indices of the bilateral sensorimotor / premotor subnetwork."""
    return np.array([i for i, r in enumerate(conn["regions"])
                     if any(k in r for k in keys)], dtype=np.int32)


def restrict_motif(edges, conn, idx):
    """Return a copy of `edges` in which motif gating acts only inside `idx`.

    This implements the third axis of the taxonomy: the anatomical *locus* of
    consolidation. Edges with both endpoints in `idx` keep their motif support;
    all other edges have M_ij set to zero and are therefore unaffected by g.
    """
    tgt, src, w_e, m_e, d_e, row_ptr, strength = edges
    inside = np.zeros(conn["n"], dtype=bool)
    inside[np.asarray(idx)] = True
    mask = inside[tgt] & inside[src]
    return (tgt, src, w_e, np.where(mask, m_e, 0.0), d_e, row_ptr, strength)


def intrinsic_frequencies(n, f0=F0_HZ, df=DF_HZ, seed=12345):
    rng = np.random.default_rng(seed)
    return 2.0 * np.pi * (f0 + df * rng.standard_normal(n))
