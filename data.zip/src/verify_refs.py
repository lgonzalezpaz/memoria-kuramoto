#!/usr/bin/env python3
"""Verify every bibliographic reference against the Crossref REST API.

No reference enters the manuscript unless this script returns VERIFIED with a
title whose normalised form matches the queried title. Output: results/references_verified.csv
"""
import json, re, sys, time, urllib.parse, urllib.request, csv, pathlib

MAILTO = "lgonzalezpaz@gmail.com"
UA = f"KuramotoMemoryRefCheck/1.0 (mailto:{MAILTO})"
OUT = pathlib.Path(__file__).resolve().parents[1] / "results" / "references_verified.csv"

# (key, query_title, optional_doi)
QUERIES = [
    ("acebron2005", "The Kuramoto model: A simple paradigm for synchronization phenomena", "10.1103/revmodphys.77.137"),
    ("breakspear2017", "Dynamic models of large-scale brain activity", "10.1038/nn.4497"),
    ("deco2011", "Emerging concepts for the dynamical organization of resting-state activity in the brain", "10.1038/nrn2961"),
    ("tognoli2014", "The metastable brain", "10.1016/j.neuron.2013.12.022"),
    ("kelso2012", "Multistability and metastability: understanding dynamic coordination in the brain", "10.1098/rstb.2011.0351"),
    ("shanahan2010", "Metastable chimera states in community-structured oscillator networks", "10.1063/1.3305451"),
    ("hellyer2014", "The control of global brain dynamics: opposing actions of frontoparietal control and default mode networks on attention", "10.1523/jneurosci.1853-13.2014"),
    ("hellyer2016", "Local inhibitory plasticity tunes macroscopic brain dynamics and allows the emergence of functional brain networks", "10.1016/j.neuroimage.2015.08.069"),
    ("cabral2011", "Role of local network oscillations in resting-state functional connectivity", "10.1016/j.neuroimage.2011.04.010"),
    ("cabral2017", "Cognitive performance in healthy older adults relates to spontaneous switching between states of functional connectivity during rest", "10.1038/s41598-017-05425-7"),
    ("cabral2022", "Metastable oscillatory modes emerge from synchronization in the brain spacetime connectome", "10.1038/s42005-022-00950-y"),
    ("deco2017", "The dynamics of resting fluctuations in the brain: metastability and its dynamical cortical core", "10.1038/s41598-017-03073-5"),
    ("ghosh2008", "Noise during rest enables the exploration of the brain's dynamic repertoire", "10.1371/journal.pcbi.1000196"),
    ("vasa2015", "Effects of lesions on synchrony and metastability in cortical networks", "10.1016/j.neuroimage.2015.05.042"),
    ("alderson2018", "Metastable neural dynamics in Alzheimer's disease are disrupted by lesions to the structural connectome", "10.1016/j.neuroimage.2018.08.033"),
    ("demirtas2017", "A whole-brain computational modeling approach to explain the alterations in resting-state functional connectivity during progression of Alzheimer's disease", "10.1016/j.nicl.2017.08.006"),
    ("jirsa2017", "The Virtual Epileptic Patient: Individualized whole-brain models of epilepsy spread", "10.1016/j.neuroimage.2016.04.049"),
    ("sanzleon2013", "The Virtual Brain: a simulator of primate brain network dynamics", "10.3389/fninf.2013.00010"),
    ("hagmann2008", "Mapping the structural core of human cerebral cortex", "10.1371/journal.pbio.0060159"),
    ("desikan2006", "An automated labeling system for subdividing the human cerebral cortex on MRI scans into gyral based regions of interest", "10.1016/j.neuroimage.2006.01.021"),
    ("honey2009", "Predicting human resting-state functional connectivity from structural connectivity", "10.1073/pnas.0811168106"),
    ("caminiti2013", "Diameter, length, speed, and conduction delay of callosal axons in macaque monkeys and humans", "10.1523/jneurosci.0761-13.2013"),
    ("seliger2002", "Plasticity and learning in a network of coupled phase oscillators", "10.1103/physreve.65.041906"),
    ("michel2018", "EEG microstates as a tool for studying the temporal dynamics of whole-brain neuronal networks: A review", "10.1016/j.neuroimage.2017.11.062"),
    ("khanna2015", "Microstates in resting-state EEG: current status and future directions", "10.1016/j.neubiorev.2014.12.010"),
    ("dcroz2019", "EEG Microstates Analysis in Young Adults With Autism Spectrum Disorder During Resting-State", "10.3389/fnhum.2019.00173"),
    ("kalburgi2020", "Children With Autism Produce a Unique Pattern of EEG Microstates During an Eyes Closed Resting-State Condition", "10.3389/fnhum.2020.00288"),
    ("watanabe2017", "Brain network dynamics in high-functioning individuals with autism", "10.1038/ncomms16048"),
    ("ezaki2017", "Energy landscape analysis of neuroimaging data", "10.1098/rsta.2016.0287"),
    ("supekar2013", "Brain hyperconnectivity in children with autism and its links to social deficits", "10.1016/j.celrep.2013.10.001"),
    ("uddin2013", "Salience network-based classification and prediction of symptom severity in children with autism", "10.1001/jamapsychiatry.2013.104"),
    ("just2004", "Cortical activation and synchronization during sentence comprehension in high-functioning autism: evidence of underconnectivity", "10.1093/brain/awh199"),
    ("rubenstein2003", "Model of autism: increased ratio of excitation/inhibition in key neural systems", "10.1034/j.1601-183x.2003.00037.x"),
    ("koenig2005", "Decreased EEG synchronization in Alzheimer's disease and mild cognitive impairment", "10.1016/j.neurobiolaging.2004.03.008"),
    ("zhang2021", "The Significance of EEG Alpha Oscillation Spectral Power and Beta Oscillation Phase Synchronization for Diagnosing Probable Alzheimer Disease", "10.3389/fnagi.2021.631587"),
    ("delbeuck2003", "Alzheimer's disease as a disconnection syndrome?", "10.1023/a:1023832305702"),
    ("hammond2007", "Pathological synchronization in Parkinson's disease: networks, models and treatments", "10.1016/j.tins.2007.05.004"),
    ("kuhn2006", "Reduction in subthalamic 8-35 Hz oscillatory activity correlates with clinical improvement in Parkinson's disease", "10.1111/j.1460-9568.2006.04717.x"),
    ("tinkhauser2017", "Beta burst dynamics in Parkinson's disease OFF and ON dopaminergic medication", "10.1093/brain/awx252"),
    ("little2013", "Adaptive deep brain stimulation in advanced Parkinson disease", "10.1002/ana.23951"),
    ("rubchinsky2011", "Intermittent neural synchronization in Parkinson's disease", "10.1007/s11071-011-0223-z"),
    ("fiorenzato2019", "Dynamic functional connectivity changes associated with dementia in Parkinson's disease", "10.1093/brain/awz192"),
    ("lord2019", "Dynamical exploration of the repertoire of brain networks at rest is modulated by psilocybin", "10.1016/j.neuroimage.2019.05.060"),
    ("hancock2022", "Metastability, fractal scaling, and synergistic information processing: what phase relationships reveal about intrinsic brain activity", "10.1098/rsif.2022.0214"),
    ("gollo2015", "Dwelling quietly in the rich club: brain network determinants of slow cortical fluctuations", "10.1098/rstb.2014.0165"),
    ("wang2021", "Hierarchical connectome modes and critical state jointly maximize human brain function", "10.1073/pnas.2022288118"),
    ("rubinov2010", "Complex network measures of brain connectivity: uses and interpretations", "10.1016/j.neuroimage.2009.10.003"),
    ("stam2007", "Phase lag index: assessment of functional connectivity from multi channel EEG and MEG with diminished bias from common sources", "10.1002/hbm.20346"),
    ("lachaux1999", "Measuring phase synchrony in brain signals", "10.1002/(SICI)1097-0193(1999)8:4<194::AID-HBM4>3.0.CO;2-C"),
    ("benjamini1995", "Controlling the false discovery rate: a practical and powerful approach to multiple testing", "10.1111/j.2517-6161.1995.tb02031.x"),
    ("morris1991", "Factorial sampling plans for preliminary computational experiments", "10.1080/00401706.1991.10484804"),
    ("saltelli2010", "Variance based sensitivity analysis of model output. Design and estimator for the total sensitivity index", "10.1016/j.cpc.2009.09.018"),
    ("kramers1940", "Brownian motion in a field of force and the diffusion model of chemical reactions", "10.1016/s0031-8914(40)90098-2"),
    ("harris2020", "Array programming with NumPy", "10.1038/s41586-020-2649-2"),
    ("virtanen2020", "SciPy 1.0: fundamental algorithms for scientific computing in Python", "10.1038/s41592-019-0686-2"),
    ("hunter2007", "Matplotlib: A 2D Graphics Environment", "10.1109/mcse.2007.55"),
    ("lam2015", "Numba: a LLVM-based Python JIT compiler", "10.1145/2833157.2833162"),
    ("niebur1991", "Collective frequencies and metastability in networks of limit-cycle oscillators with time delay", "10.1103/physrevlett.67.2753"),
    ("stikov2015", "In vivo histology of the myelin g-ratio with magnetic resonance imaging", "10.1016/j.neuroimage.2015.05.023"),
    ("donoghue2020", "Parameterizing neural power spectra into periodic and aperiodic components", "10.1038/s41593-020-00744-x"),
]


def crossref_by_doi(doi):
    url = f"https://api.crossref.org/works/{urllib.parse.quote(doi)}"
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.load(r)["message"]


def crossref_by_title(title):
    url = ("https://api.crossref.org/works?query.bibliographic="
           + urllib.parse.quote(title) + "&rows=3&select=DOI,title,container-title,volume,issue,page,issued,author,type")
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=45) as r:
        items = json.load(r)["message"]["items"]
    return items


def norm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def jaccard(a, b):
    A, B = set(re.findall(r"[a-z0-9]+", a.lower())), set(re.findall(r"[a-z0-9]+", b.lower()))
    return len(A & B) / max(1, len(A | B))


def fmt_authors(auth, limit=6):
    if not auth:
        return ""
    names = []
    for a in auth:
        fam = a.get("family", "")
        giv = a.get("given", "")
        ini = "".join(p[0] + "." for p in re.split(r"[\s\-]+", giv) if p)
        names.append(f"{fam}, {ini}".strip(", "))
    if len(names) > limit:
        return "; ".join(names[:limit]) + "; et al."
    return "; ".join(names)


def main():
    rows = []
    for key, title, doi in QUERIES:
        rec, status, score = None, "NOT_FOUND", 0.0
        try:
            if doi:
                rec, status, score = crossref_by_doi(doi), "VERIFIED_DOI", 1.0
            else:
                for cand in crossref_by_title(title):
                    s = jaccard(title, cand.get("title", [""])[0])
                    if s > score:
                        rec, score = cand, s
                if rec is not None:
                    status = "VERIFIED" if score >= 0.60 else ("WEAK" if score >= 0.40 else "MISMATCH")
        except Exception as e:                                    # pragma: no cover
            status = f"ERROR:{type(e).__name__}"
        if rec:
            iss = rec.get("issued", {}).get("date-parts", [[None]])[0]
            rows.append(dict(key=key, status=status, match=round(score, 3),
                             doi=rec.get("DOI", ""), title=rec.get("title", [""])[0],
                             journal=(rec.get("container-title") or [""])[0],
                             year=iss[0] if iss else "", volume=rec.get("volume", ""),
                             issue=rec.get("issue", ""), pages=rec.get("page", ""),
                             authors=fmt_authors(rec.get("author")), type=rec.get("type", "")))
        else:
            rows.append(dict(key=key, status=status, match=0, doi="", title=title,
                             journal="", year="", volume="", issue="", pages="", authors="", type=""))
        time.sleep(0.12)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    for r in rows:
        print(f"{r['status']:<14} {r['match']:<6} {r['key']:<16} {r['year']} {r['journal'][:40]:<40} {r['doi']}")
    bad = [r for r in rows if not r["status"].startswith("VERIFIED")]
    print(f"\n{len(rows) - len(bad)}/{len(rows)} verified; {len(bad)} need attention")
    for r in bad:
        print("  !!", r["key"], r["status"], "->", r["title"][:80])


if __name__ == "__main__":
    sys.exit(main())
