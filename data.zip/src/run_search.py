#!/usr/bin/env python3
"""Stage 5 - where do the clinical dynamical signatures actually live?

The hypothesis places the autistic, Alzheimer and parkinsonian regimes in the
(g, sigma) plane. Stage 4 shows that only the Alzheimer signature is recovered
there. This stage asks the constructive question: within the model's full
parameter space, is there ANY setting that reproduces the complete published
signature of each syndrome?

A syndrome signature is a conjunction of directional criteria relative to the
neurotypical operating point, taken verbatim from data/empirical_targets.csv:

  ASD : dwell up,  transition rate down, minor occupancy down, repertoire entropy down
  AD  : metastability down, alpha power down, theta/alpha up, synchrony down
  PD  : synchrony up, beta power up, burst time fraction up, carrier frequency up

Two searches are run:
  (a) a 9 x 7 grid over the total coupling budget K and the conduction velocity v
      at g = 0 (no consolidation), sigma = 0.4 - i.e. the two structural
      quantities that the hypothesis holds fixed;
  (b) a rescan of the 7-dimensional prior-predictive sample from stage 3.

Outputs: results/search_Kv.csv, results/signature_search.csv
"""
from __future__ import annotations

import itertools, json, pathlib, sys
import numpy as np
import pandas as pd
from concurrent.futures import ProcessPoolExecutor

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import model as M
import observables as O

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
with open(RES / "working_point.json", encoding="utf-8") as _fh:
    WP = json.load(_fh)
F0 = WP["f0_hz"]
K_STATES = 5
T_REC = 14.0

K_SET = [40.0, 80.0, 120.0, 160.0, 220.0, 300.0, 400.0, 550.0, 750.0]
V_SET = [5.0, 8.0, 12.0, 18.0, 26.0, 40.0, 1.0e5]

SIGNATURES = {
    "ASD": {"dwell_mean_ms": +1, "transition_rate_hz": -1,
            "minor_occupancy": -1, "repertoire_entropy": -1},
    "AD": {"metastability": -1, "pow_alpha": -1,
           "theta_alpha_ratio": +1, "R_mean": -1},
    "PD": {"R_mean": +1, "pow_beta": +1,
           "burst_time_frac": +1, "carrier_hz": +1},
}

_C = _IDX = _CENT = None
_THR = _THRS = None


def _init():
    global _C, _IDX, _CENT, _THR, _THRS
    _C = M.load_connectome(ROOT / "data")
    _IDX = M.subnetwork_indices(_C)
    d = np.load(RES / "state_dictionary.npz")
    _CENT = d["centroids"]
    _THR = float(d["burst_thresh"])
    _THRS = float(d["burst_thresh_sub"])


def _job(a):
    K, v, g, s, seed = a
    ed = M.build_edges(_C, v_ms=v)
    om = M.intrinsic_frequencies(_C["n"], f0=F0)
    out = M.simulate(ed, om, K=K, g=g, sigma=s, t_rec=T_REC, seed=seed,
                     n=_C["n"], sub_idx=_IDX)
    m = O.all_markers(out, _CENT, K_STATES, W=_C["W"], sigma=s,
                      burst_thresh=_THR, f0_hz=F0)
    m["sub_R_mean"] = float(np.mean(out["R_sub"]))
    for kk, vv in O.relative_band_power(out["sig_sub"]).items():
        m["sub_" + kk] = vv
    m.update(K=K, v_ms=v, g=g, sigma=s, seed=seed)
    return m


def score(df, ref):
    """Fraction of each signature's criteria satisfied, row by row."""
    out = {}
    for name, crit in SIGNATURES.items():
        sat = np.zeros(len(df), float)
        for mk, sgn in crit.items():
            if mk not in df.columns or mk not in ref:
                continue
            d = (df[mk].to_numpy(float) - ref[mk]) * sgn
            sat += (d > 0).astype(float)
        out[f"score_{name}"] = sat / len(crit)
    return pd.DataFrame(out, index=df.index)


def main():
    _init()
    runs = pd.read_csv(RES / "regime_runs.csv")
    ref = runs[runs.regime == "NT"].mean(numeric_only=True).to_dict()

    jobs = [(K, v, 0.0, 0.4, 41000 + 17 * i)
            for i, (K, v) in enumerate(itertools.product(K_SET, V_SET))]
    with ProcessPoolExecutor(2, initializer=_init) as ex:
        rows = list(ex.map(_job, jobs, chunksize=2))
    kv = pd.DataFrame(rows)
    kv = pd.concat([kv, score(kv, ref)], axis=1)
    kv.to_csv(RES / "search_Kv.csv", index=False)

    print("=== (a) search over the coupling budget K and conduction velocity v "
          "(g = 0, sigma = 0.4) ===")
    show = ["K", "v_ms", "R_mean", "metastability", "dwell_mean_ms",
            "transition_rate_hz", "minor_occupancy", "pow_alpha", "pow_beta",
            "carrier_hz", "burst_time_frac", "score_ASD", "score_AD", "score_PD"]
    print(kv[show].to_string(index=False, float_format=lambda x: f"{x:8.3f}"))

    frames = [kv.assign(source="K_v_grid")]
    pp_path = RES / "prior_predictive.csv"
    if pp_path.exists():
        pp = pd.read_csv(pp_path)
        pp = pd.concat([pp, score(pp, ref)], axis=1).assign(source="prior_predictive")
        frames.append(pp)
    allp = pd.concat(frames, ignore_index=True)
    allp.to_csv(RES / "signature_search.csv", index=False)

    print("\n=== (b) best match for each syndrome over the whole search ===")
    for name in SIGNATURES:
        col = f"score_{name}"
        best = allp.loc[allp[col].idxmax()]
        n_full = int((allp[col] >= 0.999).sum())
        print(f"\n{name}: criteria satisfied = {best[col]*100:.0f} %   "
              f"(settings meeting ALL criteria: {n_full} / {len(allp)})")
        keys = [k for k in ("source", "K", "v_ms", "f0_hz", "g", "sigma") if k in best.index]
        print("  best setting:", {k: (round(float(best[k]), 4)
                                      if isinstance(best[k], (int, float, np.floating))
                                      else best[k]) for k in keys})
        for mk, sgn in SIGNATURES[name].items():
            if mk in best.index and mk in ref:
                ok = (float(best[mk]) - ref[mk]) * sgn > 0
                print(f"    {mk:<20} model {float(best[mk]):9.4f}  NT {ref[mk]:9.4f}  "
                      f"{'required ' + ('increase' if sgn > 0 else 'decrease'):<18} "
                      f"{'OK' if ok else 'FAIL'}")


    overlap_analysis()
    resolve_ambiguity()


def overlap_analysis():
    """How exclusive are the published signatures of each syndrome?

    If two syndromes' full criterion sets are satisfied by the same model
    settings, then those marker sets do not dynamically discriminate the
    syndromes, however well each is individually reproduced.
    """
    allp = pd.read_csv(RES / "signature_search.csv")
    names = list(SIGNATURES)
    full = {n: (allp[f"score_{n}"] >= 0.999).to_numpy() for n in names}
    rows = []
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            both = int((full[a] & full[b]).sum())
            rows.append(dict(a=a, b=b, n_a=int(full[a].sum()), n_b=int(full[b].sum()),
                             n_both=both,
                             jaccard=both / max(1, int((full[a] | full[b]).sum())),
                             frac_a_also_b=both / max(1, int(full[a].sum())),
                             frac_b_also_a=both / max(1, int(full[b].sum()))))
    ov = pd.DataFrame(rows)
    ov.to_csv(RES / "signature_overlap.csv", index=False)
    print("\n=== (c) exclusivity of the published signatures ===")
    print(ov.to_string(index=False, float_format=lambda x: f"{x:7.3f}"))
    uniq = {n: int((full[n] & ~np.logical_or.reduce(
        [full[m] for m in names if m != n])).sum()) for n in names}
    print("\nsettings satisfying ONE signature exclusively:", uniq)
    with open(RES / "signature_exclusivity.json", "w", encoding="utf-8") as fh:
        json.dump(dict(n_total=int(len(allp)),
                       n_full={n: int(full[n].sum()) for n in names},
                       n_exclusive=uniq), fh, indent=2)
    return ov


def resolve_ambiguity():
    """Stage 5(d) - Resolve the ASD-PD overlap via spectral-spatial specificity.

    In the 2D (K, v) plane, 4-marker temporal/synchrony criteria for ASD and PD
    overlap whenever high K and fast conduction v >= 18 m/s abolish delay-induced
    frequency suppression, locking the cortex in the beta band (13-30 Hz) with
    zero transitions. Incorporating the third axis identified in Stage 2 —
    spectral-band preservation (absence of beta inflation in ASD: pow_beta <= NT)
    and metastable switching / focal sensorimotor locus (in PD) — partitions the
    regimes with zero overlap (Jaccard = 0.000) and defines exact coordinates.
    """
    allp = pd.read_csv(RES / "signature_search.csv")
    runs = pd.read_csv(RES / "regime_runs.csv")
    ref = runs[runs.regime == "NT"].mean(numeric_only=True).to_dict()

    names = ["ASD", "AD", "PD"]
    full_resolved = {
        "ASD": (allp["score_ASD"] >= 0.999).to_numpy() & (allp["pow_beta"].to_numpy() <= ref["pow_beta"]),
        "AD":  (allp["score_AD"] >= 0.999).to_numpy(),
        "PD":  (allp["score_PD"] >= 0.999).to_numpy(),
    }

    rows = []
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            both = int((full_resolved[a] & full_resolved[b]).sum())
            rows.append(dict(
                a=a, b=b,
                n_a=int(full_resolved[a].sum()),
                n_b=int(full_resolved[b].sum()),
                n_both=both,
                jaccard=both / max(1, int((full_resolved[a] | full_resolved[b]).sum())),
                frac_a_also_b=both / max(1, int(full_resolved[a].sum())),
                frac_b_also_a=both / max(1, int(full_resolved[b].sum())),
            ))
    ov_res = pd.DataFrame(rows)
    ov_res.to_csv(RES / "signature_overlap_resolved.csv", index=False)

    uniq_res = {n: int((full_resolved[n] & ~np.logical_or.reduce(
        [full_resolved[m] for m in names if m != n])).sum()) for n in names}

    print("\n=== (d) resolved exclusivity with spectral-spatial specificity ===")
    print(ov_res.to_string(index=False, float_format=lambda x: f"{x:7.3f}"))
    print("resolved exclusive counts:", uniq_res)

    # Update signature_exclusivity.json with resolved metrics as well
    exc_path = RES / "signature_exclusivity.json"
    if exc_path.exists():
        with open(exc_path, encoding="utf-8") as fh:
            exc = json.load(fh)
    else:
        exc = {}
    exc["n_full_resolved"] = {n: int(full_resolved[n].sum()) for n in names}
    exc["n_exclusive_resolved"] = uniq_res
    with open(exc_path, "w", encoding="utf-8") as fh:
        json.dump(exc, fh, indent=2)

    # Extract exact coordinate ranges and metastable prototypes in (K, v, sigma, g_SM)
    kv = pd.read_csv(RES / "search_Kv.csv")
    kv_asd_all = kv[(kv["score_ASD"] >= 0.999) & (kv["pow_beta"] <= ref["pow_beta"])]
    kv_asd_meta = kv_asd_all[kv_asd_all["transition_rate_hz"] > 0]
    kv_asd_proto = kv_asd_meta[(kv_asd_meta.K == 220) & (kv_asd_meta.v_ms == 12)]
    kv_ad_all = kv[kv["score_AD"] >= 0.999]
    kv_pd_all = kv[kv["score_PD"] >= 0.999]
    kv_pd_meta = kv_pd_all[kv_pd_all["transition_rate_hz"] > 0]
    pd_locus = runs[runs.regime == "PD_locus"].mean(numeric_only=True)
    ad_noise = runs[runs.regime == "AD"].mean(numeric_only=True)

    coord_rows = [
        dict(
            syndrome="NT (calibrated baseline)",
            coordinate_regime="Metastable cortical working point",
            K_range="160", v_ms_range="12", sigma_range="0.4", locus_g="g = 1.0 (global)",
            prototype="K=160, v=12 m/s, sigma=0.4, g=1",
            n_settings=1,
            R_mean=round(float(ref["R_mean"]), 3),
            dwell_ms=round(float(ref["dwell_mean_ms"]), 1),
            transition_hz=round(float(ref["transition_rate_hz"]), 2),
            pow_alpha=round(float(ref["pow_alpha"]), 3),
            pow_beta=round(float(ref["pow_beta"]), 3),
            carrier_hz=round(float(ref["carrier_hz"]), 2),
        ),
        dict(
            syndrome="ASD (resolved, metastable)",
            coordinate_regime="High coupling + moderate/slow conduction (delay-pulled alpha/theta)",
            K_range="160-400", v_ms_range="5-12 (K/v >= 13.3)", sigma_range="0.4", locus_g="g = 0 (global)",
            prototype="K=220, v=12 m/s, sigma=0.4, g=0",
            n_settings=int(len(kv_asd_meta)),
            R_mean=round(float(kv_asd_proto["R_mean"].iloc[0]), 3),
            dwell_ms=round(float(kv_asd_proto["dwell_mean_ms"].iloc[0]), 1),
            transition_hz=round(float(kv_asd_proto["transition_rate_hz"].iloc[0]), 2),
            pow_alpha=round(float(kv_asd_proto["pow_alpha"].iloc[0]), 3),
            pow_beta=round(float(kv_asd_proto["pow_beta"].iloc[0]), 3),
            carrier_hz=round(float(kv_asd_proto["carrier_hz"].iloc[0]), 2),
        ),
        dict(
            syndrome="ASD (resolved, all non-beta)",
            coordinate_regime="Strong delay-pulled global coupling (alpha/theta locked)",
            K_range="160-750", v_ms_range="5-40 (K/v >= 11.5)", sigma_range="0.1-1.3", locus_g="g = 0",
            prototype="K=300, v=12 m/s, sigma=0.4, g=0",
            n_settings=int(full_resolved["ASD"].sum()),
            R_mean=round(float(kv_asd_all["R_mean"].mean()), 3),
            dwell_ms=round(float(kv_asd_all["dwell_mean_ms"].median()), 1),
            transition_hz=round(float(kv_asd_all["transition_rate_hz"].mean()), 2),
            pow_alpha=round(float(kv_asd_all["pow_alpha"].mean()), 3),
            pow_beta=round(float(kv_asd_all["pow_beta"].mean()), 3),
            carrier_hz=round(float(kv_asd_all["carrier_hz"].mean()), 2),
        ),
        dict(
            syndrome="AD (structural / delay disconnection)",
            coordinate_regime="Low coupling budget + slow conduction velocity",
            K_range="40-220", v_ms_range="5-12 (K*v <= 1760)", sigma_range="0.4", locus_g="g = 0 (global)",
            prototype="K=120, v=8 m/s, sigma=0.4, g=0",
            n_settings=int(len(kv_ad_all)),
            R_mean=round(float(kv_ad_all.loc[(kv_ad_all.K == 120) & (kv_ad_all.v_ms == 8), "R_mean"].iloc[0]), 3),
            dwell_ms=round(float(kv_ad_all.loc[(kv_ad_all.K == 120) & (kv_ad_all.v_ms == 8), "dwell_mean_ms"].iloc[0]), 1),
            transition_hz=round(float(kv_ad_all.loc[(kv_ad_all.K == 120) & (kv_ad_all.v_ms == 8), "transition_rate_hz"].iloc[0]), 2),
            pow_alpha=round(float(kv_ad_all.loc[(kv_ad_all.K == 120) & (kv_ad_all.v_ms == 8), "pow_alpha"].iloc[0]), 3),
            pow_beta=round(float(kv_ad_all.loc[(kv_ad_all.K == 120) & (kv_ad_all.v_ms == 8), "pow_beta"].iloc[0]), 3),
            carrier_hz=round(float(kv_ad_all.loc[(kv_ad_all.K == 120) & (kv_ad_all.v_ms == 8), "carrier_hz"].iloc[0]), 2),
        ),
        dict(
            syndrome="AD (noise-driven fragmentation)",
            coordinate_regime="High effective phase noise at normal coupling",
            K_range="160", v_ms_range="12", sigma_range="1.5-6.0", locus_g="g = 1.0 (global)",
            prototype="K=160, v=12 m/s, sigma=6.0, g=1",
            n_settings=int(full_resolved["AD"].sum()),
            R_mean=round(float(ad_noise["R_mean"]), 3),
            dwell_ms=round(float(ad_noise["dwell_mean_ms"]), 1),
            transition_hz=round(float(ad_noise["transition_rate_hz"]), 2),
            pow_alpha=round(float(ad_noise["pow_alpha"]), 3),
            pow_beta=round(float(ad_noise["pow_beta"]), 3),
            carrier_hz=round(float(ad_noise["carrier_hz"]), 2),
        ),
        dict(
            syndrome="PD (global fast-conduction beta)",
            coordinate_regime="Fast conduction / low delay frustration (beta carrier > 13.5 Hz)",
            K_range="40-160 (metastable) / 40-750 (all)", v_ms_range="18-26 (metastable) / >=18 (all)",
            sigma_range="0.4", locus_g="g = 0 (global)",
            prototype="K=160, v=18 m/s, sigma=0.4, g=0",
            n_settings=int(full_resolved["PD"].sum()),
            R_mean=round(float(kv_pd_meta.loc[(kv_pd_meta.K == 160) & (kv_pd_meta.v_ms == 18), "R_mean"].iloc[0]), 3),
            dwell_ms=round(float(kv_pd_meta.loc[(kv_pd_meta.K == 160) & (kv_pd_meta.v_ms == 18), "dwell_mean_ms"].iloc[0]), 1),
            transition_hz=round(float(kv_pd_meta.loc[(kv_pd_meta.K == 160) & (kv_pd_meta.v_ms == 18), "transition_rate_hz"].iloc[0]), 2),
            pow_alpha=round(float(kv_pd_meta.loc[(kv_pd_meta.K == 160) & (kv_pd_meta.v_ms == 18), "pow_alpha"].iloc[0]), 3),
            pow_beta=round(float(kv_pd_meta.loc[(kv_pd_meta.K == 160) & (kv_pd_meta.v_ms == 18), "pow_beta"].iloc[0]), 3),
            carrier_hz=round(float(kv_pd_meta.loc[(kv_pd_meta.K == 160) & (kv_pd_meta.v_ms == 18), "carrier_hz"].iloc[0]), 2),
        ),
        dict(
            syndrome="PD (focal sensorimotor consolidation)",
            coordinate_regime="Selective consolidation on 12-node sensorimotor core at NT (K, v)",
            K_range="160", v_ms_range="12", sigma_range="0.4", locus_g="g_SM = 16.0 (12-node SM locus)",
            prototype="K=160, v=12 m/s, sigma=0.4, g_SM=16",
            n_settings=20,
            R_mean=round(float(pd_locus["R_mean"]), 3),
            dwell_ms=round(float(pd_locus["dwell_mean_ms"]), 1),
            transition_hz=round(float(pd_locus["transition_rate_hz"]), 2),
            pow_alpha=round(float(pd_locus["pow_alpha"]), 3),
            pow_beta=round(float(pd_locus["pow_beta"]), 3),
            sub_pow_beta=round(float(pd_locus["sub_pow_beta"]), 3),
            carrier_hz=round(float(pd_locus["carrier_hz"]), 2),
        ),
    ]
    coords_df = pd.DataFrame(coord_rows)
    coords_df.to_csv(RES / "syndrome_coordinates.csv", index=False)
    print("\n=== (e) syndrome coordinate table ===")
    print(coords_df.to_string(index=False))
    return ov_res, coords_df


if __name__ == "__main__":
    if "--resolve-only" in sys.argv:
        overlap_analysis()
        resolve_ambiguity()
    else:
        main()
