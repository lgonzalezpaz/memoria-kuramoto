#!/usr/bin/env python3
"""Generate every figure of the manuscript as vector PDF + 600 dpi PNG."""
from __future__ import annotations

import json, pathlib, sys
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.lines import Line2D

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES, FIG = ROOT / "results", ROOT / "figures"
FIG.mkdir(exist_ok=True)

mpl.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif", "Times New Roman", "Liberation Serif"],
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
    "axes.linewidth": 0.7, "xtick.major.width": 0.7, "ytick.major.width": 0.7,
    "axes.spines.top": False, "axes.spines.right": False,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.08,
    "figure.dpi": 150, "pdf.fonttype": 42, "ps.fonttype": 42,
})

COL = {"NT": "#4C72B0", "ASD": "#DD8452", "AD": "#55A868",
       "PD_hyp": "#C44E52", "PD_locus": "#8172B3"}
LAB = {"NT": "NT (neurotypical)", "ASD": "ASD quadrant", "AD": "AD quadrant",
       "PD_hyp": "PD quadrant (hypothesis)", "PD_locus": "PD (focal locus)"}
CM = "viridis"
MM = 1 / 25.4


def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"{name}.{ext}", dpi=600 if ext == "png" else None)
    plt.close(fig)
    print("  wrote", name)


def panel(ax, letter, dx=-0.20, dy=1.10):
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=10,
            fontweight="bold", va="top", ha="left")


# ============================================================ Figure 1 =======
def fig1():
    import model as M
    c = M.load_connectome(ROOT / "data")
    idx = M.subnetwork_indices(c)
    W, Mm, L = c["W"], c["M"], c["L"]
    n = c["n"]

    fig = plt.figure(figsize=(194 * MM, 138 * MM))
    gs = fig.add_gridspec(2, 3, hspace=0.58, wspace=0.72)

    ax = fig.add_subplot(gs[0, 0])
    im = ax.imshow(W, cmap=CM, norm=LogNorm(vmin=W[W > 0].min(), vmax=W.max()))
    ax.set_title("Structural connectivity $W_{ij}$", fontsize=8.0, pad=6)
    ax.set_xlabel("region"); ax.set_ylabel("region")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="weight (a.u.)")
    panel(ax, "a", dx=-0.28, dy=1.15)

    ax = fig.add_subplot(gs[0, 1])
    im = ax.imshow(Mm, cmap=CM, vmin=0, vmax=1)
    ax.set_title("Disynaptic motif\nsupport $M_{ij}$", fontsize=8.0, pad=6)
    ax.set_xlabel("region"); ax.set_ylabel("region")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="normalised $(W^2)_{ij}$")
    panel(ax, "b", dx=-0.26, dy=1.15)

    ax = fig.add_subplot(gs[0, 2])
    m = W > 0
    tau = L[m] * 1e-3 / 12.0 * 1e3
    ax.hist(tau, bins=40, color="#4C72B0", edgecolor="white", linewidth=0.3)
    ax.axvline(tau.mean(), color="k", ls="--", lw=0.9,
               label=f"mean {tau.mean():.1f} ms")
    ax.set_xlabel("conduction delay $\\tau_{ij}$ (ms)")
    ax.set_ylabel("number of edges")
    ax.set_title("Delay distribution\n($v = 12$ m s$^{-1}$)", fontsize=8.0, pad=6)
    ax.legend(frameon=False)
    panel(ax, "c", dx=-0.26, dy=1.15)

    ax = fig.add_subplot(gs[1, 0])
    mask = np.zeros((n, n))
    ins = np.zeros(n, bool); ins[idx] = True
    mask[np.ix_(ins, ins)] = 1.0
    ax.imshow(np.where(W > 0, 1.0, np.nan), cmap="Greys", vmin=0, vmax=3)
    ax.imshow(np.where((mask > 0) & (W > 0), 1.0, np.nan), cmap="autumn", vmin=0, vmax=1)
    ax.set_title("Sensorimotor\nconsolidation locus", fontsize=8.0, pad=6)
    ax.set_xlabel("region"); ax.set_ylabel("region")
    ax.text(0.98, 0.04, f"{len(idx)} nodes\n{int(((mask>0)&(W>0)).sum())} edges",
            transform=ax.transAxes, ha="right", va="bottom", fontsize=6.5)
    panel(ax, "d", dx=-0.26, dy=1.15)

    ax = fig.add_subplot(gs[1, 1:])
    d = np.load(RES / "state_dictionary.npz")
    import observables as O
    om = M.intrinsic_frequencies(n, f0=20.0)
    ed = M.build_edges(c, v_ms=12.0)
    out = M.simulate(ed, om, K=160.0, g=1.0, sigma=0.4, t_rec=6.0, seed=3,
                     n=n, sub_idx=idx)
    t = np.arange(len(out["R"])) / 500.0
    ax.plot(t, out["R"], lw=0.7, color="#333333", label="$R(t)$")
    ax.axhline(float(d["burst_thresh"]), color="#C44E52", ls=":", lw=0.9,
               label="burst threshold (75th pct.)")
    lab = O.assign_states(out["U"], d["centroids"])
    tt = np.arange(len(lab)) / 200.0
    for s in range(d["centroids"].shape[0]):
        ax.fill_between(tt, -0.08, -0.02, where=(lab == s), step="mid",
                        color=plt.get_cmap("tab10")(s), lw=0)
    ax.set_xlim(0, t[-1]); ax.set_ylim(-0.18, 0.96)
    ax.set_xlabel("time (s)"); ax.set_ylabel("synchrony $R$")
    ax.set_title("Metastable dynamics at the neurotypical operating point", fontsize=8.0, pad=6)
    ax.legend(frameon=False, loc="upper right", ncol=2)
    ax.text(0.01, -0.155, "configuration sequence", fontsize=6, va="bottom")
    panel(ax, "e", dx=-0.08, dy=1.12)

    save(fig, "fig1_framework")


# ============================================================ Figure 2 =======
def fig2():
    cg = pd.read_csv(RES / "calibration_grid.csv")
    with open(RES / "working_point.json", encoding="utf-8") as _fh:
        wp = json.load(_fh)
    fig, axes = plt.subplots(1, 3, figsize=(194 * MM, 68 * MM),
                             gridspec_kw=dict(wspace=0.58))

    ax = axes[0]
    for f0, mk in zip(sorted(cg.f0_hz.unique()), ["o", "s", "^"]):
        for v in sorted(cg.v_ms.unique()):
            s = cg[(cg.f0_hz == f0) & (cg.v_ms == v)].sort_values("K")
            ax.plot(s.K, s.metastability, marker=mk, ms=2.2, lw=0.6,
                    alpha=0.55, color=plt.get_cmap("viridis")(
                        (v - cg.v_ms.min()) / (cg.v_ms.max() - cg.v_ms.min())))
    ax.scatter([wp["K"]], [wp["metastability"]], s=42, facecolor="none",
               edgecolor="#C44E52", lw=1.3, zorder=5)
    ax.set_xscale("log"); ax.set_xlabel("global coupling $K$")
    ax.set_ylabel("metastability  SD$(R)$")
    ax.set_title("Working-point\nsearch", fontsize=8.0, pad=6)
    h = [Line2D([], [], marker=m, ls="-", lw=0.6, color="0.4", ms=3,
                label=f"$f_0$ = {f:.0f} Hz") for m, f in
         zip(["o", "s", "^"], sorted(cg.f0_hz.unique()))]
    ax.legend(handles=h, frameon=True, facecolor="white", framealpha=0.85,
              edgecolor="none", loc="lower left")
    panel(ax, "a", dx=-0.22, dy=1.15)

    ax = axes[1]
    ok = cg.dwell_mean_ms.between(60, 120) & cg.R_mean.between(0.15, 0.60)
    ax.scatter(cg.dwell_mean_ms[~ok], cg.metastability[~ok], s=7, c="0.75",
               lw=0, label="outside constraints")
    ax.scatter(cg.dwell_mean_ms[ok], cg.metastability[ok], s=12, c="#4C72B0",
               lw=0, label="admissible")
    ax.scatter([wp["dwell_mean_ms"]], [wp["metastability"]], s=42,
               facecolor="none", edgecolor="#C44E52", lw=1.3, zorder=5,
               label="working point")
    ax.axvspan(60, 120, color="#DD8452", alpha=0.12, lw=0)
    ax.set_xscale("log")
    ax.set_xlabel("mean dwell time (ms)"); ax.set_ylabel("metastability  SD$(R)$")
    ax.set_title("Empirical dwell-time\nconstraint", fontsize=8.0, pad=6)
    ax.legend(frameon=False, loc="lower right")
    panel(ax, "b", dx=-0.22, dy=1.15)

    ax = axes[2]
    names = ["dwell time\n(ms)", "SC–FC\ncorr.", "mean\nsynchrony $\\langle R\\rangle$"]
    mod = [wp["dwell_mean_ms"], wp["sc_fc_r"], wp["R_mean"]]
    lo = [60, 0.30, 0.15]; hi = [120, 0.70, 0.60]
    x = np.arange(3)
    for i in range(3):
        ax.plot([x[i], x[i]], [0, 1], color="0.9", lw=6, solid_capstyle="butt")
        ax.plot([x[i], x[i]], [0, 1], color="#DD8452", lw=6, alpha=0.35,
                solid_capstyle="butt")
        rel = (mod[i] - lo[i]) / (hi[i] - lo[i])
        ax.scatter([x[i]], [rel], s=46, color="#4C72B0", zorder=5)
        ax.text(x[i] + 0.16, rel, f"{mod[i]:.3g}", va="center", fontsize=7)
        ax.text(x[i], -0.11, f"{lo[i]:g}", ha="center", fontsize=6, color="0.4")
        ax.text(x[i], 1.04, f"{hi[i]:g}", ha="center", fontsize=6, color="0.4")
    ax.set_xticks(x); ax.set_xticklabels(names, fontsize=7.0)
    ax.set_xlim(-0.45, 2.55)
    ax.set_ylim(-0.2, 1.2); ax.set_yticks([])
    ax.set_title("Independent\nempirical anchors", fontsize=8.0, pad=6)
    ax.spines["left"].set_visible(False)
    panel(ax, "c", dx=-0.16, dy=1.15)

    save(fig, "fig2_calibration")


# ============================================================ Figure 3 =======
PD_PANELS = [("metastability", "metastability  SD$(R)$"),
             ("dwell_mean_ms", "mean dwell time (ms)"),
             ("transition_rate_hz", "transition rate (Hz)"),
             ("minor_occupancy", "minor-state occupancy"),
             ("parasitic_index", "dominant-state occupancy"),
             ("C_conc", "coupling concentration $H$"),
             ("R_mean", "mean synchrony $\\langle R\\rangle$"),
             ("pow_beta", "relative beta power"),
             ("theta_alpha_ratio", "theta/alpha ratio")]


def fig3():
    df = pd.read_csv(RES / "phase_diagram.csv")
    G = np.sort(df.g.unique()); S = np.sort(df.sigma.unique())
    quad = {"NT": (1.0, 0.4), "ASD": (16.0, 0.4), "AD": (1.0, 6.0), "PD_hyp": (16.0, 6.0)}
    fig, axes = plt.subplots(3, 3, figsize=(196 * MM, 182 * MM))
    for ax, (mk, lab) in zip(axes.ravel(), PD_PANELS):
        Z = df.pivot_table(index="si", columns="gi", values=mk).to_numpy()
        im = ax.pcolormesh(G, S, Z, cmap=CM, shading="nearest",
                           rasterized=True)
        ax.set_yscale("log")
        for q, (gq, sq) in quad.items():
            ax.plot(gq, sq, marker="o", ms=4.5, mfc="none", mec="w", mew=1.6)
            ax.plot(gq, sq, marker="o", ms=4.5, mfc="none", mec=COL[q], mew=1.0)
        ax.set_xlabel("consolidation gain $g$")
        ax.set_ylabel("noise amplitude $\\sigma$", labelpad=2)
        ax.set_title(lab)
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
        cb.ax.tick_params(labelsize=6.5)
    for ax, L in zip(axes.ravel(), "abcdefghi"):
        panel(ax, L, dx=-0.24, dy=1.10)
    fig.subplots_adjust(hspace=0.60, wspace=0.72)
    save(fig, "fig3_phase_diagram")


# ============================================================ Figure 4 =======
def fig4():
    runs = pd.read_csv(RES / "regime_runs.csv")
    sep = pd.read_csv(RES / "separability.csv")
    order = ["NT", "ASD", "AD", "PD_hyp", "PD_locus"]
    mks = ["R_mean", "metastability", "dwell_mean_ms", "transition_rate_hz",
           "repertoire_entropy", "minor_occupancy", "parasitic_index",
           "C_conc", "pow_beta", "sub_pow_beta", "burst_time_frac",
           "sub_burst_time_frac"]
    short = ["$\\langle R\\rangle$", "SD$(R)$", "dwell", "transit.", "$H$ repert.",
             "minor occ.", "domin. occ.", "$H$ coupling", "beta", "beta (SM)",
             "burst frac.", "burst frac. (SM)"]
    base = runs[runs.regime == "NT"]
    mu = base[mks].mean(); sd = base[mks].std(ddof=1).replace(0, np.nan)

    fig = plt.figure(figsize=(192 * MM, 140 * MM))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.15, 1.1], hspace=0.84, wspace=0.68)

    ax = fig.add_subplot(gs[0, :])
    x = np.arange(len(mks)); w = 0.16
    for i, r in enumerate(order):
        z = (runs[runs.regime == r][mks].mean() - mu) / sd
        e = (runs[runs.regime == r][mks].std(ddof=1)
             / np.sqrt(len(runs[runs.regime == r]))) / sd
        ax.bar(x + (i - 2) * w, z, w, yerr=e, color=COL[r], label=LAB[r],
               error_kw=dict(lw=0.6, capsize=1.3))
    ax.axhline(0, color="k", lw=0.7)
    ax.set_xticks(x); ax.set_xticklabels(short, rotation=35, ha="right")
    ax.set_ylabel("deviation from NT\n(SD of NT)")
    ax.set_title("Dynamical signature of each operating point")
    ax.legend(frameon=False, ncol=5, loc="upper center",
              bbox_to_anchor=(0.5, 1.26))
    panel(ax, "a", dx=-0.06, dy=1.08)

    ax = fig.add_subplot(gs[1, 0])
    Dm = pd.DataFrame(np.nan, index=order, columns=order)
    for _, r in sep.iterrows():
        Dm.loc[r.a, r.b] = Dm.loc[r.b, r.a] = r.centroid_distance
    A = Dm.to_numpy(dtype=float, copy=True)
    np.fill_diagonal(A, 0.0)
    im = ax.imshow(A, cmap=CM)
    ax.set_xticks(range(5)); ax.set_xticklabels(order, rotation=40, ha="right")
    ax.set_yticks(range(5)); ax.set_yticklabels(order)
    for i in range(5):
        for j in range(5):
            if i != j:
                v = A[i, j]
                ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=6,
                        color="w" if v < A.max() * 0.6 else "k")
    ax.set_title("Centroid distance\nin marker space", fontsize=8.0, pad=6)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    panel(ax, "b", dx=-0.30, dy=1.15)

    ax = fig.add_subplot(gs[1, 1])
    pairs = sep.assign(lbl=sep.a + " vs " + sep.b).sort_values("centroid_distance")
    cols = ["#C44E52" if q >= 0.05 else "#4C72B0" for q in pairs.q_bh]
    ax.barh(np.arange(len(pairs)), pairs.centroid_distance, color=cols, height=0.65)
    ax.set_yticks(np.arange(len(pairs)))
    ax.set_yticklabels(pairs.lbl, fontsize=6.2)
    ax.set_xlabel("centroid distance (z units)")
    ax.set_title("Separability\n(red: $q \\geq 0.05$)", fontsize=8.0, pad=6)
    panel(ax, "c", dx=-0.46, dy=1.15)

    save(fig, "fig4_regimes")


# ============================================================ Figure 5 =======
def fig5():
    """The negative result on the consolidation axis, across implementations."""
    ct = pd.read_csv(RES / "controls.csv")
    from scipy.stats import spearmanr
    fig = plt.figure(figsize=(196 * MM, 78 * MM))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.35, 1.0, 1.0], wspace=0.78)

    ax = fig.add_subplot(gs[0, 0])
    ctrls = sorted(ct.control.unique())
    cmap = plt.get_cmap("viridis")
    for i, c in enumerate(ctrls):
        s = ct[ct.control == c].groupby("g")["dwell_mean_ms"].agg(["mean", "sem"])
        ax.errorbar(s.index, s["mean"], yerr=s["sem"], marker="o", ms=2.8, lw=0.9,
                    capsize=1.4, color=cmap(i / max(1, len(ctrls) - 1)), label=c)
    ax.set_ylim(0, 148)
    ax.set_xlabel("consolidation gain $g$")
    ax.set_ylabel("mean dwell time (ms)")
    ax.set_title("Dwell time falls with $g$\nin every implementation", fontsize=8.0, pad=6)
    ax.legend(frameon=True, facecolor="white", framealpha=0.88, edgecolor="none",
              fontsize=5.2, ncol=1, loc="upper right")
    panel(ax, "a", dx=-0.22, dy=1.15)

    ax = fig.add_subplot(gs[0, 1])
    rows = [(c, *spearmanr(s.g, s.dwell_mean_ms)) for c, s in ct.groupby("control")]
    rows.sort(key=lambda r: r[1])
    y = np.arange(len(rows))
    ax.barh(y, [r[1] for r in rows], color="#C44E52", height=0.65)
    ax.axvline(0, color="k", lw=0.7)
    ax.set_yticks(y)
    ax.set_yticklabels([r[0] for r in rows], fontsize=5.5)
    ax.set_xlabel("Spearman $\\rho$ (dwell vs $g$)")
    ax.set_xlim(-1.05, 0.25)
    ax.set_title("All negative,\nall $p < 10^{-9}$", fontsize=8.0, pad=6)
    panel(ax, "b", dx=-0.56, dy=1.15)

    ax = fig.add_subplot(gs[0, 2])
    for i, c in enumerate(ctrls):
        s = ct[ct.control == c].groupby("g")[["C_conc", "C_total"]].mean()
        ax.plot(s.index, s["C_conc"], marker="o", ms=2.6, lw=0.9,
                color=cmap(i / max(1, len(ctrls) - 1)))
    ax.set_xlabel("consolidation gain $g$")
    ax.set_ylabel("coupling concentration $H$")
    ax.set_title("The landscape IS\nbeing sculpted", fontsize=8.0, pad=6)
    panel(ax, "c", dx=-0.24, dy=1.15)

    save(fig, "fig5_consolidation_controls")


# ============================================================ Figure 6 =======
def fig6():
    val = pd.read_csv(RES / "validation.csv")
    mo = pd.read_csv(RES / "morris.csv")
    rb = pd.read_csv(RES / "robustness.csv")
    fig = plt.figure(figsize=(194 * MM, 195 * MM))
    gs = fig.add_gridspec(2, 2, height_ratios=[2.0, 1.0], hspace=0.44, wspace=0.58)

    ax = fig.add_subplot(gs[0, :])
    v = val.sort_values(["regime", "marker"]).reset_index(drop=True)
    y = np.arange(len(v))
    cols = ["#4C72B0" if a else "#C44E52" for a in v.agree]
    ax.barh(y, [1] * len(v), color=cols, height=0.68)
    ax.set_yticks(y)
    ax.set_yticklabels([f"{r.marker} [{r.regime}]" for r in v.itertuples()],
                       fontsize=5.6)
    ax.set_xticks([])
    for i, r in enumerate(v.itertuples()):
        ax.text(1.02, i, f"{r.source}", va="center", fontsize=5.5)
    ax.set_xlim(0, 1.0)
    ax.set_title("Confrontation with the published literature "
                 "(blue: model agrees, red: disagrees)")
    ax.invert_yaxis()
    panel(ax, "a", dx=-0.28, dy=1.04)

    ax = fig.add_subplot(gs[1, 0])
    piv = mo.pivot(index="output", columns="factor", values="mu_star")
    im = ax.imshow(piv.to_numpy(), cmap=CM, aspect="auto")
    ax.set_xticks(range(piv.shape[1]))
    ax.set_xticklabels(piv.columns, rotation=40, ha="right", fontsize=6)
    ax.set_yticks(range(piv.shape[0]))
    ax.set_yticklabels(piv.index, fontsize=5.6)
    ax.set_title("Morris screening $\\mu^*$ (nuisance parameters)")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    panel(ax, "b", dx=-0.42, dy=1.10)

    ax = fig.add_subplot(gs[1, 1])
    order = ["NT", "ASD", "AD", "PD_hyp", "PD_locus"]
    order = [o for o in order if o in set(rb.regime)]
    for r in order:
        s = rb[rb.regime == r]
        ax.scatter(np.arange(len(s)), s.minor_occupancy, s=8, color=COL[r],
                   label=LAB[r], alpha=0.75, lw=0)
    ax.set_xlabel("perturbed-parameter setting (index)")
    ax.set_ylabel("minor-state occupancy")
    ax.set_title("Ordering preserved under $\\pm25\\,\\%$ perturbation")
    ax.legend(frameon=False, fontsize=5.6, ncol=2)
    panel(ax, "c", dx=-0.24, dy=1.10)

    save(fig, "fig6_validation_sensitivity")


# ======================================================== Supplementary ======
def figS():
    cg = pd.read_csv(RES / "calibration_grid.csv")
    fig, axes = plt.subplots(1, 3, figsize=(190 * MM, 64 * MM), sharey=True,
                             gridspec_kw=dict(wspace=0.22))
    for ax, f0 in zip(axes, sorted(cg.f0_hz.unique())):
        s = cg[cg.f0_hz == f0]
        p = s.pivot_table(index="v_ms", columns="K", values="metastability")
        im = ax.imshow(p.to_numpy(), cmap=CM, aspect="auto", origin="lower")
        ax.set_xticks(range(p.shape[1]))
        ax.set_xticklabels([f"{c:g}" for c in p.columns], rotation=40, fontsize=6)
        ax.set_yticks(range(p.shape[0]))
        ax.set_yticklabels([f"{i:g}" for i in p.index], fontsize=6)
        ax.set_title(f"$f_0$ = {f0:.0f} Hz"); ax.set_xlabel("$K$")
    axes[0].set_ylabel("$v$ (m s$^{-1}$)")
    fig.colorbar(im, ax=axes, fraction=0.025, pad=0.03, label="metastability SD$(R)$")
    save(fig, "figS1_calibration_full")

    kr = pd.read_csv(RES / "k_robustness.csv")
    fig, axes = plt.subplots(1, 3, figsize=(196 * MM, 70 * MM),
                             gridspec_kw=dict(wspace=0.54))
    for i_ax, (ax, mk, lab) in enumerate(zip(
            axes, ["dwell_mean_ms", "minor_occupancy", "parasitic_index"],
            ["dwell time (ms)", "minor-state occupancy",
             "dominant-state occupancy"])):
        for r in kr.regime.unique():
            s = kr[kr.regime == r].groupby("k")[mk].agg(["mean", "sem"])
            ax.errorbar(s.index, s["mean"], yerr=s["sem"], marker="o", ms=3,
                        lw=1.0, color=COL.get(r, "0.5"), label=LAB.get(r, r),
                        capsize=1.5)
        ax.set_xlabel("repertoire size $k$"); ax.set_ylabel(lab)
        if i_ax == 0:
            ax.set_ylim(0, 255)
    axes[0].legend(frameon=True, facecolor="white", framealpha=0.88,
                   edgecolor="none", fontsize=5.3, loc="upper right")
    save(fig, "figS2_k_robustness")

    pp = pd.read_csv(RES / "prior_predictive.csv")
    tg = pd.read_csv(ROOT / "data" / "empirical_targets.csv")
    iv = tg[tg.target_type == "interval"].drop_duplicates("marker")
    fig, axes = plt.subplots(1, len(iv), figsize=(194 * MM, 66 * MM),
                             gridspec_kw=dict(wspace=0.48))
    axes = np.atleast_1d(axes)
    for ax, (_, t) in zip(axes, iv.iterrows()):
        if t["marker"] not in pp.columns:
            continue
        x = pp[t["marker"]].dropna()
        if t["marker"] == "dwell_mean_ms":
            bins = np.geomspace(max(1e-3, x.min()), x.max(), 31)
            ax.hist(x, bins=bins, color="#4C72B0", edgecolor="white", lw=0.3)
            ax.set_xscale("log")
        else:
            ax.hist(x, bins=30, color="#4C72B0", edgecolor="white", lw=0.3)
        ax.axvspan(t["target_low"], t["target_high"], color="#DD8452", alpha=0.3, lw=0)
        ax.set_xlabel(t["marker"]); ax.set_ylabel("prior-predictive draws")
    save(fig, "figS3_prior_predictive")

    runs = pd.read_csv(RES / "regime_runs.csv")
    fig, ax = plt.subplots(figsize=(110 * MM, 74 * MM))
    for r in ["NT", "ASD", "AD", "PD_hyp", "PD_locus"]:
        s = runs[runs.regime == r]
        ax.scatter(s.pow_alpha, s.pow_beta, s=12, color=COL[r], label=LAB[r],
                   alpha=0.8, lw=0)
    ax.set_xlabel("relative alpha power"); ax.set_ylabel("relative beta power")
    ax.set_title("Spectral separation of the operating points")
    ax.legend(frameon=False, fontsize=6.5)
    save(fig, "figS4_spectral")




# ============================================================ Figure 7 =======
def fig7():
    """Where the clinical signatures actually live, and how exclusive they are."""
    kv = pd.read_csv(RES / "search_Kv.csv")
    ov = pd.read_csv(RES / "signature_overlap.csv")
    with open(RES / "signature_exclusivity.json", encoding="utf-8") as _fh:
        exc = json.load(_fh)

    fig = plt.figure(figsize=(194 * MM, 134 * MM))
    gs = fig.add_gridspec(2, 3, hspace=0.72, wspace=0.64)

    Ks = np.sort(kv.K.unique())
    vs = np.sort(kv.v_ms.unique())
    vlab = [("$\\infty$" if v > 1e4 else f"{v:g}") for v in vs]
    for j, nm in enumerate(["ASD", "AD", "PD"]):
        ax = fig.add_subplot(gs[0, j])
        Z = kv.pivot_table(index="v_ms", columns="K", values=f"score_{nm}").to_numpy()
        im = ax.imshow(Z, cmap=CM, vmin=0, vmax=1, aspect="auto", origin="lower")
        ax.set_xticks(range(len(Ks)))
        ax.set_xticklabels([f"{k:g}" for k in Ks], rotation=45, fontsize=5.6)
        ax.set_yticks(range(len(vs)))
        ax.set_yticklabels(vlab, fontsize=5.6)
        ax.set_xlabel("coupling budget $K$")
        if j == 0:
            ax.set_ylabel("conduction velocity $v$ (m s$^{-1}$)")
        ax.set_title(f"{nm} signature")
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        if j == 2:
            cb.set_label("fraction of criteria met", fontsize=6.5)
        panel(ax, "abc"[j], dx=-0.26, dy=1.10)

    ax = fig.add_subplot(gs[1, 0])
    names = ["ASD", "AD", "PD"]
    Jm = pd.DataFrame(np.nan, index=names, columns=names)
    for _, r in ov.iterrows():
        Jm.loc[r.a, r.b] = Jm.loc[r.b, r.a] = r.jaccard
    J = Jm.to_numpy(dtype=float, copy=True)
    np.fill_diagonal(J, 1.0)
    im = ax.imshow(J, cmap=CM, vmin=0, vmax=1)
    ax.set_xticks(range(3)); ax.set_xticklabels(names)
    ax.set_yticks(range(3)); ax.set_yticklabels(names)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, f"{J[i, j]:.2f}", ha="center", va="center",
                    fontsize=6.5, color="w" if J[i, j] < 0.6 else "k")
    ax.set_title("Signature overlap\n(Jaccard)", fontsize=8.0, pad=6)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    panel(ax, "d", dx=-0.30, dy=1.15)

    ax = fig.add_subplot(gs[1, 1])
    nf = exc["n_full"]; ne = exc["n_exclusive"]
    nr = exc.get("n_exclusive_resolved", ne)
    x = np.arange(3); w = 0.26
    ax.bar(x - w, [nf[n] for n in names], w, color="#4C72B0",
           label="4-crit. satisfied")
    ax.bar(x, [ne[n] for n in names], w, color="#DD8452",
           label="4-crit. exclusive")
    ax.bar(x + w, [nr[n] for n in names], w, color="#55A868",
           label="resolved exclusive (J=0)")
    ax.set_xticks(x); ax.set_xticklabels(names)
    ax.set_ylim(0, 185)
    ax.set_ylabel("model settings")
    ax.text(0.98, 0.56, f"n = {exc['n_total']}\ntested", transform=ax.transAxes,
            ha="right", va="center", fontsize=6.0)
    ax.set_title("Exclusivity before and\nafter resolution", fontsize=8.0, pad=6)
    ax.legend(frameon=False, fontsize=5.3, loc="upper left")
    panel(ax, "e", dx=-0.30, dy=1.15)

    ax = fig.add_subplot(gs[1, 2])
    runs = pd.read_csv(RES / "regime_runs.csv")
    nt = runs[runs.regime == "NT"]
    nt_beta = float(nt.pow_beta.mean())
    asd_m = (kv.score_ASD >= 0.999) & (kv.pow_beta <= nt_beta)
    pd_m = (kv.score_PD >= 0.999)
    other_m = ~(asd_m | pd_m)
    ax.scatter(kv.pow_alpha[other_m], kv.pow_beta[other_m], s=12, color="0.78",
               lw=0, label="other / AD")
    ax.scatter(kv.pow_alpha[asd_m], kv.pow_beta[asd_m], s=20, color=COL["ASD"],
               lw=0, alpha=0.9, label="ASD (resolved)")
    ax.scatter(kv.pow_alpha[pd_m], kv.pow_beta[pd_m], s=20, color=COL["PD_hyp"],
               lw=0, alpha=0.9, label="PD (beta-locked)")
    ax.axhline(nt_beta, color="0.35", ls="--", lw=0.7)
    ax.scatter([nt.pow_alpha.mean()], [nt_beta], s=55, marker="*",
               color="#4C72B0", zorder=5, label="NT working point")
    ax.set_xlabel("relative alpha power")
    ax.set_ylabel("relative beta power")
    ax.set_title("Spectral resolution\nof ASD vs PD", fontsize=8.0, pad=6)
    ax.legend(frameon=False, fontsize=5.3, loc="upper right")
    panel(ax, "f", dx=-0.30, dy=1.15)

    save(fig, "fig7_signature_search")


def figS5():
    ls = pd.read_csv(RES / "locus_sweep.csv")
    fig, axes = plt.subplots(1, 3, figsize=(196 * MM, 72 * MM),
                             gridspec_kw=dict(wspace=0.56))
    for i_ax, (ax, (mk, lab)) in enumerate(zip(
            axes, [("sub_pow_beta", "beta power (sensorimotor)"),
                   ("parasitic_index", "dominant-state occupancy"),
                   ("dwell_mean_ms", "mean dwell time (ms)")])):
        for anat, c, nm in [(True, "#8172B3", "anatomical core"),
                            (False, "#999999", "size-matched random")]:
            s = ls[ls.anatomical == anat].groupby("locus_size")[mk].agg(["mean", "sem"])
            ax.errorbar(s.index, s["mean"], yerr=s["sem"], marker="o", ms=3.2,
                        lw=1.0, color=c, capsize=1.6, label=nm)
        ax.set_xlabel("consolidation locus size (nodes)", fontsize=7.2)
        ax.set_ylabel(lab)
        if i_ax == 0:
            ax.set_ylim(0.02, 0.305)
    axes[0].legend(frameon=False, fontsize=5.8, loc="upper left")
    fig.subplots_adjust(left=0.07, right=0.93, bottom=0.18, top=0.95)
    save(fig, "figS5_locus_sweep")


def main():
    for fn in (fig1, fig2, fig3, fig4, fig5, fig6, fig7, figS, figS5):
        try:
            fn()
        except Exception as e:                                # pragma: no cover
            print(f"  !! {fn.__name__} failed: {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
