#!/usr/bin/env python3
"""Regenerate data/dk68_*.txt from the upstream tvb-data distribution.

Only needed if you prefer not to trust the redistributed copy in data/.
Requires network access to PyPI.
"""
import hashlib, pathlib, shutil, subprocess, sys, tempfile, zipfile, bz2

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
EXPECT = {"dk68_weights.txt": "2a17652fecca239d910a4140b6a9b366",
          "dk68_tract_lengths.txt": "5f735f5fec2746a74a53d60bbda6a8e0"}
MAP = {"weights.txt": "dk68_weights.txt",
       "tract_lengths.txt": "dk68_tract_lengths.txt",
       "centres.txt": "dk68_centres.txt",
       "average_orientations.txt": "dk68_orientations.txt"}


def main():
    with tempfile.TemporaryDirectory() as td:
        td = pathlib.Path(td)
        subprocess.run([sys.executable, "-m", "pip", "download", "tvb-data==3.0.0",
                        "--no-deps", "-d", str(td)], check=True)
        whl = next(td.glob("tvb_data-3.0.0*.whl"))
        with zipfile.ZipFile(whl) as z:
            z.extractall(td / "x")
        with zipfile.ZipFile(td / "x" / "tvb_data" / "connectivity" / "connectivity_68.zip") as z:
            z.extractall(td / "c68")
        for src, dst in MAP.items():
            p = td / "c68" / src
            if not p.exists() and (td / "c68" / (src + ".bz2")).exists():
                p.write_bytes(bz2.decompress((td / "c68" / (src + ".bz2")).read_bytes()))
            shutil.copy(p, DATA / dst)
    with open(DATA / "dk68_centres.txt", encoding="utf-8") as fh:
        centres = "".join(ln.split()[0] + "\n" for ln in fh)
    (DATA / "dk68_regions.txt").write_text(centres, encoding="utf-8")
    for f, h in EXPECT.items():
        got = hashlib.md5((DATA / f).read_bytes()).hexdigest()
        assert got == h, f"checksum mismatch for {f}: {got} != {h}"
        print(f"OK {f} {got}")


if __name__ == "__main__":
    main()
